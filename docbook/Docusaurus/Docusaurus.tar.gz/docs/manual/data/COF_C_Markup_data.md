<div id="d126470e1" class="table">

<div class="table-title">

Table 1. Markup

</div>

<div class="table-contents">

|                                 |                      |                   |         |                 |                 |                      |         |                     |                       |                       |
| :-----------------------------: | :------------------: | :---------------: | :-----: | :-------------: | :-------------: | :------------------: | :-----: | :-----------------: | :-------------------: | :-------------------: |
| Permitir Informações do Produto | Parceiro de Negócios | Tipo de Documento | Markup  | Margem Máxima % | Margem Mínima % | Categoria de Produto | Produto | Prioridade Relativa |     Válido desde      |      Válido até       |
|              true               |                      |                   | 5000000 |       30        |       20        |                      | 5000022 |         15          | 2018-03-01 00:00:00.0 | 2018-03-01 00:00:00.0 |

</div>

</div>
