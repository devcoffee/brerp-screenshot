<div id="d558647e1" class="table">

<div class="table-title">

Table 1. Campo de Entrada de Serviço
Web

</div>

<div class="table-contents">

|        |            |                     |                   |                      |               |                     |                                 |                     |
| :----: | :--------: | :-----------------: | :---------------: | :------------------: | :-----------: | :-----------------: | :-----------------------------: | :-----------------: |
| Coluna | Referência | Chave de Referência | Nome da Coluna BD | Identificador Lógico | Identificador | Permitir Valor Nulo | Campo de Entrada de Serviço Web | Tipo de Serviço Web |
|  2901  |            |                     |                   |                      |     false     |        false        |              50000              |        50001        |
|  2902  |            |                     |                   |                      |     false     |        false        |              50001              |        50001        |
|  2909  |            |                     |                   |                      |     false     |        false        |              50002              |        50001        |
|  2915  |            |                     |                   |                      |     false     |        false        |              50003              |        50001        |
|  2916  |            |                     |                   |                      |     false     |        false        |              50004              |        50001        |
|  3082  |            |                     |                   |                      |     false     |        false        |              50005              |        50001        |
|  4216  |            |                     |                   |                      |     false     |        false        |              50006              |        50001        |
|  4940  |            |                     |                   |                      |     false     |        false        |              50007              |        50001        |
|  2893  |            |                     |                   |                      |     false     |        false        |             5000000             |       5000000       |
|  4216  |            |                     |                   |                      |     false     |        false        |             5000001             |       5000000       |
|  2903  |            |                     |                   |                      |     false     |        false        |             5000002             |       5000000       |
|  2902  |            |                     |                   |                      |     false     |        false        |             5000003             |       5000000       |
|  2901  |            |                     |                   |                      |     false     |        false        |             5000004             |       5000000       |
|  2909  |            |                     |                   |                      |     false     |        false        |             5000005             |       5000000       |
| 58113  |            |                     |                   |                      |     false     |        false        |             5000006             |       5000000       |
|  2901  |            |                     |                   |                      |     false     |        false        |             5000007             |       5000001       |
|  6287  |            |                     |                   |                      |     false     |        false        |             5000008             |       5000002       |
|  6295  |            |                     |                   |                      |     false     |        false        |             5000009             |       5000004       |
| 10573  |            |                     |                   |                      |     false     |        false        |             5000010             |       5000004       |
|  6296  |            |                     |                   |                      |     false     |        false        |             5000011             |       5000004       |
| 212770 |            |                     |                   |                      |     false     |        false        |             5000012             |       5000005       |
| 212781 |            |                     |                   |                      |     false     |        false        |             5000013             |       5000005       |
| 212782 |            |                     |                   |                      |     false     |        false        |             5000014             |       5000005       |
| 212771 |            |                     |                   |                      |     false     |        false        |             5000015             |       5000005       |
| 212779 |            |                     |                   |                      |     false     |        false        |             5000017             |       5000005       |
| 212780 |            |                     |                   |                      |     false     |        false        |             5000018             |       5000005       |
| 212784 |            |                     |                   |                      |     false     |        false        |             5000019             |       5000005       |
| 212785 |            |                     |                   |                      |     false     |        false        |             5000020             |       5000005       |
| 212786 |            |                     |                   |                      |     false     |        false        |             5000021             |       5000005       |
| 212783 |            |                     |                   |                      |     false     |        false        |             5000022             |       5000005       |
| 212787 |            |                     |                   |                      |     false     |        false        |             5000025             |       5000005       |

</div>

</div>
