<div id="d144212e1" class="table">

<div class="table-title">

Table 1. Conta Bancária de
Parceiro

</div>

<div class="table-contents">

|            |                 |               |                 |                |                       |                                 |               |                 |              |              |                        |           |       |                      |                            |                          |              |              |        |                   |                       |                                      |      |       |                     |                |                    |
| :--------: | :-------------: | :-----------: | :-------------: | :------------: | :-------------------: | :-----------------------------: | :-----------: | :-------------: | :----------: | :----------: | :--------------------: | :-------: | :---: | :------------------: | :------------------------: | :----------------------: | :----------: | :----------: | :----: | :---------------: | :-------------------: | :----------------------------------: | :--: | :---: | :-----------------: | :------------: | :----------------: |
| Núm. Conta | Cidade da Conta | País da Conta | Usuário/Contato | Email da Conta | Carteira de Motorista | Núm.de Seguridade Social (INSS) | Nome da Conta | Estado da Conta | Rua da Conta | CEP da Conta | Tipo de Conta Bancária | Uso Conta | Banco | Parceiro de Negócios | Conta Bancária de Parceiro | Processador de Pagamento | Validade Mês | Validade Ano | Número | Cartão de Crédito | Código de Verificação | ID do Perfil de Pagamento do Cliente | IBAN |  CCA  | Endereço Verificado | CEP Verificado | Número de Rastreio |
|            |                 |               |                 |                |                       |                                 |  Cust1 Acct1  |                 |              |              |                        |           |       |         117          |            100             |                          |      0       |     2000     |        |                   |                       |                                      |      | false |                     |                |                    |

</div>

</div>
