<div id="d412726e1" class="table">

<div class="table-title">

Table 1. Cronograma de Manutenção
Preventiva

</div>

<div class="table-contents">

|                |         |                   |           |          |                       |                              |                       |                          |           |                     |                     |           |                |           |                |                                  |                                     |                        |                      |            |            |                     |      |       |
| :------------: | :-----: | :---------------: | :-------: | :------: | :-------------------: | :--------------------------: | :-------------------: | :----------------------: | :-------: | :-----------------: | :-----------------: | :-------: | :------------: | :-------: | :------------: | :------------------------------: | :---------------------------------: | :--------------------: | :------------------: | :--------: | :--------: | :-----------------: | :--: | :---: |
| Grupo de Ativo |  Ativo  | Tipo de Documento | Copiar de | MP Atual |   Data da Última OT   | Data do último processamento | Última Execução de MP | Data da Próxima Execução | Descrição | Estado do Documento | Número do Documento | Intervalo | Registro Filho | Última MP | Última Leitura | Checklist de Processos (Padrões) | Cronograma de Manutenção Preventiva | Cronograma de MP (Pai) | Métrica de Prevenção | Próxima MP | Prioridade | Tipo da Programação | Uso  | Faixa |
|    5000000     | 5000000 |                   |     N     |    0     |                       |    2018-01-19 00:00:00.0     | 2018-01-19 00:00:00.0 |  2018-01-29 00:00:00.0   |           |         AT          |       1000000       |   10.0    |     false      |     0     |       0        |                                  |               5000000               |                        |                      |     0      |            |          C          |  0   |   0   |
|    5000000     | 5000000 |                   |     N     |    0     |                       |    2018-01-24 00:00:00.0     | 2018-01-24 00:00:00.0 |                          |           |         AT          |       1000001       |    10     |     false      |   42.00   |       0        |                                  |               5000001               |                        |       5000001        |   52.00    |            |          M          | 4.67 |   5   |
|    5000001     | 5000002 |                   |     N     |    0     |                       |                              |                       |                          |           |         AT          |       1000002       |     0     |     false      |     0     |       0        |                                  |               5000002               |                        |       5000001        |     0      |            |          M          |  0   |   0   |
|                |         |                   |           |          | 2018-02-19 13:37:06.0 |                              |                       |                          |           |         AT          |       1000003       |           |                |           |                |                                  |               5000003               |                        |                      |            |            |          M          |      |       |

</div>

</div>
