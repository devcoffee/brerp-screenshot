<div id="d74835e1" class="table">

<div class="table-title">

Table 1. Provedor de
Armazenamento

</div>

<div class="table-contents">

|                           |                                                 |            |                                   |       |     |                  |
| :-----------------------: | :---------------------------------------------: | :--------: | :-------------------------------: | :---: | :-: | :--------------: |
| Provedor de Armazenamento |                     Folder                      |   Método   |               Nome                | Senha | URL | Email Registrado |
|          1000000          | /tmp/js\_brerp-5.1R1\_031218/Attachments\_BrERP | FileSystem | File System Configuration - BrERP |       |     |                  |

</div>

</div>
