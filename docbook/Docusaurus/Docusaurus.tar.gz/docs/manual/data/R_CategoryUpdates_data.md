<div id="d541898e1" class="table">

<div class="table-title">

Table 1. R\_CategoryUpdates

</div>

<div class="table-contents">

|                 |              |           |
| :-------------: | :----------: | :-------: |
| Usuário/Contato | Auto-Serviço | Categoria |
|       101       |    false     |    101    |

</div>

</div>
