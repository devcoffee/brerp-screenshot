<div id="d75140e1" class="table">

<div class="table-title">

Table 1. Style

</div>

<div class="table-contents">

|         |                                      |                                                             |
| :-----: | :----------------------------------: | :---------------------------------------------------------: |
|  Style  |                Style                 |                          Descrição                          |
| 200000  | 2761af49-8165-416c-8522-b1acc548e492 |                                                             |
| 5000000 | 17f62052-1be3-4756-b31f-d1179e68a8e7 |             Tipo de documento para Info Window              |
| 5000001 | 0e8c03c8-fa72-4b71-aaf3-312ce710d8da |                                                             |
| 5000002 | a75e0306-aeec-4b45-976d-d26652fbc240 |                                                             |
| 5000003 | 218051f4-283c-40fc-8b4c-83cb41ccc873 |                                                             |
| 5000004 | 4533cc77-4c67-4b9e-b434-6a72caa45d70 |                                                             |
| 5000005 | 36f8b635-d662-4484-b53e-182467c62e6f | Quantidade de Linhas sem Fiscal na Info de Pedido Detalhado |

</div>

</div>
