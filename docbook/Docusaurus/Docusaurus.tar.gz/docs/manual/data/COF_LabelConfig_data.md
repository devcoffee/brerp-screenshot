<div id="d132213e1" class="table">

<div class="table-title">

Table 1. Configuração de
Etiqueta

</div>

<div class="table-contents">

|                            |                                |                          |                      |                        |                  |                                  |                    |           |          |                |
| :------------------------: | :----------------------------: | :----------------------: | :------------------: | :--------------------: | :--------------: | :------------------------------: | :----------------: | :-------: | :------: | :------------: |
| Permitir Etiqueta Repetida | Validar Tamanho do Cód. Barras | Configuração de Etiqueta | Tipo de Configuração | Caracteres Cód. Barras | Tipo de Etiqueta | Verificar existência de etiqueta | Digito Verificador | Descrição |   Nome   | Chave de Busca |
|           false            |             false              |         5000000          |          BO          |           1            |        FI        |               true               |         1          |           | Etiqueta |    1000000     |

</div>

</div>
