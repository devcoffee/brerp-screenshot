<div id="d399507e1" class="table">

<div class="table-title">

Table 1. Mensagem
Legal

</div>

<div class="table-contents">

|             |                |      |                                                                                                                                                                                                                 |
| :---------: | :------------: | :--: | :-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------: |
| Comentários | Mensagem Legal | Nome |                                                                                                Texto de Mensagem                                                                                                |
|             |    5000000     |  01  | DOCUMENTO EMITIDO POR ME OU EPP OPTANTE PELO SIMPLES NACIONAL; PERMITE O APROVEITAMENTO DO CREDITO DE ICMS NO VALOR DE R$ @VCREDICMSSN@ CORRESPONDENTE A ALIQUOTA DE @PCREDSN@ % NOS TERMOS DO ART.23 DA LC.123 |

</div>

</div>
