<div id="d187508e1" class="table">

<div class="table-title">

Table 1. Programação de
Faturamento

</div>

<div class="table-contents">

|       |                            |           |                           |               |                           |                      |                            |                                     |              |        |         |
| :---: | :------------------------: | :-------: | :-----------------------: | :-----------: | :-----------------------: | :------------------: | :------------------------: | :---------------------------------: | :----------: | :----: | :-----: |
| Valor | Programação de Faturamento | Descrição | Faturar nas Semanas Pares | Dia da Fatura | Último dia p/ Faturamento | Freqüência da Fatura | Dia de Semana para Faturar | Último dia da semana p/ Faturamento | Valor Limite | Padrão |  Nome   |
|   0   |            100             |           |           false           |      30       |             0             |          M           |                            |                                     |    false     | false  | Monthly |

</div>

</div>
