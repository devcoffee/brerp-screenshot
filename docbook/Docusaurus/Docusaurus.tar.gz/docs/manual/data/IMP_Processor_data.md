<div id="d319061e1" class="table">

<div class="table-title">

Table 1. Importar
Processo

</div>

<div class="table-contents">

|                |                              |                          |                                        |            |                    |                                 |                 |                   |                            |                                 |                                                      |                 |       |                 |                            |
| :------------: | :--------------------------: | :----------------------: | :------------------------------------: | :--------: | :----------------: | :-----------------------------: | :-------------: | :---------------: | :------------------------: | :-----------------------------: | :--------------------------------------------------: | :-------------: | :---: | :-------------: | :------------------------: |
|     Conta      | Data do último processamento | Data da Próxima Execução |               Descrição                | Freqüência | Tipo de Freqüência |        Comentário/Ajuda         |    Servidor     | Importar Processo | Importe o Tipo do Processo | Dias para manter registro (log) |                         Nome                         |  Info de Senha  | Porta | Processar Agora |       Chave de Busca       |
| exampleAccount |                              |                          |    HDD Import Processor Description    |     10     |         M          |    HDD Import Processor Help    | www.example.com |       50000       |           50000            |                7                |                 HDD Import Processor                 | examplePassword |       |      false      |    HDD Import Processor    |
| exampleAccount |                              |                          | JMS Topic Import Processor Description |     10     |         M          | JMS Topic Import Processor Help | www.example.com |       50001       |           50001            |                7                | Human Readable name for - JMS Topic Import Processor | examplePassword | 61616 |      false      | JMS Topic Import Processor |

</div>

</div>
