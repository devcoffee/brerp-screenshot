<div id="d440276e1" class="table">

<div class="table-title">

Table 1. Versão da Lista de
Preço

</div>

<div class="table-contents">

|                                                                                                                        |                      |                |                      |                          |                     |       |                       |
| :--------------------------------------------------------------------------------------------------------------------: | :------------------: | :------------: | :------------------: | :----------------------: | :-----------------: | :---: | :-------------------: |
|                                                       Descrição                                                        | Esquema de Descontos | Lista de Preço | Lista de Preços Base | Versão da Lista de Preço |        Nome         | Criar |     Válido desde      |
|                                                                                                                        |         100          |      103       |         103          |           105            |     Export 2003     |   N   | 2003-01-01 00:00:00.0 |
| Current price list - we buy with 30% from TreeFarm and 40% from SeedFarm - Will get another 10% at the end of the year |         101          |      102       |                      |           102            |    Purchase 2001    |   N   | 2001-05-21 00:00:00.0 |
|         Our Standard price is 5% below list - the Limit price 10% - for all products - We add $5 on oak trees          |         100          |      101       |         102          |           101            |    Standard 2001    |       | 2001-01-01 00:00:00.0 |
| Current price list - we buy with 30% from TreeFarm and 40% from SeedFarm, 10% on Chemicals, 20% tools and 10% on patio |         101          |      102       |                      |           103            |    Purchase 2003    |   N   | 2003-01-21 00:00:00.0 |
|                                                Price list for customers                                                |         100          |      101       |         103          |           104            |    Standard 2003    |   N   | 2003-01-21 00:00:00.0 |
|                                                                                                                        |         100          |    1000002     |                      |         1000000          |     Vendas BRL      |   N   | 2014-01-01 00:00:00.0 |
|                                                                                                                        |         101          |    1000003     |         103          |         1000001          |     Compras BRL     |   N   | 2014-01-01 00:00:00.0 |
|                                                                                                                        |       1000000        |    1000005     |                      |         1000003          |        VENDA        |   N   | 2000-01-01 00:00:00.0 |
|                                                                                                                        |       1000000        |    1000004     |                      |         1000002          |       Padrão        |       | 2000-01-01 00:00:00.0 |
|                                                                                                                        |       1000000        |    1000006     |                      |         1000004          |       COMPRA        |   N   | 2000-01-01 00:00:00.0 |
|                                                                                                                        |       1000000        |    5000000     |       1000004        |         5000000          |      COMPRA $$      |   N   | 2018-01-01 00:00:00.0 |
|                                                                                                                        |       1000000        |    5000001     |       1000003        |         5000001          | 2018-01-11 15:03:07 |   N   | 2018-01-11 00:00:00.0 |
|                                                                                                                        |       1000000        |    5000002     |                      |         5000002          |    VENDA MARKUP     |   N   | 2018-03-01 00:00:00.0 |

</div>

</div>
