<div id="d399517e1" class="table">

<div class="table-title">

Table 1. NCM

</div>

<div class="table-contents">

|        |            |                                                                                                                   |         |                    |                |
| :----: | :--------: | :---------------------------------------------------------------------------------------------------------------: | :-----: | :----------------: | :------------: |
| Is DBN | Possui NVE |                                                     Descrição                                                     |   NCM   | Imposto Brasileiro | Chave de Busca |
| false  |   false    |                                               Tainhas (Mujil spp.)                                                | 1000191 |                    |   0303.79.43   |
| false  |   false    |                                               Do subitem 8471.60.24                                               | 1007983 |                    |   8471.49.34   |
| false  |   false    |                                \-Não cortadas em pedaços, frescas ou refrigeradas                                 | 1000076 |                    |   0207.32.00   |
| false  |   false    |                                                      Outras                                                       | 1000090 |                    |   0209.00.29   |
| false  |   false    |                                                      Outros                                                       | 1000091 |                    |   0209.00.90   |
| false  |   false    |                                                    \-Esqualos                                                     | 1000130 |                    |   0302.65.00   |
| false  |   false    |                                             \-Enguias (Anguilla spp.)                                             | 1000131 |                    |   0302.66.00   |
| false  |   false    |                                             \-Enguias (Anguilla spp.)                                             | 1000180 |                    |   0303.76.00   |
| false  |   false    |                                     De cherne-poveiro (Polyprion americanus)                                      | 1000220 |                    |   0304.20.40   |
| false  |   false    |                                                    De galinhas                                                    | 1000303 |                    |   0407.00.11   |
| false  |   false    |                                                      Outros                                                       | 1000304 |                    |   0407.00.19   |
| false  |   false    |                                                      Outros                                                       | 1000340 |                    |   0511.99.90   |
| false  |   false    |                          Com água salgada, sulfurada ou adicionada de outras substâncias                          | 1000407 |                    |   0711.30.10   |
| false  |   false    |                                             Sem casca, mesmo ralados                                              | 1000445 |                    |   0801.11.10   |
| false  |   false    |                                                     \- Outras                                                     | 1000495 |                    |   0810.90.00   |
| false  |   false    |                                                     BAUNILHA                                                      | 1000524 |                    |   0905.00.00   |
| false  |   false    |                                                  Para semeadura                                                   | 1000544 |                    |   1001.10.10   |
| false  |   false    |                                                  Para semeadura                                                   | 1000611 |                    |   1201.00.10   |
| false  |   false    |                                                       Outra                                                       | 1000612 |                    |   1201.00.90   |
| false  |   false    |                                              \-de fléolo dos prados                                               | 1000649 |                    |   1209.26.00   |
| false  |   false    |                                                     \-Outros                                                      | 1000703 |                    |   1404.90.00   |
| false  |   false    |                                                      Outros                                                       | 1000754 |                    |   1515.29.90   |
| false  |   false    |                                            \-Caviar e seus sucedâneos                                             | 1000801 |                    |   1604.30.00   |
| false  |   false    |                                                 Extrato de malte                                                  | 1000847 |                    |   1901.90.10   |
| false  |   false    |                          \-Outros produtos hortícolas e misturas de produtos hortícolas                           | 1000887 |                    |   2005.90.00   |
| false  |   false    |                                             Complementos alimentares                                              | 1000959 |                    |   2106.90.30   |
| false  |   false    |                                                     \- Outras                                                     | 1000967 |                    |   2202.90.00   |
| false  |   false    |                                                    Sal de mesa                                                    | 1001046 |                    |   2501.00.20   |
| false  |   false    | \-Em bruto ou em fragmentos irregulares, incluída a pedra-pomes triturada (cascalho de pedra-pomes ou “bimskies”) | 1001076 |                    |   2513.11.00   |
| false  |   false    |                                                      \-Outra                                                      | 1001077 |                    |   2513.19.00   |
| false  |   false    |                                                      Outros                                                       | 1001116 |                    |   2524.00.19   |
| false  |   false    |                                             Cinzas de origem vegetal                                              | 1001187 |                    |   2621.90.10   |
| false  |   false    |                                                      Coques                                                       | 1001196 |                    |   2704.00.10   |
| false  |   false    |                                                      Outras                                                       | 1001215 |                    |   2710.11.29   |
| false  |   false    |                                               Cianeto de hidrogênio                                               | 1001308 |                    |   2811.19.50   |
| false  |   false    |                                                     \-Outros                                                      | 1001316 |                    |   2811.29.00   |
| false  |   false    |                                                     \-Outros                                                      | 1001368 |                    |   2824.90.00   |
| false  |   false    |                                                    Periodatos                                                     | 1001454 |                    |   2829.90.40   |
| false  |   false    |                                                   Polissulfetos                                                   | 1001466 |                    |   2830.90.20   |
| false  |   false    |                                               Pirofosfato de zinco                                                | 1001531 |                    |   2835.39.30   |
| false  |   false    |                                                    De magnésio                                                    | 1001578 |                    |   2841.10.20   |
| false  |   false    |                                                    De bismuto                                                     | 1001579 |                    |   2841.10.30   |
| false  |   false    |                                                    Cobalto 60                                                     | 1001633 |                    |   2844.40.20   |
| false  |   false    |                                           Cloroetano (cloreto de etila)                                           | 1001689 |                    |   2903.11.20   |
| false  |   false    |                                              Cloroeptafluorpropanos                                               | 1001723 |                    |   2903.45.47   |
| false  |   false    |                                                   Nitropropanos                                                   | 1001782 |                    |   2904.20.20   |
| false  |   false    |                                     Tetraidrolinalol (3,7-dimetiloctan-3-ol)                                      | 1001827 |                    |   2905.19.94   |
| false  |   false    |                                                      Outros                                                       | 1001887 |                    |   2908.10.90   |
| false  |   false    |                                                      Outros                                                       | 1001889 |                    |   2908.20.90   |
| false  |   false    |                                                     Dieldrin                                                      | 1001946 |                    |   2910.90.20   |
| false  |   false    |                                                     Diacetila                                                     | 1001985 |                    |   2914.19.23   |
| false  |   false    |                                                   Pseudoiononas                                                   | 1001988 |                    |   2914.19.40   |
| false  |   false    |                                 Diacetato de etilenoglicol (diacetato de etileno)                                 | 1002048 |                    |   2915.39.63   |
| false  |   false    |                                                 Oleato de manitol                                                 | 1002097 |                    |   2916.15.11   |
| false  |   false    |                                               Sebacato de dibutila                                                | 1002136 |                    |   2917.13.22   |
| false  |   false    |                                                      Outros                                                       | 1002205 |                    |   2918.90.19   |
| false  |   false    |                                                  Metil Paration                                                   | 1002226 |                    |   2920.10.20   |
| false  |   false    |                                              Mucato de isometepteno                                               | 1002282 |                    |   2921.19.93   |
| false  |   false    |                                        Diaminotoluenos (toluilenodiaminas)                                        | 1002332 |                    |   2921.51.12   |
| false  |   false    |                                          Aminoantraquinonas e seus sais                                           | 1002388 |                    |   2922.39.10   |
| false  |   false    |                                                  Fluoroacetamida                                                  | 1002436 |                    |   2924.19.23   |
| false  |   false    |                                                    Talidomida                                                     | 1002488 |                    |   2925.19.10   |
| false  |   false    |                                          Isocianato de 3,4-diclorofenila                                          | 1002537 |                    |   2929.10.30   |
| false  |   false    |                                                      Forato                                                       | 1002588 |                    |   2930.90.51   |
| false  |   false    |                                           Hidróxido de trifenilestanho                                            | 1002631 |                    |   2931.00.44   |
| false  |   false    |                                     Óxido de fembutatin (óxido de fenbutatin)                                     | 1002632 |                    |   2931.00.45   |
| false  |   false    |                                             Cloridrato de amiodarona                                              | 1002680 |                    |   2932.99.91   |
| false  |   false    |                                            Cloridrato de difenoxilato                                             | 1002726 |                    |   2933.33.42   |
| false  |   false    |                                               Dicloreto de paraquat                                               | 1002775 |                    |   2933.39.84   |
| false  |   false    |                                                   Trimetoprima                                                    | 1002829 |                    |   2933.59.41   |
| false  |   false    |                                                     Oxazepam                                                      | 1002884 |                    |   2933.91.64   |
| false  |   false    |                                                     Pinazepam                                                     | 1002886 |                    |   2933.91.71   |
| false  |   false    |                                                     Fentiazac                                                     | 1002930 |                    |   2934.10.10   |
| false  |   false    |                                             Cloridrato de tiazolidina                                             | 1002931 |                    |   2934.10.20   |
| false  |   false    |                                                      Tiofeno                                                      | 1002981 |                    |   2934.99.41   |
| false  |   false    |                                                   Menotropinas                                                    | 1003065 |                    |   2937.19.40   |
| false  |   false    |                                                   Alilestrenol                                                    | 1003087 |                    |   2937.23.51   |
| false  |   false    |                                                      Outros                                                       | 1003166 |                    |   2939.91.19   |
| false  |   false    |                                                     Maltitol                                                      | 1003186 |                    |   2940.00.93   |
| false  |   false    |                                Embonato de espiramicina (pamoato de espiramicina)                                 | 1003231 |                    |   2941.90.51   |
| false  |   false    |                                               Nistatina e seus sais                                               | 1003233 |                    |   2941.90.61   |
| false  |   false    |                                     Interferon beta; peg interferon alfa-2-a                                      | 1003272 |                    |   3002.10.36   |
| false  |   false    |                                             Levodopa; alfa-metildopa                                              | 1003373 |                    |   3003.39.93   |
| false  |   false    |                                    Granisetron; tropisetrona ou seu cloridrato                                    | 1003381 |                    |   3003.40.50   |
| false  |   false    |                              Medicamento c/outs.tiocompostos organ.etc.exc.em doses                               | 1003428 |                    |   3003.90.69   |
| false  |   false    |                                            Hormônios corticosteróides                                             | 1003486 |                    |   3004.32.10   |
| false  |   false    |                                                      Outros                                                       | 1003488 |                    |   3004.32.90   |
| false  |   false    |                                    Pilocarpina, seu nitrato ou seu cloridrato                                     | 1003523 |                    |   3004.40.20   |
| false  |   false    |                                                 De polidiexanona                                                  | 1003608 |                    |   3006.10.11   |
| false  |   false    |                                           \-Desperdícios farmacêuticos                                            | 1003629 |                    |   3006.80.00   |
| false  |   false    |             Com teor de pentóxido de fósforo (P2O5) superior a 22 % mas não superior a 45 %, em peso              | 1003646 |                    |   3103.10.20   |
| false  |   false    |                                                      Outros                                                       | 1003716 |                    |   3206.11.19   |
| false  |   false    |                                           Indutos utilizados em pintura                                           | 1003766 |                    |   3214.10.20   |
| false  |   false    |                              Agua destilada aromat.e sol.aquosa de oleos essenciais                               | 1003798 |                    |   3301.90.30   |
| false  |   false    |                                       \-De linhita modificada quimicamente                                        | 1003859 |                    |   3404.10.00   |
| false  |   false    |                                Foguetes e cartuchos contra o granizo e semelhantes                                | 1003924 |                    |   3604.90.10   |
| false  |   false    |                                                      Outros                                                       | 1003962 |                    |   3702.51.90   |
| false  |   false    |                                         \-De largura não superior a 16mm                                          | 1003973 |                    |   3702.91.00   |
| false  |   false    |                                                     \-Outros                                                      | 1004015 |                    |   3805.90.00   |
| false  |   false    |                                             \- Para reprodução ofsete                                             | 1003984 |                    |   3705.10.00   |

</div>

</div>
