<div id="d533411e1" class="table">

<div class="table-title">

Table 1. Medida

</div>

<div class="table-contents">

|                   |                 |           |             |      |                   |                |                           |           |                          |                    |         |       |                     |
| :---------------: | :-------------: | :-------: | :---------: | :--: | :---------------: | :------------: | :-----------------------: | :-------: | :----------------------: | :----------------: | :-----: | :---: | :-----------------: |
| Calculation Class | Tipo de Projeto | Descrição | Real Manual | Nota | Measure Data Type | Tipo de Medida |           Nome            | Benchmark | Hierarquia de Relatórios | Cálculo de Medição | Medida  | Razão | Tipo de Solicitação |
|                   |                 |           |      0      |      |         S         |       C        |    Open Invoice Amount    |           |                          |        105         |   102   |       |                     |
|                   |                 |           |      0      |      |         T         |       Q        |  Service Requests (Time)  |           |                          |                    |   103   |       |         101         |
|                   |                 |           |      0      |      |         S         |       Q        | Service Requests (Status) |           |                          |                    |   104   |       |         101         |
|                   |                 |           |      0      |      |         T         |       C        |  Invoices Gross Revenue   |           |                          |        101         |   101   |       |                     |
|                   |                 |           |      0      |      |         S         |       C        |      Contas Receber       |           |                          |        105         | 5000000 |       |                     |
|                   |                 |           |      0      |      |         S         |       C        |    Numero de Clientes     |           |                          |        103         | 5000001 |       |                     |
|                   |                 |           |      0      |      |         S         |       C        |          Margem           |           |                          |        102         | 5000002 |       |                     |
|                   |                 |           |      0      |      |         S         |       C        |    Meta de Faturamento    |           |                          |      1500027       | 5000003 |       |                     |

</div>

</div>
