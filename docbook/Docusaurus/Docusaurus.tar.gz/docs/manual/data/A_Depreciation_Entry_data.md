<div id="d112135e1" class="table">

<div class="table-title">

Table 1. Entrada de
Depreciação

</div>

<div class="table-contents">

|                        |                 |                  |          |                   |                      |                       |                       |           |                   |                     |                     |          |         |                    |            |                    |                 |
| :--------------------: | :-------------: | :--------------: | :------: | :---------------: | :------------------: | :-------------------: | :-------------------: | :-------: | :---------------: | :-----------------: | :-----------------: | :------: | :-----: | :----------------: | :--------: | :----------------: | :-------------: |
| Entrada de Depreciação | Tipo de Entrada | Esquema Contábil | Moeda De | Tipo de Documento | Período (Ano Fiscal) |     Data da Conta     |   Data do Documento   | Descrição | Ação do Documento | Estado do Documento | Número do Documento | Aprovado | Lançado | Tipo de Lançamento | Processado |   Processado Em    | Processar Agora |
|        5000000         |       DEP       |     1000001      |   297    |      1000086      |       5000024        | 2018-01-23 00:00:00.0 | 2018-01-23 00:00:00.0 |           |        CL         |         CO          |       1000000       |   true   |  true   |         A          |    true    | 1516731903676.6765 |      false      |
|        5000001         |       DEP       |     1000001      |   297    |      1000086      |       5000025        | 2018-02-17 00:00:00.0 | 2018-02-17 00:00:00.0 |           |        CL         |         CO          |       1000001       |   true   |  true   |         A          |    true    | 1518897324094.9443 |      false      |
|        5000002         |       DEP       |     1000001      |   297    |      1000086      |       5000025        | 2018-02-19 00:00:00.0 | 2018-02-19 00:00:00.0 |           |        CL         |         CO          |       1000002       |   true   |  true   |         A          |    true    | 1519043087564.5647 |      false      |

</div>

</div>
