<div id="d166538e1" class="table">

<div class="table-title">

Table 1. Contra
Documento

</div>

<div class="table-contents">

|                  |                   |                          |           |                   |                        |        |          |                 |
| :--------------: | :---------------: | :----------------------: | :-------: | :---------------: | :--------------------: | :----: | :------: | :-------------: |
| Contra Documento | Tipo de Documento | Tipo de Contra-Documento | Descrição | Ação do Documento | Criar Contra-Documento | Válido |   Nome   | Processar Agora |
|       100        |        126        |           132            |           |                   |          true          |  true  | PO-\> SO |      false      |

</div>

</div>
