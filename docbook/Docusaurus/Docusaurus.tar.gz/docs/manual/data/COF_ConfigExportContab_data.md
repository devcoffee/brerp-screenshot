<div id="d131284e1" class="table">

<div class="table-title">

Table 1. Configuração de Exportação de Movimentos
Contábeis

</div>

<div class="table-contents">

|          |                    |                                                    |          |                 |                 |           |                    |                |
| :------: | :----------------: | :------------------------------------------------: | :------: | :-------------: | :-------------: | :-------: | :----------------: | :------------: |
| Elemento | Formato do Arquivo | Configuração de Exportação de Movimentos Contábeis | Elemento | Processar Agora | Tipo do Arquivo | Descrição | Caracter Separador | Chave de Busca |
| 1000000  |       UTF-8        |                      5000000                       | 1000000  |        N        |       PF        |           |                    |    1000001     |
| 1000000  |       UTF-8        |                      5000001                       | 1000000  |        N        |       PF        |           |                    |    1000002     |
| 1000000  |       UTF-8        |                      5000002                       | 1000000  |        N        |       SE        |           |         \-         |    1000003     |

</div>

</div>
