<div id="d174944e1" class="table">

<div class="table-title">

Table 1. Nível de Cobrança
\*\*

</div>

<div class="table-contents">

|        |                   |           |                                                                    |                              |
| :----: | :---------------: | :-------: | :----------------------------------------------------------------: | :--------------------------: |
| Idioma | Nível de Cobrança | Traduzida |                                Nota                                |      Texto de Impressão      |
| pt\_BR |        100        |   true    |       Please review your statement and submit due payments.        |          Statement           |
| pt\_BR |        101        |   true    |              Please pay the due invoices immediately               |        Dunning Letter        |
| es\_CO |      5000000      |   false   |                                                                    | Valores atrasado \> - 2 dias |
| es\_CO |        100        |   true    | Por favor revise su estado de cuenta y realice los pagos vencidos. |       Estado de Cuenta       |
| es\_CO |        101        |   true    |        Por favor pague las facturas vencidas inmediatamente        |      Carta de morosidad      |
| pt\_BR |      5000000      |   false   |                                                                    | Valores atrasado \> - 2 dias |

</div>

</div>
