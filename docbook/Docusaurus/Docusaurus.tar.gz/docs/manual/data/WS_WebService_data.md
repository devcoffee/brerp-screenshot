<div id="d559239e1" class="table">

<div class="table-title">

Table 1. Serviço
Web

</div>

<div class="table-contents">

|                                                                |                                                                                                                                                                                           |                             |                    |             |
| :------------------------------------------------------------: | :---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------: | :-------------------------: | :----------------: | :---------: |
|                           Descrição                            |                                                                                     Comentário/Ajuda                                                                                      |            Nome             |   Chave de Busca   | Serviço Web |
| Contributed by http://www.globalqss.com - implemented security | This web services are very generic - so it's necessary to configure the security layer in the web services security window to make them work. You can take a look to GardenWorld samples. | Model Oriented Web Services |   ModelADService   |    50001    |
|                                                                |                                                                                     Composite service                                                                                     |     CompositeInterface      | CompositeInterface |   200001    |

</div>

</div>
