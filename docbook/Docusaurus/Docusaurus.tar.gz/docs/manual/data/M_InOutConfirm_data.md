<div id="d419307e1" class="table">

<div class="table-title">

Table 1. Confirmação de
Envio/Recebimento

</div>

<div class="table-contents">

|                    |        |                  |                     |                 |                                               |                   |                     |                     |          |           |            |                                  |                     |                |            |                 |
| :----------------: | :----: | :--------------: | :-----------------: | :-------------: | :-------------------------------------------: | :---------------: | :-----------------: | :-----------------: | :------: | :-------: | :--------: | :------------------------------: | :-----------------: | :------------: | :--------: | :-------------: |
| Valor da Aprovação | Fatura | Núm. Confirmação | Tipo de Confirmação | Criar Embalagem |                   Descrição                   | Ação do Documento | Estado do Documento | Número do Documento | Aprovado | Cancelado | Em Disputa | Confirmação de Envio/Recebimento | Remessa/Recebimento | Estoque Físico | Processado | Processar Agora |
|                    |        |                  |         XC          |                 |                                               |        CO         |         DR          |      10000000       |  false   |   false   |   false    |               100                |         108         |                |   false    |      false      |
|                    |        |                  |         XC          |                 |                                               |        CO         |         DR          |       1000000       |  false   |   false   |   false    |             5000000              |       5000210       |                |   false    |      false      |
|                    |        |                  |         XC          |                 | SuperUser: Aprovado - 2018-02-12 14:27:21.782 |        CL         |         CO          |       1000001       |   true   |   false   |   false    |             5000001              |       5000270       |                |    true    |      false      |
|                    |        |                  |         XC          |                 | SuperUser: Aprovado - 2018-02-15 10:39:58.555 |        \--        |         CL          |       1000002       |   true   |   false   |   false    |             5000002              |       5000308       |                |    true    |      false      |
|                    |        |                  |         XV          |                 |                                               |        CO         |         DR          |       1000003       |  false   |   false   |   false    |             5000003              |       5000334       |                |   false    |      false      |
|                    |        |                  |         XC          |                 | SuperUser: Aprovado - 2018-03-05 09:56:40.322 |        \--        |         CL          |       1000004       |   true   |   false   |   false    |             5000004              |       5000355       |                |    true    |      false      |

</div>

</div>
