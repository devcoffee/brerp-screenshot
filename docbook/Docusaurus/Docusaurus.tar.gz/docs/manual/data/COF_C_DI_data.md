<div id="d124679e1" class="table">

<div class="table-title">

Table 1. Declaração de
Importação

</div>

<div class="table-contents">

|                          |                      |                                 |                               |                               |                                   |                     |                   |                |                               |       |                                      |
| :----------------------: | :------------------: | :-----------------------------: | :---------------------------: | :---------------------------: | :-------------------------------: | :-----------------: | :---------------: | :------------: | :---------------------------: | :---: | :----------------------------------: |
| Declaração de Importação | Código do Exportador | CNPJ do Adquirente/Encomendante | Data do Desembaraço Aduaneiro | Data de Registro do documento | Número do Documento de Importação | Forma de Importação | Via de Transporte | UF Desembaraço | UF do Adquirente/Encomendante | AFRMM |         Local de desembaraço         |
|         5000000          |       1000024        |         13823508000131          |     2017-12-04 00:00:00.0     |     2017-12-04 00:00:00.0     |            1720879216             |          3          |         4         |       SP       |              SP               |   0   | AEROPORTO INTERNACIONAL DE VIRACOPOS |

</div>

</div>
