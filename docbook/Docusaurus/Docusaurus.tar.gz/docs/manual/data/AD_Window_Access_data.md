<div id="d103885e1" class="table">

<div class="table-title">

Table 1. AD\_Window\_Access

</div>

<div class="table-contents">

|        |         |                   |
| :----: | :-----: | :---------------: |
| Perfil | Janela  | Escrita e Leitura |
|   0    |   105   |       true        |
|   0    |   340   |       true        |
|   0    |   335   |       true        |
|   0    |   295   |       true        |
|   0    |  53102  |       true        |
|   0    |   188   |       true        |
|   0    |  53059  |       true        |
|   0    |   240   |       true        |
|   0    |   249   |       true        |
|   0    |   346   |       true        |
|   0    |   298   |       true        |
|   0    | 200016  |       true        |
|   0    |   368   |       true        |
|   0    |  53019  |       true        |
|   0    |  53028  |       true        |
|   0    |   388   |       true        |
|   0    |  53054  |       true        |
|   0    |   377   |       true        |
|   0    |   384   |       true        |
|   0    |   365   |       true        |
|   0    |   193   |       true        |
|   0    |  53116  |       true        |
|   0    |  50006  |       true        |
|   0    |   110   |       true        |
|   0    | 1100000 |       true        |
|   0    |   243   |       true        |
|   0    | 200000  |       true        |
|   0    |   213   |       true        |
|   0    | 1120010 |       true        |
|   0    |  53117  |       true        |
|   0    |  53069  |       true        |
|   0    |   187   |       true        |
|   0    | 200001  |       true        |
|   0    | 200006  |       true        |
|   0    |   297   |       true        |
|   0    |  53015  |       true        |
|   0    |  53115  |       true        |
|   0    |  50003  |       true        |
|   0    |   127   |       true        |
|   0    |   263   |       true        |
|   0    |   380   |       true        |
|   0    |   381   |       true        |
|   0    |   189   |       true        |
|   0    |   108   |       true        |
|   0    |   180   |       true        |
|   0    |   385   |       true        |
|   0    | 200061  |       true        |
|   0    |   349   |       true        |
|   0    |   204   |       true        |
|   0    |   104   |       true        |
|   0    |   276   |       true        |
|   0    |   129   |       true        |
|   0    |  53067  |       true        |
|   0    |   151   |       true        |
|   0    | 200022  |       true        |
|   0    |  53152  |       true        |
|   0    | 200034  |       true        |
|   0    |   101   |       true        |
|   0    |   121   |       true        |
|   0    |   270   |       true        |
|   0    |  50002  |       true        |
|   0    | 200049  |       true        |
|   0    |   376   |       true        |
|   0    |   374   |       true        |
|   0    |   201   |       true        |
|   0    | 1000002 |       true        |
|   0    |   373   |       true        |
|   0    |   305   |       true        |
|   0    |   165   |       true        |
|   0    |  53027  |       true        |
|   0    |   200   |       true        |
|   0    |   389   |       true        |
|   0    |   379   |       true        |
|   0    |  53052  |       true        |
|   0    |   114   |       true        |
|   0    | 200044  |       true        |
|   0    | 1000010 |       true        |
|   0    |   312   |       true        |
|   0    |   226   |       true        |
|   0    | 1000008 |       true        |
|   0    |  53026  |       true        |
|   0    |  53003  |       true        |
|   0    | 200002  |       true        |
|   0    |   367   |       true        |
|   0    |   100   |       true        |
|   0    | 1500033 |       true        |
|   0    |   232   |       true        |
|   0    |   292   |       true        |
|   0    | 200015  |       true        |
|   0    |  50004  |       true        |
|   0    |  53025  |       true        |
|   0    |  53008  |       true        |
|   0    |   332   |       true        |
|   0    |   370   |       true        |
|   0    |   103   |       true        |
|   0    |  53124  |       true        |
|   0    |  53153  |       true        |
|   0    |   212   |       true        |
|   0    |   363   |       true        |
|   0    |  52000  |       true        |

</div>

</div>
