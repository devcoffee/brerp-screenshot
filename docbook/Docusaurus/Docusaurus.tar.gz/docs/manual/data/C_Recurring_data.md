<div id="d237218e1" class="table">

<div class="table-title">

Table 1. Recorrente

</div>

<div class="table-contents">

|        |        |           |         |                      |            |                              |                          |           |            |                    |             |                  |                |                 |                 |                     |                     |
| :----: | :----: | :-------: | :-----: | :------------------: | :--------: | :--------------------------: | :----------------------: | :-------: | :--------: | :----------------: | :---------: | :--------------: | :------------: | :-------------: | :-------------: | :-----------------: | :-----------------: |
| Fatura | Pedido | Pagamento | Projeto | Grupo de Recorrência | Recorrente | Data do último processamento | Data da Próxima Execução | Descrição | Freqüência | Tipo de Freqüência | Lote Diário | Comentário/Ajuda |      Nome      | Processar Agora | Tipo Recorrente | Máximo de Execuções | Execuções Restantes |
|        |        |           |         |                      |    100     |                              |  2003-08-31 00:00:00.0   |           |     1      |         M          |             |                  | Monthy Invoice |      false      |        I        |         10          |          0          |

</div>

</div>
