<div id="d461355e1" class="table">

<div class="table-title">

Table 1. Armazém

</div>

<div class="table-contents">

|          |                    |                               |             |                      |                  |                      |         |                   |                      |                           |                        |                      |
| :------: | :----------------: | :---------------------------: | :---------: | :------------------: | :--------------: | :------------------: | :-----: | :---------------: | :------------------: | :-----------------------: | :--------------------: | :------------------: |
| Endereço |     Descrição      | Não Permitir Estoque Negativo | Em Trânsito | Em poder de terceiro | Tipo de Depósito | Reservar Localizador | Armazém | Armazém de Origem |         Nome         | Classe de Reabastecimento | Separador de Elementos |    Chave de Busca    |
|   114    |                    |             false             |    false    |        false         |       OWN        |         101          |   103   |                   |     HQ Warehouse     |                           |           \-           |          HQ          |
|  50002   |                    |             false             |    true     |        false         |       OWN        |        50000         |  50000  |                   |      HQ Transit      |                           |           \*           |         HQT          |
|  50003   |     Furniture      |             false             |    false    |        false         |       OWN        |        50004         |  50001  |                   |      Furniture       |                           |           \*           |      Furniture       |
|  50004   |     Fertilizer     |             false             |    false    |        false         |       OWN        |        50001         |  50002  |                   |      Fertilizer      |                           |           \*           |      Fertilizer      |
|  50005   |                    |             false             |    false    |        false         |       OWN        |        50002         |  50003  |                   |     Store North      |                           |           \*           |     Store North      |
|  50006   |                    |             false             |    false    |        false         |       OWN        |        50003         |  50004  |                   |     Store South      |                           |           \*           |     Store South      |
|  50007   |                    |             false             |    false    |        false         |       OWN        |        50005         |  50005  |                   |      Store East      |                           |           \*           |      Store East      |
|  50008   |                    |             false             |    false    |        false         |       OWN        |        50006         |  50006  |                   |      Store West      |                           |           \*           |      Store West      |
|   126    |                    |             false             |    false    |        false         |       OWN        |         102          |   104   |                   |    Store Central     |                           |           \*           |    Store Central     |
|  50014   | Fertilizer Transit |             false             |    true     |        false         |       OWN        |        50007         |  50007  |                   |  Fertilizer Transit  |                           |           \*           |     FertilizerT      |
|  50015   | Furniture Transit  |             false             |    true     |        false         |       OWN        |        50008         |  50008  |                   |  Furniture Transit   |                           |           \*           |      FurnitureT      |
| 1000000  |                    |             false             |    false    |         true         |       3RD        |                      | 1000000 |                   |     Third Party      |                           |           \*           |     Third Party      |
| 5000011  |                    |             true              |    false    |        false         |       OWN        |       5000000        | 5000002 |                   |      MGS Padrao      |                           |           \*           |      MGS Padrao      |
| 5000012  |                    |             true              |    false    |        false         |       OWN        |       5000001        | 5000003 |                   |    Uso e Consumo     |                           |           \*           |    Uso e Consumo     |
| 5000013  |                    |             true              |    false    |        false         |       OWN        |                      | 5000004 |                   |       Revenda        |                           |           \*           |       Revenda        |
| 5000015  |                    |             true              |    false    |        false         |       OWN        |                      | 5000006 |                   |    Materia Prima     |                           |           \*           |    Materia Prima     |
| 5000026  |                    |             false             |    false    |        false         |       OWN        |       5000012        | 5000008 |                   |        TESTE         |                           |           \*           |       1000002        |
| 5000027  |                    |             false             |    false    |        false         |       OWN        |       5000013        | 5000010 |                   |      Armazém SC      |                           |           \*           |      Armazém SC      |
| 1000005  |                    |             false             |    false    |        false         |       OWN        |       1000000        | 1000002 |                   |        Padrão        |                           |           \*           |        Padrão        |
| 5000014  |                    |             false             |    false    |        false         |       OWN        |       5000006        | 5000005 |                   |       Fabrica        |                           |           \*           |       Fabrica        |
| 5000041  |                    |             false             |    false    |        false         |       OWN        |       5000014        | 5000011 |                   |   Armazem PR TESTE   |                           |           \*           |   Armazem PR TESTE   |
| 5000042  |                    |             false             |    false    |        false         |       OWN        |       5000015        | 5000013 |                   | Armazem MATRIZ TESTE |                           |           \*           | Armazem MATRIZ TESTE |
| 5000025  |                    |             false             |    false    |        false         |       OWN        |       5000010        | 5000007 |      5000013      |      Armazem PR      |                           |           \*           |      Armazem PR      |

</div>

</div>
