<div id="d132237e1" class="table">

<div class="table-title">

Table 1. Etiqueta

</div>

<div class="table-contents">

|         |               |          |                       |                        |                |           |                                    |             |      |         |                 |                 |            |            |        |                |
| :-----: | :-----------: | :------: | :-------------------: | :--------------------: | :------------: | :-------: | :--------------------------------: | :---------: | :--: | :-----: | :-------------: | :-------------: | :--------: | :--------: | :----: | :------------: |
| Emissão | É Reimpressão | Etiqueta | Número do Equipamento | Vencimento da Garantia | Is Replacement | Lote Núm. | Instância do Conjunto de Atributos | Localizador | Lote | Produto | Processar Agora | Processar Agora | Quantidade | Núm. Série | Estado | Chave de Busca |
|   OU    |               | 5000000  |                       |                        |                |           |                                    |             |      |         |      false      |                 |            |            |   GE   |    1000000     |
|   OU    |               | 5000001  |                       |                        |                |           |                                    |             |      |         |      false      |                 |            |            |   GE   |    1000001     |
|   OU    |               | 5000002  |                       |                        |                |           |                                    |             |      |         |      false      |                 |            |            |   GE   |    1000002     |
|   OU    |               | 5000003  |                       |                        |                |           |                                    |             |      |         |      false      |                 |            |            |   GE   |    1000003     |
|   OU    |               | 5000004  |                       |                        |                |           |                                    |             |      |         |      false      |                 |            |            |   GE   |    1000004     |
|   OU    |               | 5000005  |                       |                        |                |           |                                    |             |      |         |      false      |                 |            |            |   GE   |    1000005     |
|   OU    |               | 5000006  |                       |                        |                |           |                                    |             |      |         |      false      |                 |            |            |   GE   |    1000006     |
|   OU    |               | 5000007  |                       |                        |                |           |                                    |             |      |         |      false      |                 |            |            |   GE   |    1000007     |
|   OU    |               | 5000008  |                       |                        |                |           |                                    |             |      |         |      false      |                 |            |            |   GE   |    1000008     |
|   OU    |               | 5000009  |                       |                        |                |           |                                    |             |      |         |      false      |                 |            |            |   GE   |    1000009     |

</div>

</div>
