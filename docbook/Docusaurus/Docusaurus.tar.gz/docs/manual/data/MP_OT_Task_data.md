<div id="d412922e1" class="table">

<div class="table-title">

Table 1. Tarefa da
OT

</div>

<div class="table-contents">

|     |           |         |                                     |                   |              |            |           |        |
| :-: | :-------: | :-----: | :---------------------------------: | :---------------: | :----------: | :--------: | :-------: | :----: |
| UDM | Descrição | Duração | Cronograma de Manutenção Preventiva | Ordem de Trabalho | Tarefa da OT | Processado | Seqüência | Estado |
| 100 |   dddd    |    0    |                                     |      5000000      |   5000000    |   false    |    10     |   NS   |
| 100 |           |    0    |                                     |      5000017      |   5000001    |   false    |    10     |   NS   |
| 100 |           |    3    |                                     |      5000018      |   5000002    |    true    |    10     |   CO   |

</div>

</div>
