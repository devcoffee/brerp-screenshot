<div id="d459930e1" class="table">

<div class="table-title">

Table 1. M\_Substitute

</div>

<div class="table-contents">

|           |         |                                            |            |
| :-------: | :-----: | :----------------------------------------: | :--------: |
| Descrição | Produto |                    Nome                    | Substituto |
|           | 5000004 |  Prod Uso e Consumo – IPI/ST-Sem Crédito   |  5000003   |
|           | 5000017 |    Produto revenda importado – FCI/IPI     |  5000016   |
|           | 5000012 |    Produto Produzido A – IPI/NVE/SEM ST    |  5000006   |
|           | 5000019 |       Produto Revenda nacional – ST        |  5000018   |
|           | 5000020 |       Produto Revenda nacional – ST        |  5000018   |
|           | 5000022 | Produto Revenda Nacional – Deson. ICMS 30% |  5000021   |
|           | 5000023 |   Produto Rev Nacional – Deson. ICMS 30%   |  5000021   |

</div>

</div>
