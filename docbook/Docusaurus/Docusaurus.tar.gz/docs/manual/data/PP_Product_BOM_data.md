<div id="d539931e1" class="table">

<div class="table-title">

Table 1. LM %26
Fórmula

</div>

<div class="table-contents">

|             |          |           |       |                                    |                     |                  |                                    |                    |         |                     |                |                 |         |                       |            |                |
| :---------: | :------: | :-------: | :---: | :--------------------------------: | :-----------------: | :--------------: | :--------------------------------: | :----------------: | :-----: | :-----------------: | :------------: | :-------------: | :-----: | :-------------------: | :--------: | :------------: |
| Tipo de LDM | Usar LDM | Copiar de |  UDM  |             Descrição              | Número do Documento | Comentário/Ajuda | Instância do Conjunto de Atributos | Aviso de Alteração | Produto |        Nome         | LM %26 Fórmula | Processar Agora | Revisão |     Válido desde      | Válido até | Chave de Busca |
|      A      |    M     |           |  100  | 1 table, 4 Chairs and 1 Sun Screen |       1000000       |                  |                                    |                    |   145   | Patio Furniture Set |      145       |                 |         | 2003-01-21 20:05:02.0 |            |    PatioSet    |
|      A      |    M     |     N     |  100  |      Nice Chair for outdoors       |        50000        |                  |                                    |                    |   133   |     Patio Chair     |     50000      |      false      |         | 2007-09-22 00:00:00.0 |            |     PChair     |
|      A      |    M     |     N     |  100  |                                    |        50001        |                  |                                    |                    |  50000  |  Assembly Back Leg  |     50001      |      false      |         | 2007-09-22 00:00:00.0 |            |    PBackLeg    |
|      A      |    M     |     N     |  100  |    50 \# Bag of Lawn Fertilizer    |        50003        |                  |                                    |                    |   136   |   Fertilizer \#50   |     50004      |      false      |         | 2007-09-22 00:00:00.0 |            | Fertilizer\#50 |
|      A      |    M     |     N     |  100  |    70 \# Bag of Lawn Fertilizer    |        50004        |                  |                                    |                    |  50007  |   Fertilizer \#70   |     50005      |      false      |         | 2007-09-22 00:00:00.0 |            | Fertilizer\#70 |
|      A      |    M     |     N     | 50001 |                                    |        50005        |                  |                                    |                    |  50008  |   Lawn Fertilizer   |     50006      |      false      |         | 2007-09-22 00:00:00.0 |            |   Fertilizer   |
|      A      |    M     |     N     |  100  |                                    |        50002        |                  |                                    |                    |  50001  | Assembly Front Leg  |     50003      |      false      |         | 2007-09-22 00:00:00.0 |            |   PFrontLeg    |

</div>

</div>
