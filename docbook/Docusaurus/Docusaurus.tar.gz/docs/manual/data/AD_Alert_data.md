<div id="d110e1" class="table">

<div class="table-title">

Table 1. Alerta

</div>

<div class="table-contents">

|         |                        |                                                         |                          |                        |                 |                            |                           |                  |        |                   |
| :-----: | :--------------------: | :-----------------------------------------------------: | :----------------------: | :--------------------: | :-------------: | :------------------------: | :-----------------------: | :--------------: | :----: | :---------------: |
| Alerta  | Processador de Alertas |                   Mensagem de Alerta                    |    Assunto de Alerta     | Armazenamento em Nuvem |    Descrição    | Impor Segurança da Empresa | Impor Segurança de Função | Comentário/Ajuda | Válido |       Nome        |
|   100   |          100           | Check that the iDempiere Database has sufficient space: | iDempiere Database Space |                        | Oracle specific |           false            |           false           |                  |  true  | Space in Database |
| 5000000 |          100           |                          teste                          |          teste           |                        |                 |            true            |           true            |                  |  true  |       TEste       |

</div>

</div>
