<div id="d255307e1" class="table">

<div class="table-title">

Table 1. Lote
Diário

</div>

<div class="table-contents">

|          |                   |                   |           |                      |                       |                       |           |                   |                     |                     |                          |             |          |                    |            |                 |                |               |              |
| :------: | :---------------: | :---------------: | :-------: | :------------------: | :-------------------: | :-------------------: | :-------: | :---------------: | :-----------------: | :-----------------: | :----------------------: | :---------: | :------: | :----------------: | :--------: | :-------------: | :------------: | :-----------: | :----------: |
| Moeda De | Tipo de Documento | Valor de Controle | Copiar de | Período (Ano Fiscal) |     Data da Conta     |   Data do Documento   | Descrição | Ação do Documento | Estado do Documento | Número do Documento | Categoria de Razão Geral | Lote Diário | Aprovado | Tipo de Lançamento | Processado | Processar Agora | ID de Reversão | Crédito Total | Débito Total |
|   100    |        115        |         0         |           |         155          | 2002-08-10 00:00:00.0 | 2002-08-10 00:00:00.0 |   Test    |        CL         |         CO          |        1000         |           108            |     100     |  false   |         A          |    true    |      false      |                |      100      |     100      |

</div>

</div>
