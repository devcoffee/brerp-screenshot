<div id="d542071e1" class="table">

<div class="table-title">

Table 1. Histórico de
Solicitações

</div>

<div class="table-contents">

|       |        |                 |           |                      |        |                   |        |           |         |               |                      |            |            |         |                         |              |                     |         |                   |     |               |            |                        |                     |                      |                      |           |       |                           |             |                     |           |        |                         |                |                       |                  |
| :---: | :----: | :-------------: | :-------: | :------------------: | :----: | :---------------: | :----: | :-------: | :-----: | :-----------: | :------------------: | :--------: | :--------: | :-----: | :---------------------: | :----------: | :-----------------: | :-----: | :---------------: | :-: | :-----------: | :--------: | :--------------------: | :-----------------: | :------------------: | :------------------: | :-------: | :---: | :-----------------------: | :---------: | :-----------------: | :-------: | :----: | :---------------------: | :------------: | :-------------------: | :--------------: |
| Ativo | Perfil | Usuário/Contato | Atividade | Parceiro de Negócios | Fatura | Confidencialidade | Pedido | Pagamento | Projeto | Complete Plan | Data da próxima ação | Start Plan | Data Final | Elevado | Faturado (Nota Emitida) | Auto-Serviço | Remessa/Recebimento | Produto | Produto Utilizado | ARM | Colunas Nulas | Prioridade | Importância do Usuário | Quantidade Faturada | Quantidade Planejada | Quantidade Utilizada | Categoria | Grupo | Histórico de Solicitações | Solicitação | Tipo de Solicitação | Resolução | Estado | Representante de Vendas | Data de Início |        Resumo         | Estado da Tarefa |
|       |        |                 |           |                      |        |                   |        |           |         |               |                      |            |            |         |                         |              |                     |         |                   |     |               |            |                        |                     |                      |                      |           |  100  |            100            |     100     |                     |           |        |                         |                | Want my flower cut \! |                  |
|       |        |                 |           |                      |        |                   |        |           |         |               |                      |            |            |         |                         |              |                     |         |                   |     |   StartDate   |            |                        |                     |                      |                      |           |       |            101            |     100     |         100         |           |        |                         |                |                       |                  |

</div>

</div>
