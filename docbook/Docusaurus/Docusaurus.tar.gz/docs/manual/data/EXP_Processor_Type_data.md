<div id="d250398e1" class="table">

<div class="table-title">

Table 1. Tipo do Processador de
Exportação

</div>

<div class="table-contents">

|                                           |                                   |                                 |                                                    |                                                           |                                 |
| :---------------------------------------: | :-------------------------------: | :-----------------------------: | :------------------------------------------------: | :-------------------------------------------------------: | :-----------------------------: |
|                 Descrição                 | Tipo do Processador de Exportação |        Comentário/Ajuda         |                    Classe Java                     |                           Nome                            |         Chave de Busca          |
|    Adempiere HDD Export Processor Type    |               50000               |    HDD Export Processor Type    |  org.adempiere.process.rpl.exp.HDDExportProcessor  |                 HDD Export Processor Type                 |    HDD Export Processor Type    |
| Adempiere JMS Topic Export Processor Type |               50001               | JMS Topic Export Processor Type | org.adempiere.process.rpl.exp.TopicExportProcessor | Human Readable name for - JMS Topic Export Processor Type | JMS Topic Export Processor Type |

</div>

</div>
