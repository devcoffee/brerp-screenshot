<div id="d118827e1" class="table">

<div class="table-title">

Table 1. Código de Segurança do
Contribuinte

</div>

<div class="table-contents">

|                                     |                                      |        |              |                 |                |
| :---------------------------------: | :----------------------------------: | :----: | :----------: | :-------------: | :------------: |
| Código de Segurança do Contribuinte |              Descrição               | Padrão | Ambiente NFe |      Nome       | Chave de Busca |
|               5000000               | 891521cf-00f1-4a83-aa2d-1321685803cc | false  |      2       | CSC Homologação |     000001     |
|               5000001               | YBTBSL1NZFTYISXHGJRDTV3VGXCNN7T9OWW5 | false  |      2       | CSC Homologação |     000001     |

</div>

</div>
