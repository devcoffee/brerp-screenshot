<div id="d139066e1" class="table">

<div class="table-title">

Table 1. Registro diário (log) do Processador de
Contabilidade

</div>

<div class="table-contents">

|                |                              |                                                       |           |       |               |                 |                   |
| :------------: | :--------------------------: | :---------------------------------------------------: | :-------: | :---: | :-----------: | :-------------: | :---------------: |
| Dados Binários | Processador de Contabilidade | Registro diário (log) do Processador de Contabilidade | Descrição | Erro  |  Referência   |     Resumo      | Texto de Mensagem |
|                |             100              |                        5102515                        |           | false | \#6 - 00.126  | Logs deleted=0  |                   |
|                |             100              |                        5102558                        |           | false | \#10 - 00.104 | Logs deleted=0  |                   |
|                |           1000000            |                        5102609                        |           | false | \#0 - 00.520  | Logs deleted=0  |                   |
|                |           1000000            |                        5102621                        |           | false | \#5 - 00.113  | Logs deleted=0  |                   |
|                |           1000000            |                        5102627                        |           | false | \#8 - 00.132  | Logs deleted=0  |                   |
|                |           1000000            |                        5102629                        |           | false | \#9 - 00.118  | Logs deleted=0  |                   |
|                |             100              |                        5102637                        |           | false | \#13 - 00.165 | Logs deleted=0  |                   |
|                |           1000000            |                        5102642                        |           | false | \#15 - 00.90  | Logs deleted=0  |                   |
|                |           1000000            |                        5102644                        |           | false | \#16 - 00.88  | Logs deleted=0  |                   |
|                |           1000000            |                        5102646                        |           | false | \#17 - 00.138 | Logs deleted=0  |                   |
|                |           1000000            |                        5102693                        |           | false | \#41 - 00.95  | Logs deleted=0  |                   |
|                |           1000000            |                        5102731                        |           | false | \#0 - 00.673  | Logs deleted=0  |                   |
|                |           1000000            |                        5102759                        |           | false | \#0 - 00.635  | Logs deleted=0  |                   |
|                |             100              |                        5102762                        |           | false | \#1 - 00.128  | Logs deleted=0  |                   |
|                |           1000000            |                        5102801                        |           | false | \#21 - 00.93  | Logs deleted=0  |                   |
|                |           1000000            |                        5102813                        |           | false | \#0 - 00.582  | Logs deleted=13 |                   |
|                |             100              |                        5102814                        |           | false | \#0 - 00.617  | Logs deleted=13 |                   |
|                |           1000000            |                        5102815                        |           | false | \#1 - 00.149  | Logs deleted=0  |                   |
|                |             100              |                        5102816                        |           | false | \#1 - 00.118  | Logs deleted=0  |                   |
|                |           1000000            |                        5102861                        |           | false | \#24 - 00.141 | Logs deleted=0  |                   |
|                |           1000000            |                        5102863                        |           | false | \#25 - 00.141 | Logs deleted=0  |                   |
|                |           1000000            |                        5102870                        |           | false | \#28 - 00.115 | Logs deleted=0  |                   |
|                |             100              |                        5102872                        |           | false | \#29 - 00.118 | Logs deleted=0  |                   |
|                |             100              |                        5102883                        |           | false | \#35 - 00.200 | Logs deleted=0  |                   |
|                |           1000000            |                        5102887                        |           | false | \#37 - 00.97  | Logs deleted=0  |                   |
|                |             100              |                        5102888                        |           | false | \#37 - 00.112 | Logs deleted=0  |                   |
|                |           1000000            |                        5102889                        |           | false | \#38 - 00.122 | Logs deleted=0  |                   |
|                |             100              |                        5102892                        |           | false | \#39 - 00.117 | Logs deleted=0  |                   |
|                |           1000000            |                        5102895                        |           | false | \#41 - 00.88  | Logs deleted=0  |                   |
|                |           1000000            |                        5102924                        |           | false | \#55 - 00.99  | Logs deleted=0  |                   |
|                |           1000000            |                        5102925                        |           | false | \#0 - 00.472  | Logs deleted=66 |                   |
|                |             100              |                        5102928                        |           | false | \#1 - 00.124  | Logs deleted=0  |                   |
|                |           1000000            |                        5102519                        |           | false | \#0 - 00.293  | Logs deleted=0  |                   |
|                |             100              |                        5102521                        |           | false | \#1 - 00.145  | Logs deleted=0  |                   |
|                |           1000000            |                        5102560                        |           | false | \#9 - 00.102  | Logs deleted=0  |                   |
|                |           1000000            |                        5102567                        |           | false | \#11 - 00.73  | Logs deleted=0  |                   |
|                |             100              |                        5102571                        |           | false | \#12 - 00.250 | Logs deleted=0  |                   |
|                |           1000000            |                        5102575                        |           | false | \#13 - 00.97  | Logs deleted=0  |                   |
|                |           1000000            |                        5102584                        |           | false | \#15 - 00.80  | Logs deleted=0  |                   |
|                |           1000000            |                        5102592                        |           | false | \#17 - 00.123 | Logs deleted=0  |                   |
|                |             100              |                        5102610                        |           | false | \#0 - 00.520  | Logs deleted=0  |                   |
|                |             100              |                        5102628                        |           | false | \#8 - 00.113  | Logs deleted=0  |                   |
|                |           1000000            |                        5102638                        |           | false | \#13 - 00.164 | Logs deleted=0  |                   |
|                |             100              |                        5102639                        |           | false | \#14 - 00.99  | Logs deleted=0  |                   |
|                |             100              |                        5102643                        |           | false | \#16 - 00.85  | Logs deleted=0  |                   |
|                |             100              |                        5102694                        |           | false | \#41 - 00.96  | Logs deleted=0  |                   |
|                |           1000000            |                        5102695                        |           | false | \#42 - 00.105 | Logs deleted=0  |                   |
|                |             100              |                        5102698                        |           | false | \#43 - 00.87  | Logs deleted=0  |                   |
|                |             100              |                        5102732                        |           | false | \#0 - 00.673  | Logs deleted=0  |                   |
|                |             100              |                        5102760                        |           | false | \#0 - 00.635  | Logs deleted=0  |                   |
|                |             100              |                        5102802                        |           | false | \#21 - 00.101 | Logs deleted=0  |                   |
|                |             100              |                        5102817                        |           | false | \#2 - 00.108  | Logs deleted=0  |                   |
|                |             100              |                        5102864                        |           | false | \#25 - 00.141 | Logs deleted=0  |                   |
|                |             100              |                        5102866                        |           | false | \#26 - 00.108 | Logs deleted=0  |                   |
|                |             100              |                        5102869                        |           | false | \#28 - 00.108 | Logs deleted=0  |                   |
|                |           1000000            |                        5102884                        |           | false | \#35 - 00.199 | Logs deleted=0  |                   |
|                |           1000000            |                        5102885                        |           | false | \#36 - 00.183 | Logs deleted=0  |                   |
|                |             100              |                        5102890                        |           | false | \#38 - 00.118 | Logs deleted=0  |                   |
|                |           1000000            |                        5102891                        |           | false | \#39 - 00.115 | Logs deleted=0  |                   |
|                |             100              |                        5102893                        |           | false | \#40 - 00.110 | Logs deleted=0  |                   |
|                |             100              |                        5102899                        |           | false | \#43 - 00.94  | Logs deleted=0  |                   |
|                |             100              |                        5102901                        |           | false | \#44 - 00.88  | Logs deleted=0  |                   |
|                |           1000000            |                        5102903                        |           | false | \#45 - 00.115 | Logs deleted=0  |                   |
|                |           1000000            |                        5102906                        |           | false | \#46 - 00.119 | Logs deleted=0  |                   |
|                |             100              |                        5102926                        |           | false | \#0 - 00.472  | Logs deleted=66 |                   |
|                |             100              |                        5102520                        |           | false | \#0 - 00.296  | Logs deleted=0  |                   |
|                |           1000000            |                        5102566                        |           | false | \#12 - 00.527 | Logs deleted=0  |                   |
|                |           1000000            |                        5102574                        |           | false | \#14 - 00.57  | Logs deleted=0  |                   |
|                |             100              |                        5102577                        |           | false | \#15 - 00.98  | Logs deleted=0  |                   |
|                |           1000000            |                        5102611                        |           | false | \#0 - 00.321  | Logs deleted=1  |                   |
|                |             100              |                        5102630                        |           | false | \#9 - 00.115  | Logs deleted=0  |                   |
|                |           1000000            |                        5102640                        |           | false | \#14 - 00.99  | Logs deleted=0  |                   |
|                |             100              |                        5102696                        |           | false | \#42 - 00.192 | Logs deleted=0  |                   |
|                |             100              |                        5102733                        |           | false | \#1 - 00.138  | Logs deleted=0  |                   |
|                |             100              |                        5102737                        |           | false | \#3 - 00.117  | Logs deleted=0  |                   |
|                |           1000000            |                        5102743                        |           | false | \#6 - 00.125  | Logs deleted=0  |                   |
|                |           1000000            |                        5102746                        |           | false |  \#7 - 00.84  | Logs deleted=0  |                   |
|                |           1000000            |                        5102761                        |           | false | \#1 - 00.128  | Logs deleted=0  |                   |
|                |           1000000            |                        5102803                        |           | false | \#22 - 00.112 | Logs deleted=0  |                   |
|                |             100              |                        5102806                        |           | false | \#23 - 00.119 | Logs deleted=0  |                   |
|                |           1000000            |                        5102809                        |           | false | \#25 - 00.114 | Logs deleted=0  |                   |
|                |           1000000            |                        5102818                        |           | false | \#2 - 00.119  | Logs deleted=0  |                   |
|                |           1000000            |                        5102865                        |           | false | \#26 - 00.107 | Logs deleted=0  |                   |
|                |           1000000            |                        5102871                        |           | false | \#29 - 00.115 | Logs deleted=0  |                   |
|                |           1000000            |                        5102873                        |           | false | \#30 - 00.167 | Logs deleted=0  |                   |
|                |             100              |                        5102886                        |           | false | \#36 - 00.193 | Logs deleted=0  |                   |
|                |           1000000            |                        5102894                        |           | false | \#40 - 00.130 | Logs deleted=0  |                   |
|                |           1000000            |                        5102927                        |           | false | \#1 - 00.120  | Logs deleted=0  |                   |
|                |             100              |                        5102929                        |           | false | \#2 - 00.114  | Logs deleted=0  |                   |
|                |           1000000            |                        5102522                        |           | false | \#1 - 00.149  | Logs deleted=0  |                   |
|                |             100              |                        5102569                        |           | false | \#13 - 00.96  | Logs deleted=0  |                   |
|                |           1000000            |                        5102586                        |           | false | \#17 - 00.98  | Logs deleted=0  |                   |
|                |             100              |                        5102612                        |           | false | \#0 - 00.321  | Logs deleted=1  |                   |
|                |             100              |                        5102631                        |           | false | \#10 - 00.112 | Logs deleted=0  |                   |
|                |             100              |                        5102641                        |           | false | \#15 - 00.91  | Logs deleted=0  |                   |
|                |           1000000            |                        5102699                        |           | false | \#44 - 00.161 | Logs deleted=0  |                   |
|                |           1000000            |                        5102734                        |           | false | \#1 - 00.143  | Logs deleted=0  |                   |
|                |             100              |                        5102736                        |           | false | \#2 - 00.148  | Logs deleted=0  |                   |
|                |             100              |                        5102740                        |           | false | \#4 - 00.106  | Logs deleted=0  |                   |
|                |           1000000            |                        5102741                        |           | false | \#5 - 00.116  | Logs deleted=0  |                   |

</div>

</div>
