<div id="d543319e1" class="table">

<div class="table-title">

Table 1. Estado

</div>

<div class="table-contents">

|           |                  |                      |        |                  |                    |                    |                     |                |                 |        |           |                      |                  |                |
| :-------: | :--------------: | :------------------: | :----: | :--------------: | :----------------: | :----------------: | :-----------------: | :------------: | :-------------: | :----: | :-------: | :------------------: | :--------------: | :------------: |
| Descrição | Comentário/Ajuda | Estado de Fechamento | Padrão | Fechamento Final | Estado de Abertura | Web Pode Atualizar |        Nome         | Próximo Estado | Status Category | Estado | Seqüência | Tempo Limite em Dias | Atualizar Estado | Chave de Busca |
|           |                  |         true         | false  |       true       |       false        |       false        |     Final Close     |                |       100       |  103   |     9     |          0           |                  |     Final      |
|           |                  |        false         |  true  |      false       |        true        |        true        |        Open         |                |       100       |  100   |     1     |          0           |                  |      Open      |
|           |                  |        false         | false  |      false       |        true        |        true        | Waiting on customer |      102       |       100       |  101   |     2     |          5           |       100        |    Waiting     |
|           |                  |         true         | false  |      false       |       false        |        true        |       Closed        |      103       |       100       |  102   |     3     |          1           |       100        |     Closed     |

</div>

</div>
