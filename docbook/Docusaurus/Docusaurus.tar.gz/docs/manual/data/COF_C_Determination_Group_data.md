<div id="d124705e1" class="table">

<div class="table-title">

Table 1. Grupo de
Apuração

</div>

<div class="table-contents">

|               |                   |                     |                        |         |
| :-----------: | :---------------: | :-----------------: | :--------------------: | :-----: |
| Classificação | Grupo de Apuração | Código da Impreesão | Descrição da Impressão | Imposto |
|      EES      |      5000000      |         1.1         |  Entrada para Revenda  | 1106000 |

</div>

</div>
