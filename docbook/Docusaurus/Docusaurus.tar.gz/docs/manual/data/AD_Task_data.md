<div id="d84238e1" class="table">

<div class="table-title">

Table 1. Tarefa
SO

</div>

<div class="table-contents">

|                          |                   |           |                                             |                  |                                                              |                       |                   |                                                   |
| :----------------------: | :---------------: | :-------: | :-----------------------------------------: | :--------------: | :----------------------------------------------------------: | :-------------------: | :---------------: | :-----------------------------------------------: |
| Nível de Acesso de Dados | Ajuda de Contexto | Tarefa SO |                  Descrição                  | Tipo de Entidade |                       Comentário/Ajuda                       | Processar no Servidor |       Nome        |                    Comando SO                     |
|            4             |                   |    102    | Displays the version of the default Java VM |        D         | The java version used by the application might be different. |         false         |   Java Version    |                   java -version                   |
|            4             |                   |    103    |         Export (save) the database          |        D         |               Run this command from the server               |         false         |  Database export  |    @BRERP\_HOME@@/@utils@/@RUN\_DBExport.@sh@     |
|            4             |                   |    104    |            Transfer the database            |        D         |               Run this command from the server               |         false         | Database transfer | @BRERP\_HOME@@/@utils@/@RUN\_ExampleTransfer.@sh@ |

</div>

</div>
