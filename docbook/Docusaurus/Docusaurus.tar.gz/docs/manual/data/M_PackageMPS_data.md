<div id="d439803e1" class="table">

<div class="table-title">

Table 1. Package
MPS

</div>

<div class="table-contents">

|                          |                      |               |           |               |        |             |                              |           |             |       |            |           |                      |      |         |
| :----------------------: | :------------------: | :-----------: | :-------: | :-----------: | :----: | :---------: | :--------------------------: | :-------: | :---------: | :---: | :--------: | :-------: | :------------------: | :--: | :-----: |
| Criar linhas a partir de | UDM para Comprimento | UDM para Peso | Descrição | Peso Estimado | Altura | Comprimento | Principal No de Rastreamento | Embalagem | Package MPS | Preço | Processado | Seqüência | Núm. de Rastreamento | Peso | Largura |
|                          |                      |               |           |               |        |             |                              |  5000000  |   5000000   |       |   false    |    10     |                      |  0   |         |

</div>

</div>
