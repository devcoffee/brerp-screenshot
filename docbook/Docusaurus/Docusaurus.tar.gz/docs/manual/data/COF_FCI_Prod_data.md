<div id="d132091e1" class="table">

<div class="table-title">

Table 1. COF\_FCI\_Prod\_ID

</div>

<div class="table-contents">

|                  |                    |                          |                        |                                   |                                 |                       |                       |         |
| :--------------: | :----------------: | :----------------------: | :--------------------: | :-------------------------------: | :-----------------------------: | :-------------------: | :-------------------: | :-----: |
| COF\_FCILine\_ID | COF\_FCI\_Prod\_ID | Índice de Nacionalização |       Número FCI       | Valor Médio de Conteúdo Importado | Valor Médio Venda Interestadual |        Do dia         |        Ao dia         | Produto |
|     5000013      |      5000000       |          203.55          | 1111111111111111111111 |              179.12               |              88.00              | 2018-01-01 00:00:00.0 | 2018-01-31 00:00:00.0 | 5000002 |

</div>

</div>
