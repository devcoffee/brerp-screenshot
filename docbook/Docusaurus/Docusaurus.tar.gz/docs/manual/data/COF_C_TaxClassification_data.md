<div id="d128731e1" class="table">

<div class="table-title">

Table 1. Classificação
Fiscal

</div>

<div class="table-contents">

|                      |                  |         |                 |                       |                       |                |
| :------------------: | :--------------: | :-----: | :-------------: | :-------------------: | :-------------------: | :------------: |
| Classificação Fiscal | Simples Nacional | Imposto | Processar Agora |     Válido desde      |      Válido até       | Chave de Busca |
|       5000006        |      false       | 1106000 |      false      | 2018-01-08 00:00:00.0 | 2019-12-31 00:00:00.0 |      ICMS      |
|       5000007        |      false       | 1106003 |      false      | 2018-01-08 00:00:00.0 | 2019-12-31 00:00:00.0 |      IPI       |
|       5000010        |      false       | 1106001 |      false      | 2018-01-08 00:00:00.0 | 2019-12-31 00:00:00.0 |      PIS       |
|       5000011        |      false       | 1106002 |      false      | 2018-01-08 00:00:00.0 | 2019-12-31 00:00:00.0 |     COFINS     |
|       5000008        |      false       | 1106023 |      false      | 2018-01-08 00:00:00.0 | 2019-12-31 00:00:00.0 |      FCP       |
|       5000009        |      false       | 1106019 |      false      | 2018-01-08 00:00:00.0 | 2019-12-31 00:00:00.0 |   ICMS DIFAL   |

</div>

</div>
