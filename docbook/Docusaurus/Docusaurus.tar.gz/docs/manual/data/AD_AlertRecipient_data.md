<div id="d74e1" class="table">

<div class="table-title">

Table 1. Destinatário do Alerta

</div>

<div class="table-contents">

|        |                        |        |                 |
| :----: | :--------------------: | :----: | :-------------: |
| Alerta | Destinatário do Alerta | Perfil | Usuário/Contato |
|  100   |          100           |   0    |                 |

</div>

</div>
