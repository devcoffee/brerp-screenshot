<div id="d416976e1" class="table">

<div class="table-title">

Table 1. Tipo de
Custo

</div>

<div class="table-contents">

|                                                                     |                  |               |                    |
| :-----------------------------------------------------------------: | :--------------: | :-----------: | :----------------: |
|                              Descrição                              | Comentário/Ajuda | Tipo de Custo |        Nome        |
| Note: Default Cost Type - define additional for Plan, History, etc. |                  |      100      |      Default       |
|                                                                     |                  |    1000000    | Custo Fatura Média |
|                                                                     |                  |    5000000    |      PC Médio      |

</div>

</div>
