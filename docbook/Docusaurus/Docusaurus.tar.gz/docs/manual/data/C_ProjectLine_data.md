<div id="d236963e1" class="table">

<div class="table-title">

Table 1. Linha de
Projeto

</div>

<div class="table-contents">

|                    |                         |        |                  |         |                    |                  |                 |                   |           |                    |                |                     |          |            |                      |         |          |                 |                  |                 |                      |            |
| :----------------: | :---------------------: | :----: | :--------------: | :-----: | :----------------: | :--------------: | :-------------: | :---------------: | :-------: | :----------------: | :------------: | :-----------------: | :------: | :--------: | :------------------: | :-----: | :------: | :-------------: | :--------------: | :-------------: | :------------------: | :--------: |
| Valor Comprometido | Quantidade Comprometida | Pedido | Pedido de Compra | Projeto | Emissão do Projeto | Linha de Projeto | Fase de Projeto | Tarefa de Projeto | Descrição | Formação de Preços | Valor Faturado | Quantidade Faturada | Impresso | Linha Núm. | Categoria de Produto | Produto | Produção | Valor Planejado | Margem Planejada | Preço Planejado | Quantidade Planejada | Processado |
|         0          |            0            |        |                  |   101   |                    |       101        |                 |                   |           |         Y          |       0        |          0          |   true   |     10     |         105          |   132   |          |       600       |        0         |       60        |          10          |   false    |

</div>

</div>
