<div id="d434800e1" class="table">

<div class="table-title">

Table 1. Localizador

</div>

<div class="table-contents">

|                      |        |             |              |         |                     |                       |                    |                    |                    |
| :------------------: | :----: | :---------: | :----------: | :-----: | :-----------------: | :-------------------: | :----------------: | :----------------: | :----------------: |
| Parceiro de Negócios | Padrão | Localizador | Locator Type | Armazém | Prioridade Relativa |    Chave de Busca     |    Corredor (X)    |    Estante (Y)     |     Nível (Z)      |
|                      |  true  |     101     |              |   103   |         50          |  Default HQ Locator   |         0          |         0          |         0          |
|                      |  true  |    50000    |              |  50000  |         50          |      HQ Transit       |     HQ Transit     |     HQ Transit     |     HQ Transit     |
|                      |  true  |    50003    |              |  50004  |         50          |      Store South      |    Store South     |    Store South     |    Store South     |
|                      |  true  |    50002    |              |  50003  |         50          |      Store North      |    Store North     |    Store North     |    Store North     |
|                      |  true  |    50001    |              |  50002  |         50          |      Fertilizer       |     Fertilizer     |     Fertilizer     |     Fertilizer     |
|                      |  true  |    50004    |              |  50001  |         50          |       Furniture       |     Furniture      |     Furniture      |     Furniture      |
|                      |  true  |    50005    |              |  50005  |         50          |      Store East       |     Store East     |     Store East     |     Store East     |
|                      |  true  |    50006    |              |  50006  |         50          |      Store West       |     Store West     |     Store West     |     Store West     |
|                      |  true  |     102     |              |   104   |         50          | Default Store Locator |         0          |         0          |         0          |
|                      |  true  |    50007    |              |  50007  |         50          |  Fertilizer Transit   | Fertilizer Transit | Fertilizer Transit | Fertilizer Transit |
|                      |  true  |    50008    |              |  50008  |         50          |   Furniture Transit   | Furniture Transit  | Furniture Transit  | Furniture Transit  |
|                      |  true  |   1000000   |              | 1000002 |         50          |        Padrão         |         0          |         0          |         0          |
|                      |  true  |   5000000   |              | 5000002 |         50          |      MGS Padrao       |         1          |         1          |         1          |
|                      | false  |   1000003   |              | 1000002 |         50          |      2 \* 2 \* 2      |         2          |         2          |         2          |
|                      | false  |   1000002   |              | 1000002 |         50          |      1 \* 1 \* 0      |         1          |         1          |         0          |
|                      | false  |   1000001   |              | 1000002 |         50          |      1 \* 0 \* 0      |         1          |         0          |         0          |
|                      | false  |   5000001   |              | 5000003 |         50          |         UC01          |         a          |         b          |         c          |
|                      | false  |   5000003   |              | 5000003 |         50          |         UC02          |         1          |         2          |         3          |
|                      | false  |   5000005   |              | 5000004 |         50          |         RV02          |         A          |         B          |         C          |
|                      | false  |   5000007   |              | 5000005 |         50          |         FB02          |         2          |         3          |         4          |
|                      | false  |   5000008   |              | 5000006 |         50          |         MP01          |         1          |         1          |         1          |
|                      | false  |   5000009   |              | 5000006 |         50          |         MP02          |         1          |         2          |         1          |
|                      |  true  |   5000004   |              | 5000004 |         50          |         RV01          |         1          |         2          |         3          |
|                      | false  |   5000012   |              | 5000008 |         50          |        1000001        |         a          |         a          |         a          |
|                      |  true  |   5000010   |              | 5000007 |         50          |      Armazem PR       |         a          |         a          |         a          |
|                      |  true  |   5000013   |              | 5000010 |         50          |      Armazém SC       |         a          |         a          |         a          |
|                      |  true  |   5000006   |              | 5000005 |         50          |         FB01          |         1          |         2          |         3          |
|                      | false  |   5000014   |              | 5000011 |         50          |        1000003        |         1          |         1          |         1          |
|                      | false  |   5000015   |              | 5000013 |         50          |        1000004        |         1          |         1          |         1          |

</div>

</div>
