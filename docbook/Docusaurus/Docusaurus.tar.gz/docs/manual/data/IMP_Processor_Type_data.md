<div id="d319041e1" class="table">

<div class="table-title">

Table 1. Importe o Tipo do
Processo

</div>

<div class="table-contents">

|                                           |                                 |                            |                                                   |                                                           |                                 |
| :---------------------------------------: | :-----------------------------: | :------------------------: | :-----------------------------------------------: | :-------------------------------------------------------: | :-----------------------------: |
|                 Descrição                 |        Comentário/Ajuda         | Importe o Tipo do Processo |                    Classe Java                    |                           Nome                            |         Chave de Busca          |
|    Adempiere HDD Import Processor Type    |    HDD Import Processor Type    |           50000            | org.adempiere.server.rpl.imp.FileImportProcessor  |                 HDD Import Processor Type                 |    HDD Import Processor Type    |
| Adempiere JMS Topic Import Processor Type | JMS Topic Import Processor Type |           50001            | org.adempiere.server.rpl.imp.TopicImportProcessor | Human Readable name for - JMS Topic Import Processor Type | JMS Topic Import Processor Type |

</div>

</div>
