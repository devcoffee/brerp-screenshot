<div id="d86576e1" class="table">

<div class="table-title">

Table 1. Aba Definida pelo
Usuário

</div>

<div class="table-contents">

|     |                           |                              |             |                      |                                                                                                                                                                                                                                                                             |                 |                 |                       |        |                           |
| :-: | :-----------------------: | :--------------------------: | :---------: | :------------------: | :-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------: | :-------------: | :-------------: | :-------------------: | :----: | :-----------------------: |
| Aba | Aba Definida pelo Usuário | Janela Definida pelo Usuário | Observações |      Descrição       |                                                                                                                              Comentário/Ajuda                                                                                                                               | Só Multi Linhas | Somente Leitura | Layout em Linha Única |  Nome  | Lógica Somente de Leitura |
| 186 |          5000000          |           5000000            |             | Cabeçalho de Pedido  |                                            A Aba "Cabeçalho de Pedido" define os parâmetros de um Pedido. Alterar a Organização, Parceiro de Negócios, Armazém, Data Prometida, etc. atualiza estes valores em todas as linhas.                                             |      false      |      false      |         true          | Pedido |                           |
| 263 |          5000001          |           5000002            |             |  Fatura de Cliente   |                                                                        A Aba "Fatura" define os parâmetros de uma Fatura gerada para um Parceiro de Negócios. Ela se constitue em contas a receber.                                                                         |      false      |      false      |         true          | Fatura |                           |
| 290 |          5000002          |           5000003            |             | Fatura de Fornecedor | A Aba "Fatura" define os parâmetros de uma Fatura gerada por um Parceiro de Negócios. Ela se constitue em contas a pagar. When generating a Receipt, the receipt document type of the purchase is used - or if not used/defined the default Material Receipt Document type. |      false      |      false      |         true          | Fatura |                           |

</div>

</div>
