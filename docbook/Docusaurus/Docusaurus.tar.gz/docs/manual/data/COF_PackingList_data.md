<div id="d134377e1" class="table">

<div class="table-title">

Table 1. Lista de
Embarque

</div>

<div class="table-contents">

|        |           |              |          |            |                    |                     |          |                    |                   |                           |                   |                           |              |            |       |                  |                |                 |                   |              |      |                              |                            |           |                     |            |                     |     |         |                |                 |                         |        |        |
| :----: | :-------: | :----------: | :------: | :--------: | :----------------: | :-----------------: | :------: | :----------------: | :---------------: | :-----------------------: | :---------------: | :-----------------------: | :----------: | :--------: | :---: | :--------------: | :------------: | :-------------: | :---------------: | :----------: | :--: | :--------------------------: | :------------------------: | :-------: | :-----------------: | :--------: | :-----------------: | :-: | :-----: | :------------: | :-------------: | :---------------------: | :----: | :----: |
| Chassi | Motorista | Equipamentos | Impresso | KM Entrada | Km Fim Equipamento | Km Ini. Equipamento | KM Saída | Número Habilitação | Região de Entrega | Data de Lista de Embarque | Lista de Embarque | Tipo da Lista de Embarque | Peso Entrada | Peso Saída | Placa | Porteiro Entrada | Porteiro Saída | Processar Agora | Situação Embarque | Estado Placa | Tara | Tolerância Adicional Entrada | Tolerância Adicional Saída | Descrição | Número do Documento | Data Final | Transação de Vendas | CPF | LinkURL | Transportadora | Processar Agora |     Data de Início      | Estado |  Peso  |
|        |           |              |  false   |            |                    |                     |          |                    |                   |   2017-12-01 00:00:00.0   |      5000000      |             D             |              |            |       |                  |                |                 |        AP         |              |      |                              |                            |           |       1000000       |            |        true         |     |         |                |      false      | 2018-01-15 11:35:01.725 |   OP   | 886.00 |
|        |           |              |  false   |            |                    |                     |          |                    |                   |   2017-12-13 00:00:00.0   |      5000001      |             P             |              |            |       |                  |                |                 |        AP         |              |      |                              |                            |           |       1000001       |            |        true         |     |         |                |      false      | 2018-01-15 13:14:47.992 |   OP   |  75.0  |
|        |           |              |  false   |            |                    |                     |          |                    |                   |   2018-01-24 00:00:00.0   |      5000002      |             P             |              |            |       |                  |                |                 |        AP         |              |      |                              |                            |           |       1000002       |            |        true         |     |         |                |      false      | 2018-01-24 11:30:04.472 |   OP   | 16.500 |
|        |           |              |  false   |            |                    |                     |          |                    |                   |   2018-03-02 00:00:00.0   |      5000003      |             D             |              |            |       |                  |                |                 |        AP         |              |      |                              |                            |           |       1000003       |            |        true         |     |         |                |      false      | 2018-03-02 08:18:27.749 |   OP   | 141.0  |

</div>

</div>
