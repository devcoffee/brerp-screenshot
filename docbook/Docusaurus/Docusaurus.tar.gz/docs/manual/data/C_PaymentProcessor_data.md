<div id="d227479e1" class="table">

<div class="table-title">

Table 1. Processador de
Pagamento

</div>

<div class="table-contents">

|             |            |                          |                    |               |                      |                         |                 |                    |             |           |                |          |            |                     |                          |                      |                           |                     |              |                      |                                    |                |             |                |                |                                                    |                   |
| :---------: | :--------: | :----------------------: | :----------------: | :-----------: | :------------------: | :---------------------: | :-------------: | :----------------: | :---------: | :-------: | :------------: | :------: | :--------: | :-----------------: | :----------------------: | :------------------: | :-----------------------: | :-----------------: | :----------: | :------------------: | :--------------------------------: | :------------: | :---------: | :------------: | :------------: | :------------------------------------------------: | :---------------: |
| Aceita AMEX | Aceita ATM | Aceita Cheque Eletrônico | Aceita Corporativo | Aceita Diners | Aceita Débito Direto | Aceitar Depósito Direto | Aceita Discover | Aceita Master Card | Aceita Visa | Seqüência | Conta Bancária | Moeda De | Comissão % | Custo por transação | Processador de Pagamento |      Descrição       |  Endereço do Hospedeiro   | Porta do Hospedeiro | Valor Mínimo |         Nome         | Classe de Processador de Pagamento | Endereço Proxy | Proxy logon | Senha do Proxy | Porta do Proxy | Exige o Código de Verificação do Cartão de Crédito | Tipo de Transação |
|    true     |   false    |          false           |        true        |     true      |        false         |          false          |      true       |        true        |    true     |           |                |   100    |    2.35    |         0.3         |           100            | VeriSign PayFlow Pro | test-payflow.verisign.com |         443         |      0       | MoneyBank DirectCash | org.compiere.model.PP\_PayFlowPro  |                |             |                |                |                       false                        |                   |
|    false    |   false    |          false           |       false        |     false     |        false         |          false          |      false      |       false        |    false    |           |                |   100    |     0      |          0          |           101            |                      | test-payflow.verisign.com |         443         |      0       |   Optimal Payments   |   org.compiere.model.PP\_Optimal   |                |             |                |       0        |                       false                        |                   |

</div>

</div>
