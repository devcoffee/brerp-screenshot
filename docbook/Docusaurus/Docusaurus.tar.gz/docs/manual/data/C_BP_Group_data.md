<div id="d144808e1" class="table">

<div class="table-title">

Table 1. Grupo de
Parceiros

</div>

<div class="table-contents">

|                  |                    |          |                    |           |                      |        |                      |                |                    |                            |                          |                                     |                    |                |
| :--------------: | :----------------: | :------: | :----------------: | :-------: | :------------------: | :----: | :------------------: | :------------: | :----------------: | :------------------------: | :----------------------: | :---------------------------------: | :----------------: | :------------: |
| Cor de Impressão | Grupo de Parceiros | Cobrança | Observar Crédito % | Descrição | Inform. Confidencial | Padrão | Esquema de Descontos | Lista de Preço |        Nome        | Esquema de Descontos do PC | Lista de Preço de Compra | Tolerância de Coincidência de Preço | Base de Prioridade | Chave de Busca |
|                  |        103         |          |                    |           |        false         |  true  |                      |                | Standard Customers |                            |                          |                                     |                    |    Standard    |
|       110        |        104         |          |                    |           |        false         | false  |                      |                |      Vendors       |                            |                          |                                     |                    |     Vendor     |
|       117        |        105         |          |         0          |           |        false         | false  |                      |                |       Staff        |                            |                          |                                     |                    |     Staff      |
|                  |      1000000       |          |                    |           |        false         |  true  |                      |                |       Padrão       |                            |                          |                                     |         S          |     Padrão     |
|       100        |      1000001       |          |         0          |           |        false         | false  |                      |    1000004     |      Clientes      |                            |                          |                  0                  |         S          |    Clientes    |
|       100        |      1000002       |          |         0          |           |        false         | false  |                      |    1000004     |    Fornecedores    |                            |                          |                  0                  |         S          |  Fornecedores  |
|       100        |      1000003       |          |         0          |           |        false         | false  |                      |    1000004     |    Funcionários    |                            |                          |                  0                  |         S          |  Funcionários  |
|       100        |      1000004       |          |         0          |           |        false         | false  |                      |    1000004     |   Representantes   |                            |                          |                  0                  |         S          | Representantes |

</div>

</div>
