<div id="d419285e1" class="table">

<div class="table-title">

Table 1. Frete

</div>

<div class="table-contents">

|      |          |        |                |                    |       |                |      |      |                       |
| :--: | :------: | :----: | :------------: | :----------------: | :---: | :------------: | :--: | :--: | :-------------------: |
| País | Moeda De | Região | Valor do Frete | Categoria de Frete | Frete | Transportadora | Para | Para |     Válido desde      |
|      |   100    |        |       20       |        100         |  100  |      100       |      |      | 2003-06-01 00:00:00.0 |

</div>

</div>
