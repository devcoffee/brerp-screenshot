<div id="d140537e1" class="table">

<div class="table-title">

Table 1. Atividade
\*\*

</div>

<div class="table-contents">

|        |           |           |                  |           |           |
| :----: | :-------: | :-------: | :--------------: | :-------: | :-------: |
| Idioma | Atividade | Descrição | Comentário/Ajuda | Traduzida |   Nome    |
| es\_CO |  1000000  |           |                  |   false   |  Padrão   |
| es\_CO |  5000000  |           |                  |   false   | Industria |
| es\_CO |  5000001  |           |                  |   false   | Comercial |
| pt\_BR |  1000000  |           |                  |   false   |  Padrão   |
| pt\_BR |  5000000  |           |                  |   false   | Industria |
| pt\_BR |  5000001  |           |                  |   false   | Comercial |

</div>

</div>
