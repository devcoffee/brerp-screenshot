<div id="d106734e1" class="table">

<div class="table-title">

Table 1. Processador de Fluxo de
Trabalho

</div>

<div class="table-contents">

|           |                                  |                         |                              |                          |           |                               |                                 |                           |                 |                  |            |
| :-------: | :------------------------------: | :---------------------: | :--------------------------: | :----------------------: | :-------: | :---------------------------: | :-----------------------------: | :-----------------------: | :-------------: | :--------------: | :--------: |
| Programar | Processador de Fluxo de Trabalho | Alerta sobre Prioridade | Data do último processamento | Data da Próxima Execução | Descrição | Dias de Alerta de Inatividade | Dias para manter registro (log) |           Nome            | Processar Agora | Dias de Lembrete | Supervisor |
|  200004   |               100                |                         |   2019-01-31 15:50:53.015    | 2019-01-31 17:50:53.015  |           |               0               |                7                | System Workflow Processor |      false      |        0         |     0      |

</div>

</div>
