<div id="d402888e1" class="table">

<div class="table-title">

Table 1. Taxa
Definição

</div>

<div class="table-contents">

|                      |        |                   |                   |                 |                               |                    |                   |                        |        |           |        |                     |                              |      |                     |                     |                         |                |     |                             |                   |                |                    |                   |         |                     |      |                       |                |
| :------------------: | :----: | :---------------: | :---------------: | :-------------: | :---------------------------: | :----------------: | :---------------: | :--------------------: | :----: | :-------: | :----: | :-----------------: | :--------------------------: | :--: | :-----------------: | :-----------------: | :---------------------: | :------------: | :-: | :-------------------------: | :---------------: | :------------: | :----------------: | :---------------: | :-----: | :-----------------: | :--: | :-------------------: | :------------: |
| Parceiro de Negócios | Cidade | Tipo de Documento | Cidade de Destino | Indicador da IE | COF\_TaxDefinition\_Group\_ID | Incentivos Fiscais | Cod. Regime Trib. | Cod. Regime Trib. (PN) | Região | Descrição | Manual | Transação de Vendas | Categoria do Parceiro (CFOP) | CFOP | Grupo de Tributação | Grupo de Tributação | Substituição Tributária | Mensagem Legal | NCM | Categoria do Produto (CFOP) | Origem do Produto | Taxa Definição | Imposto Brasileiro | Tipo de Transação | Produto | Prioridade Relativa | Para |     Válido desde      | Chave de Busca |
|                      |        |                   |                   |        9        |                               |                    |                   |                        |  465   |           | false  |          Y          |                              |      |                     |                     |            B            |                |     |                             |                   |    5000000     |                    |        END        |         |         80          | 453  | 2001-01-01 00:00:00.0 |    1000000     |
|                      |        |      5000061      |                   |                 |                               |                    |                   |                        |        |           | false  |          Y          |                              |      |                     |                     |            B            |    5000000     |     |                             |                   |    5000001     |                    |                   |         |        1050         |      | 2018-01-01 00:00:00.0 |    1000001     |

</div>

</div>
