<div id="d156588e1" class="table">

<div class="table-title">

Table 1. Finalidade
\*\*

</div>

<div class="table-contents">

|        |            |           |           |                                                             |
| :----: | :--------: | :-------: | :-------: | :---------------------------------------------------------: |
| Idioma | Finalidade | Descrição | Traduzida |                            Nome                             |
| pt\_BR |    100     |           |   true    |                         Bank Charge                         |
| pt\_BR |    101     |           |   true    |                      Commissions Paid                       |
| pt\_BR |  5000257   |           |   false   |       3.1.1.10.01.001 RECEITA VENDAS PRODUTO ACABADO        |
| es\_CO |  5000257   |           |   false   |       3.1.1.10.01.001 RECEITA VENDAS PRODUTO ACABADO        |
| pt\_BR |  5000258   |           |   false   |          3.1.1.10.02.001 RECEITA VENDA DE SERVICOS          |
| es\_CO |  5000258   |           |   false   |          3.1.1.10.02.001 RECEITA VENDA DE SERVICOS          |
| pt\_BR |  5000259   |           |   false   |            4.1.1.10.01.001 MATERIA PRIMA-DIRETO             |
| es\_CO |  5000259   |           |   false   |            4.1.1.10.01.001 MATERIA PRIMA-DIRETO             |
| pt\_BR |  5000260   |           |   false   |        4.1.1.10.02.001 MATERIAL DE EMBALAGEM-DIRETO         |
| es\_CO |  5000260   |           |   false   |        4.1.1.10.02.001 MATERIAL DE EMBALAGEM-DIRETO         |
| pt\_BR |  5000261   |           |   false   |          4.1.1.10.03.001 MATERIAL USO GERAL-DIRETO          |
| es\_CO |  5000261   |           |   false   |          4.1.1.10.03.001 MATERIAL USO GERAL-DIRETO          |
| pt\_BR |  5000262   |           |   false   |         4.1.1.10.03.002 MATERIAL SECUNDARIO-DIRETO          |
| es\_CO |  5000262   |           |   false   |         4.1.1.10.03.002 MATERIAL SECUNDARIO-DIRETO          |
| pt\_BR |  5000263   |           |   false   |           4.1.1.10.04.001 MATERIA PRIMA IMPORTADA           |
| es\_CO |  5000263   |           |   false   |           4.1.1.10.04.001 MATERIA PRIMA IMPORTADA           |
| pt\_BR |  5000264   |           |   false   |        4.1.1.10.06.001 CUSTO DOS SERVICOS PRESTADOS         |
| es\_CO |  5000264   |           |   false   |        4.1.1.10.06.001 CUSTO DOS SERVICOS PRESTADOS         |
| pt\_BR |  5000265   |           |   false   |               4.1.1.20.02.001 AJUSTE DE CUSTO               |
| es\_CO |  5000265   |           |   false   |               4.1.1.20.02.001 AJUSTE DE CUSTO               |
| pt\_BR |  5000266   |           |   false   |           4.1.1.40.02.001 DESPESAS DE IMPORTACAO            |
| es\_CO |  5000266   |           |   false   |           4.1.1.40.02.001 DESPESAS DE IMPORTACAO            |
| pt\_BR |  5000267   |           |   false   |            4.1.1.40.02.002 CORRETAGEM DE CAMBIO             |
| es\_CO |  5000267   |           |   false   |            4.1.1.40.02.002 CORRETAGEM DE CAMBIO             |
| pt\_BR |  5000268   |           |   false   |            4.1.1.40.02.003 FRETES INTERNACIONAIS            |
| es\_CO |  5000268   |           |   false   |            4.1.1.40.02.003 FRETES INTERNACIONAIS            |
| pt\_BR |  5000269   |           |   false   |                  4.1.1.40.02.004 DEMURRAGE                  |
| pt\_BR |  5000025   |           |   false   |              3.2.2.10.01.006 AJUSTE DE ESTOQUE              |
| es\_CO |  5000269   |           |   false   |                  4.1.1.40.02.004 DEMURRAGE                  |
| pt\_BR |  5000270   |           |   false   |           4.1.1.40.03.001 DESPESAS DE EXPORTACAO            |
| es\_CO |  5000270   |           |   false   |           4.1.1.40.03.001 DESPESAS DE EXPORTACAO            |
| pt\_BR |  5000271   |           |   false   |           4.1.1.40.04.001 FRETES E CARRETOS - IDL           |
| es\_CO |  5000271   |           |   false   |           4.1.1.40.04.001 FRETES E CARRETOS - IDL           |
| pt\_BR |  5000272   |           |   false   |        4.1.1.40.04.002 DESPESAS COM CAMINHOES - IDL         |
| es\_CO |  5000272   |           |   false   |        4.1.1.40.04.002 DESPESAS COM CAMINHOES - IDL         |
| pt\_BR |  5000273   |           |   false   |        4.1.1.40.04.003 DESPESAS COM LOCOMOCAO - IDL         |
| es\_CO |  5000273   |           |   false   |        4.1.1.40.04.003 DESPESAS COM LOCOMOCAO - IDL         |
| pt\_BR |  5000274   |           |   false   |           4.1.1.40.04.004 ENERGIA ELETRICA - IDL            |
| es\_CO |  5000274   |           |   false   |           4.1.1.40.04.004 ENERGIA ELETRICA - IDL            |
| pt\_BR |  5000275   |           |   false   |          4.1.1.40.04.005 VIAGENS E ESTADIAS - IDL           |
| es\_CO |  5000275   |           |   false   |          4.1.1.40.04.005 VIAGENS E ESTADIAS - IDL           |
| pt\_BR |  5000276   |           |   false   |    4.1.1.40.04.006 RETIFICA DE MATERIAIS DIVERSOS - IDL     |
| es\_CO |    101     |           |   true    |                     Comisiones Pagadas                      |
| es\_CO |  5000276   |           |   false   |    4.1.1.40.04.006 RETIFICA DE MATERIAIS DIVERSOS - IDL     |
| pt\_BR |  5000277   |           |   false   |       4.1.1.40.04.007 FERRAMENTAS PEQUENO VALOR - IDL       |
| es\_CO |  5000277   |           |   false   |       4.1.1.40.04.007 FERRAMENTAS PEQUENO VALOR - IDL       |
| pt\_BR |  5000278   |           |   false   |          4.1.1.40.04.008 MATERIAL DE CONSUMO - IDL          |
| es\_CO |  5000278   |           |   false   |          4.1.1.40.04.008 MATERIAL DE CONSUMO - IDL          |
| pt\_BR |  5000279   |           |   false   |   4.1.1.40.04.009 MANUTENCAO E REPAROS EQUIPS INDS - IDL    |
| es\_CO |  5000279   |           |   false   |   4.1.1.40.04.009 MANUTENCAO E REPAROS EQUIPS INDS - IDL    |
| pt\_BR |  5000280   |           |   false   |    4.1.1.40.04.010 SEGURO DE MERCADORIAS-DESPESAS - IDL     |
| es\_CO |  5000280   |           |   false   |    4.1.1.40.04.010 SEGURO DE MERCADORIAS-DESPESAS - IDL     |
| pt\_BR |  5000281   |           |   false   |  4.1.1.40.04.011 DESPESAS COM INSTRUMENTOS MUSICAIS - IDL   |
| es\_CO |  5000281   |           |   false   |  4.1.1.40.04.011 DESPESAS COM INSTRUMENTOS MUSICAIS - IDL   |
| pt\_BR |  5000286   |           |   false   |                 4.1.1.40.04.016 AGUA - IDL                  |
| es\_CO |  5000286   |           |   false   |                 4.1.1.40.04.016 AGUA - IDL                  |
| pt\_BR |  5000287   |           |   false   |          4.1.1.40.04.017 DESPESA COM OFICINA - IDL          |
| es\_CO |  5000287   |           |   false   |          4.1.1.40.04.017 DESPESA COM OFICINA - IDL          |
| pt\_BR |  5000288   |           |   false   | 4.1.1.40.04.018 SERVICOS PROFISSIONAIS PESSOA FISICA - IDL  |
| es\_CO |  5000288   |           |   false   | 4.1.1.40.04.018 SERVICOS PROFISSIONAIS PESSOA FISICA - IDL  |
| pt\_BR |  5000289   |           |   false   |        4.1.1.40.04.019 PARTICIPACAO EM FEIRAS - IDL         |
| es\_CO |  5000289   |           |   false   |        4.1.1.40.04.019 PARTICIPACAO EM FEIRAS - IDL         |
| pt\_BR |  5000290   |           |   false   |         4.1.1.40.04.020 CURSOS E TREINAMENTOS - IDL         |
| es\_CO |  5000290   |           |   false   |         4.1.1.40.04.020 CURSOS E TREINAMENTOS - IDL         |
| pt\_BR |  5000291   |           |   false   |                4.1.1.40.04.021 LEASING - IDL                |
| es\_CO |  5000291   |           |   false   |                4.1.1.40.04.021 LEASING - IDL                |
| pt\_BR |  5000292   |           |   false   |          4.1.1.40.04.022 ALUGUEIS / LOCACOES - IDL          |
| es\_CO |  5000292   |           |   false   |          4.1.1.40.04.022 ALUGUEIS / LOCACOES - IDL          |
| pt\_BR |  5000293   |           |   false   |       4.1.1.40.04.023 MANUTENCAO E REPAROS PDI - INDL       |
| es\_CO |  5000293   |           |   false   |       4.1.1.40.04.023 MANUTENCAO E REPAROS PDI - INDL       |
| pt\_BR |  5000294   |           |   false   |          4.1.1.40.04.024 ETIQUETAS ESPECIAIS-INDL           |
| es\_CO |  5000294   |           |   false   |          4.1.1.40.04.024 ETIQUETAS ESPECIAIS-INDL           |
| pt\_BR |  5000295   |           |   false   |   4.1.1.40.04.025 MATERIAIS PARA GRAVACAO EM VIDROS-INDL    |
| es\_CO |  5000295   |           |   false   |   4.1.1.40.04.025 MATERIAIS PARA GRAVACAO EM VIDROS-INDL    |
| pt\_BR |  5000296   |           |   false   |   4.1.1.40.04.026 LOCACAO DE MAQUINAS E EQUIPAMENTOS-INDL   |
| es\_CO |  5000296   |           |   false   |   4.1.1.40.04.026 LOCACAO DE MAQUINAS E EQUIPAMENTOS-INDL   |
| pt\_BR |  5000297   |           |   false   |         4.1.1.40.04.027 MANUAL DO PROPRIETARIO-INDL         |
| es\_CO |  5000297   |           |   false   |         4.1.1.40.04.027 MANUAL DO PROPRIETARIO-INDL         |
| pt\_BR |  5000298   |           |   false   |              4.1.1.40.04.028 ARMAZENAGEM-INDL               |
| es\_CO |  5000298   |           |   false   |              4.1.1.40.04.028 ARMAZENAGEM-INDL               |
| pt\_BR |  5000299   |           |   false   |           4.1.1.40.05.001 SERVICOS DE ENGENHARIA            |
| es\_CO |  5000299   |           |   false   |           4.1.1.40.05.001 SERVICOS DE ENGENHARIA            |
| pt\_BR |  5000300   |           |   false   | 4.1.1.40.05.002 SERVICOS DE VALIDACAO E TESTES COM VEICULOS |
| es\_CO |  5000300   |           |   false   | 4.1.1.40.05.002 SERVICOS DE VALIDACAO E TESTES COM VEICULOS |
| pt\_BR |  5000301   |           |   false   |  4.1.1.40.05.003 SERVICOS MONTAGEM E REPARACAO DE VEICULOS  |
| es\_CO |  5000301   |           |   false   |  4.1.1.40.05.003 SERVICOS MONTAGEM E REPARACAO DE VEICULOS  |
| pt\_BR |  5000282   |           |   false   |             4.1.1.40.04.012 HOMOLOGACOES - IDL              |
| es\_CO |  5000282   |           |   false   |             4.1.1.40.04.012 HOMOLOGACOES - IDL              |
| pt\_BR |  5000283   |           |   false   |          4.1.1.40.04.013 MANUTENCAO PREDIAL - IDL           |
| es\_CO |  5000283   |           |   false   |          4.1.1.40.04.013 MANUTENCAO PREDIAL - IDL           |
| pt\_BR |  5000284   |           |   false   |              4.1.1.40.04.014 COMBUSTIVEL - IDL              |
| es\_CO |  5000284   |           |   false   |              4.1.1.40.04.014 COMBUSTIVEL - IDL              |
| pt\_BR |  5000285   |           |   false   |               4.1.1.40.04.015 TELEFONE - IDL                |
| es\_CO |  5000285   |           |   false   |               4.1.1.40.04.015 TELEFONE - IDL                |
| pt\_BR |  5000302   |           |   false   |        4.1.1.40.05.004 SERVICOS DE CARGA E DESCARGA         |
| es\_CO |  5000302   |           |   false   |        4.1.1.40.05.004 SERVICOS DE CARGA E DESCARGA         |
| pt\_BR |  5000303   |           |   false   |   4.1.1.40.05.005 SERVICOS PROFISSIONAIS PESSOA JURIDICA    |
| es\_CO |  5000303   |           |   false   |   4.1.1.40.05.005 SERVICOS PROFISSIONAIS PESSOA JURIDICA    |
| pt\_BR |  5000304   |           |   false   |          4.2.1.10.01.001 FRETES E CARRETOS - COML           |
| es\_CO |  5000304   |           |   false   |          4.2.1.10.01.001 FRETES E CARRETOS - COML           |

</div>

</div>
