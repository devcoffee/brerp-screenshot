<div id="d80108e1" class="table">

<div class="table-title">

Table 1. Índice da
Tabela

</div>

<div class="table-contents">

|          |        |                  |           |                  |                  |                 |              |       |                                     |                 |                          |
| :------: | :----: | :--------------: | :-------: | :--------------: | :--------------: | :-------------: | :----------: | :---: | :---------------------------------: | :-------------: | :----------------------: |
| Mensagem | Tabela | Índice da Tabela | Descrição | Tipo de Entidade | Comentário/Ajuda | Criar Restrição | Coluna Chave | Único |                Nome                 | Processar Agora | Excluir índice da tabela |
|          |  539   |      200000      |           |        D         |                  |      false      |    false     | true  |          a\_asset\_uu\_idx          |      false      |                          |
|          | 53123  |      200001      |           |        D         |                  |      false      |    false     | true  |       a\_asset\_acct\_uu\_idx       |      false      |                          |
|          | 53137  |      200002      |           |        D         |                  |      false      |    false     | true  |     a\_asset\_addition\_uu\_idx     |      false      |                          |
|          | 53133  |      200003      |           |        D         |                  |      false      |    false     | true  |      a\_asset\_change\_uu\_idx      |      false      |                          |
|          | 53269  |      200004      |           |        D         |                  |      false      |    false     | true  |      a\_asset\_class\_uu\_idx       |      false      |                          |
|          |  541   |      200005      |           |        D         |                  |      false      |    false     | true  |     a\_asset\_delivery\_uu\_idx     |      false      |                          |
|          | 53127  |      200006      |           |        D         |                  |      false      |    false     | true  |     a\_asset\_disposed\_uu\_idx     |      false      |                          |
|          |  542   |      200007      |           |        D         |                  |      false      |    false     | true  |      a\_asset\_group\_uu\_idx       |      false      |                          |
|          | 53130  |      200008      |           |        D         |                  |      false      |    false     | true  |   a\_asset\_group\_acct\_uu\_idx    |      false      |                          |
|          | 53132  |      200009      |           |        D         |                  |      false      |    false     | true  |    a\_asset\_info\_fin\_uu\_idx     |      false      |                          |
|          | 53135  |      200010      |           |        D         |                  |      false      |    false     | true  |    a\_asset\_info\_ins\_uu\_idx     |      false      |                          |
|          | 53134  |      200011      |           |        D         |                  |      false      |    false     | true  |    a\_asset\_info\_lic\_uu\_idx     |      false      |                          |
|          | 53136  |      200012      |           |        D         |                  |      false      |    false     | true  |    a\_asset\_info\_oth\_uu\_idx     |      false      |                          |
|          | 53131  |      200013      |           |        D         |                  |      false      |    false     | true  |    a\_asset\_info\_tax\_uu\_idx     |      false      |                          |
|          | 53270  |      200014      |           |        D         |                  |      false      |    false     | true  |     a\_asset\_product\_uu\_idx      |      false      |                          |
|          |  540   |      200015      |           |        D         |                  |      false      |    false     | true  |    a\_asset\_retirement\_uu\_idx    |      false      |                          |
|          | 53275  |      200016      |           |        D         |                  |      false      |    false     | true  |      a\_asset\_reval\_uu\_idx       |      false      |                          |
|          | 53119  |      200017      |           |        D         |                  |      false      |    false     | true  |   a\_asset\_reval\_entry\_uu\_idx   |      false      |                          |
|          | 53120  |      200018      |           |        D         |                  |      false      |    false     | true  |   a\_asset\_reval\_index\_uu\_idx   |      false      |                          |
|          | 53122  |      200019      |           |        D         |                  |      false      |    false     | true  |      a\_asset\_split\_uu\_idx       |      false      |                          |
|          | 53126  |      200020      |           |        D         |                  |      false      |    false     | true  |      a\_asset\_spread\_uu\_idx      |      false      |                          |
|          | 53128  |      200021      |           |        D         |                  |      false      |    false     | true  |     a\_asset\_transfer\_uu\_idx     |      false      |                          |
|          | 53276  |      200022      |           |        D         |                  |      false      |    false     | true  |       a\_asset\_type\_uu\_idx       |      false      |                          |
|          | 53138  |      200023      |           |        D         |                  |      false      |    false     | true  |       a\_asset\_use\_uu\_idx        |      false      |                          |
|          | 53112  |      200024      |           |        D         |                  |      false      |    false     | true  |      a\_depreciation\_uu\_idx       |      false      |                          |
|          | 53129  |      200025      |           |        D         |                  |      false      |    false     | true  |   a\_depreciation\_build\_uu\_idx   |      false      |                          |
|          | 53125  |      200026      |           |        D         |                  |      false      |    false     | true  | a\_depreciation\_conventi\_uu\_idx  |      false      |                          |
|          | 53121  |      200027      |           |        D         |                  |      false      |    false     | true  |   a\_depreciation\_entry\_uu\_idx   |      false      |                          |
|          | 53115  |      200028      |           |        D         |                  |      false      |    false     | true  |    a\_depreciation\_exp\_uu\_idx    |      false      |                          |
|          | 53118  |      200029      |           |        D         |                  |      false      |    false     | true  | a\_depreciation\_forecast\_uu\_idx  |      false      |                          |
|          | 53124  |      200030      |           |        D         |                  |      false      |    false     | true  |  a\_depreciation\_method\_uu\_idx   |      false      |                          |
|          | 53113  |      200031      |           |        D         |                  |      false      |    false     | true  | a\_depreciation\_table\_de\_uu\_idx |      false      |                          |
|          | 53114  |      200032      |           |        D         |                  |      false      |    false     | true  | a\_depreciation\_table\_he\_uu\_idx |      false      |                          |
|          | 53116  |      200033      |           |        D         |                  |      false      |    false     | true  | a\_depreciation\_workfile\_uu\_idx  |      false      |                          |
|          | 53273  |      200034      |           |        D         |                  |      false      |    false     | true  |       a\_fundingmode\_uu\_idx       |      false      |                          |
|          | 53274  |      200035      |           |        D         |                  |      false      |    false     | true  |    a\_fundingmode\_acct\_uu\_idx    |      false      |                          |
|          |  651   |      200036      |           |        D         |                  |      false      |    false     | true  |      a\_registration\_uu\_idx       |      false      |                          |
|          |  652   |      200037      |           |        D         |                  |      false      |    false     | true  |  a\_registrationattribute\_uu\_idx  |      false      |                          |
|          |  715   |      200038      |           |        D         |                  |      false      |    false     | true  |   a\_registrationproduct\_uu\_idx   |      false      |                          |
|          |  653   |      200039      |           |        D         |                  |      false      |    false     | true  |    a\_registrationvalue\_uu\_idx    |      false      |                          |
|          |  717   |      200040      |           |        D         |                  |      false      |    false     | true  |       ad\_accesslog\_uu\_idx        |      false      |                          |
|          |  594   |      200041      |           |        D         |                  |      false      |    false     | true  |         ad\_alert\_uu\_idx          |      false      |                          |
|          |  700   |      200042      |           |        D         |                  |      false      |    false     | true  |     ad\_alertprocessor\_uu\_idx     |      false      |                          |
|          |  699   |      200043      |           |        D         |                  |      false      |    false     | true  |   ad\_alertprocessorlog\_uu\_idx    |      false      |                          |
|          |  592   |      200044      |           |        D         |                  |      false      |    false     | true  |     ad\_alertrecipient\_uu\_idx     |      false      |                          |
|          |  593   |      200045      |           |        D         |                  |      false      |    false     | true  |       ad\_alertrule\_uu\_idx        |      false      |                          |
|          |  754   |      200046      |           |        D         |                  |      false      |    false     | true  |        ad\_archive\_uu\_idx         |      false      |                          |
|          |  254   |      200047      |           |        D         |                  |      false      |    false     | true  |       ad\_attachment\_record        |      false      |                          |
|          |  254   |      200048      |           |        D         |                  |      false      |    false     | true  |       ad\_attachment\_uu\_idx       |      false      |                          |
|          |  705   |      200049      |           |        D         |                  |      false      |    false     | true  |     ad\_attachmentnote\_uu\_idx     |      false      |                          |
|          |  405   |      200050      |           |        D         |                  |      false      |    false     | true  |       ad\_attribute\_uu\_idx        |      false      |                          |
|          |  406   |      200051      |           |        D         |                  |      false      |    false     | true  |    ad\_attribute\_value\_uu\_idx    |      false      |                          |
|          | 200038 |      200052      |           |        D         |                  |      false      |    false     | true  |    ad\_broadcastmessage\_uu\_idx    |      false      |                          |
|          |  580   |      200053      |           |        D         |                  |      false      |    false     | true  |       ad\_changelog\_uu\_idx        |      false      |                          |
|          |  580   |      200054      |           |        D         |                  |      false      |    false     | false |        ad\_changelog\_speed         |      false      |                          |
|          | 53284  |      200055      |           |        D         |                  |      false      |    false     | true  |         ad\_chart\_uu\_idx          |      false      |                          |
|          | 53282  |      200056      |           |        D         |                  |      false      |    false     | true  |    ad\_chartdatasource\_uu\_idx     |      false      |                          |
|          |  112   |      200057      |           |        D         |                  |      false      |    false     | true  |          ad\_client\_value          |      false      |                          |
|          |  112   |      200058      |           |        D         |                  |      false      |    false     | true  |         ad\_client\_uu\_idx         |      false      |                          |
|          |  227   |      200059      |           |        D         |                  |      false      |    false     | true  |       ad\_clientinfo\_uu\_idx       |      false      |                          |
|          |  827   |      200060      |           |        D         |                  |      false      |    false     | true  |       ad\_clientshare\_table        |      false      |                          |
|          |  827   |      200061      |           |        D         |                  |      false      |    false     | true  |      ad\_clientshare\_uu\_idx       |      false      |                          |
|          |  457   |      200062      |           |        D         |                  |      false      |    false     | true  |         ad\_color\_uu\_idx          |      false      |                          |
|          |  101   |      200063      |           |        D         |                  |      false      |    false     | true  |         ad\_column\_uu\_idx         |      false      |                          |
|          |  101   |      200064      |           |        D         |                  |      false      |    false     | true  |          ad\_column\_name           |      false      |                          |
|          |  571   |      200065      |           |        D         |                  |      false      |    false     | true  |     ad\_column\_access\_uu\_idx     |      false      |                          |
|          |  752   |      200066      |           |        D         |                  |      false      |    false     | true  |      ad\_column\_trl\_uu\_idx       |      false      |                          |
|          | 200063 |      200067      |           |        D         |                  |      false      |    false     | true  |        ad\_ctxhelp\_uu\_idx         |      false      |                          |
|          | 200064 |      200068      |           |        D         |                  |      false      |    false     | true  |       ad\_ctxhelpmsg\_uu\_idx       |      false      |                          |
|          | 200065 |      200069      |           |        D         |                  |      false      |    false     | true  |    ad\_ctxhelpmsg\_trl\_uu\_idx     |      false      |                          |
|          |  458   |      200070      |           |        D         |                  |      false      |    false     | true  |        ad\_desktop\_uu\_idx         |      false      |                          |
|          |  460   |      200071      |           |        D         |                  |      false      |    false     | true  |      ad\_desktop\_trl\_uu\_idx      |      false      |                          |
|          |  459   |      200072      |           |        D         |                  |      false      |    false     | true  |    ad\_desktopworkbench\_uu\_idx    |      false      |                          |
|          | 53012  |      200073      |           |        D         |                  |      false      |    false     | true  | ad\_document\_action\_acce\_uu\_idx |      false      |                          |
|          |  276   |      200074      |           |        D         |                  |      false      |    false     | true  |        ad\_element\_uu\_idx         |      false      |                          |
|          |  276   |      200075      |           |        D         |                  |      false      |    false     | true  |    ad\_element\_uppercolumnname     |      false      |                          |
|          |  276   |      200076      |           |        D         |                  |      false      |    false     | false |          ad\_element\_name          |      false      |                          |
|          |  276   |      200077      |           |        D         |                  |      false      |    false     | false |       ad\_element\_clientorg        |      false      |                          |
|          |  277   |      200078      |           |        D         |                  |      false      |    false     | true  |      ad\_element\_trl\_uu\_idx      |      false      |                          |
|          |  882   |      200079      |           |        D         |                  |      false      |    false     | true  |       ad\_entitytype\_uu\_idx       |      false      |                          |
|          |  380   |      200080      |           |        D         |                  |      false      |    false     | true  |         ad\_error\_uu\_idx          |      false      |                          |
|          |  107   |      200081      |           |        D         |                  |      false      |    false     | true  |         ad\_field\_uu\_idx          |      false      |                          |
|          |  107   |      200082      |           |        D         |                  |      false      |    false     | true  |          ad\_field\_column          |      false      |                          |
|          |  127   |      200083      |           |        D         |                  |      false      |    false     | true  |       ad\_field\_trl\_uu\_idx       |      false      |                          |
|          |  414   |      200084      |           |        D         |                  |      false      |    false     | true  |       ad\_fieldgroup\_uu\_idx       |      false      |                          |
|          |  414   |      200085      |           |        D         |                  |      false      |    false     | true  |         ad\_fieldgroup\_key         |      false      |                          |
|          |  415   |      200086      |           |        D         |                  |      false      |    false     | true  |    ad\_fieldgroup\_trl\_uu\_idx     |      false      |                          |
|          |  404   |      200087      |           |        D         |                  |      false      |    false     | true  |          ad\_find\_uu\_idx          |      false      |                          |
|          |  376   |      200088      |           |        D         |                  |      false      |    false     | true  |          ad\_form\_uu\_idx          |      false      |                          |
|          |  378   |      200089      |           |        D         |                  |      false      |    false     | true  |      ad\_form\_access\_uu\_idx      |      false      |                          |
|          |  377   |      200090      |           |        D         |                  |      false      |    false     | true  |       ad\_form\_trl\_uu\_idx        |      false      |                          |
|          | 53147  |      200091      |           |        D         |                  |      false      |    false     | true  |      ad\_housekeeping\_uu\_idx      |      false      |                          |
|          |  461   |      200092      |           |        D         |                  |      false      |    false     | true  |         ad\_image\_uu\_idx          |      false      |                          |
|          |  381   |      200093      |           |        D         |                  |      false      |    false     | true  |         ad\_impformat\_name         |      false      |                          |
|          |  381   |      200094      |           |        D         |                  |      false      |    false     | true  |       ad\_impformat\_uu\_idx        |      false      |                          |
|          |  382   |      200095      |           |        D         |                  |      false      |    false     | true  |     ad\_impformat\_row\_uu\_idx     |      false      |                          |
|          | 200086 |      200096      |           |        D         |                  |      false      |    false     | true  |      ad\_indexcolumn\_uu\_idx       |      false      |                          |
|          |  897   |      200097      |           |        D         |                  |      false      |    false     | true  |       ad\_infocolumn\_uu\_idx       |      false      |                          |
|          |  898   |      200098      |           |        D         |                  |      false      |    false     | true  |    ad\_infocolumn\_trl\_uu\_idx     |      false      |                          |
|          |  895   |      200099      |           |        D         |                  |      false      |    false     | true  |    ad\_infowindow\_unique\_name     |      false      |                          |

</div>

</div>
