<div id="d155251e1" class="table">

<div class="table-title">

Table 1. Conta
Bancária

</div>

<div class="table-contents">

|               |                        |      |                |         |          |                       |                        |                   |                   |             |                       |      |        |                   |                                         |                |
| :-----------: | :--------------------: | :--: | :------------: | :-----: | :------: | :-------------------: | :--------------------: | :---------------: | :---------------: | :---------: | :-------------------: | :--: | :----: | :---------------: | :-------------------------------------: | :------------: |
|  Núm. Conta   | Tipo de Conta Bancária | NCBB | Conta Bancária |  Banco  | Moeda De | Compoe Fluxo de Caixa | Transitória de Crédito | Centro de Custo 2 | Limite de Crédito | Saldo Atual |       Descrição       | IBAN | Padrão |       Nome        | Classe Exportação da Folha de Pagamento | Chave de Busca |
|     1234      |           C            |      |      100       |   100   |   100    |         true          |         false          |                   |         0         |   \-1500    |   With PayFlwo Pro    |      |  true  |       1234        |                                         |      1234      |
|     5678      |           C            |      |      101       |   100   |   100    |         true          |         false          |                   |         0         |      0      | With Optimal Payments |      | false  |       5678        |                                         |      5678      |
|  HQ POS Cash  |           B            |      |     200000     | 200000  |   100    |         true          |         false          |                   |         0         |      0      |                       |      | false  |    HQ POS Cash    |                                         |  HQ POS Cash   |
| C030 / CX DIN |           C            |      |    1000000     | 1000000 |   297    |         true          |         false          |                   |         0         |      0      |                       |      | false  |   C030 / CX DIN   |                                         | C030 / CX DIN  |
|   0004454-5   |           C            |      |    5000002     | 5000002 |   297    |         true          |         false          |                   |         0         |      0      |                       |      | false  |     Santander     |                                         |    1000002     |
|    3030-4     |           C            |      |    5000004     | 5000004 |   297    |         true          |         false          |                   |         0         |      0      |                       |      | false  |        cc         |                                         |    1000004     |
|    27773-3    |           C            |      |    5000005     | 5000005 |   297    |         true          |         false          |                   |         0         |      0      |                       |      | false  | Itau 27773-3 - PR |                                         |    1000005     |
|   001145-5    |           C            |      |    5000003     | 5000003 |   297    |         true          |         false          |                   |         0         |     0.0     |                       |      | false  |       Itau        |                                         |    1000003     |
|    55562-2    |           C            |      |    5000001     | 5000001 |   297    |         true          |         false          |                   |         0         | \-32467.00  |                       |      | false  |       HSBC        |                                         |    1000001     |
|   000125-5    |           C            |      |    5000000     | 5000000 |   297    |         true          |         false          |                   |         0         |  \-4888.60  |                       |      | false  |     Bradesco      |                                         |    1000000     |

</div>

</div>
