<div id="d440049e1" class="table">

<div class="table-title">

Table 1. Lista de Preço
\*\*

</div>

<div class="table-contents">

|        |                                                                          |           |                |              |
| :----: | :----------------------------------------------------------------------: | :-------: | :------------: | :----------: |
| Idioma |                                Descrição                                 | Traduzida | Lista de Preço |     Nome     |
| pt\_BR | This is the sales price list and we create it based on the Purchase list |   false   |      101       |   Standard   |
| pt\_BR |     This list is created first - the "root" of the other price lists     |   false   |      102       |   Purchase   |
| pt\_BR |                           Export Prices in EUR                           |   false   |      103       |    Export    |
| pt\_BR |                                                                          |   false   |    1000002     |  Vendas BRL  |
| pt\_BR |                                                                          |   false   |    1000003     | Compras BRL  |
| es\_CO |                                                                          |   false   |    1000002     |  Vendas BRL  |
| es\_CO |                                                                          |   false   |    1000003     | Compras BRL  |
| es\_CO |                                                                          |   false   |    1000005     |    VENDA     |
| es\_CO |                                                                          |   false   |    1000006     |    COMPRA    |
| es\_CO |                                                                          |   false   |    1000004     |    Padrão    |
| es\_CO | This is the sales price list and we create it based on the Purchase list |   false   |      101       |   Standard   |
| es\_CO |     This list is created first - the "root" of the other price lists     |   false   |      102       |   Purchase   |
| es\_CO |                           Export Prices in EUR                           |   false   |      103       |    Export    |
| pt\_BR |                                                                          |   true    |    1000004     |    Padrão    |
| pt\_BR |                                                                          |   false   |    1000005     |    VENDA     |
| pt\_BR |                                                                          |   false   |    1000006     |    COMPRA    |
| pt\_BR |                                                                          |   false   |    5000000     |  COMPRA $$   |
| es\_CO |                                                                          |   false   |    5000000     |  COMPRA $$   |
| pt\_BR |                                                                          |   false   |    5000001     |  EXPORTAÇÃO  |
| es\_CO |                                                                          |   false   |    5000001     |  EXPORTAÇÃO  |
| pt\_BR |                                                                          |   false   |    5000002     | VENDA MARKUP |
| es\_CO |                                                                          |   false   |    5000002     | VENDA MARKUP |

</div>

</div>
