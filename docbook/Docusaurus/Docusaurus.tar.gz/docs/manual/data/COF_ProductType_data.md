<div id="d134725e1" class="table">

<div class="table-title">

Table 1. Tipo do Produto

</div>

<div class="table-contents">

|                 |           |      |                |
| :-------------: | :-------: | :--: | :------------: |
| Tipo do Produto | Descrição | Nome | Chave de Busca |
|     5000000     |           | TIPO |      TIPO      |
|     5000001     |           | CON  |      CON       |
|     5000002     |           | PROD |      PROD      |
|     5000003     |           | REV  |      REV       |

</div>

</div>
