<div id="d236849e1" class="table">

<div class="table-title">

Table 1. Fase
Padrão

</div>

<div class="table-contents">

|             |                 |                                                                                                                                                       |                                                              |         |                            |           |                   |
| :---------: | :-------------: | :---------------------------------------------------------------------------------------------------------------------------------------------------: | :----------------------------------------------------------: | :-----: | :------------------------: | :-------: | :---------------: |
| Fase Padrão | Tipo de Projeto |                                                                       Descrição                                                                       |                       Comentário/Ajuda                       | Produto |            Nome            | Seqüência | Quantidade Padrão |
|     100     |       100       |                                                           Evaluate the need and priorities                                                            |                                                              |         |  Initial Need Evaluation   |    10     |         1         |
|     101     |       100       |                                                      Conference Room Pilot - Critical Operations                                                      | This phase conentrates on critical operation of the business |         |  CRP - Critical Operation  |    20     |         0         |
|     102     |       101       |                                                                                                                                                       |                                                              |         |  Initial Scope Definition  |    10     |         1         |
|     103     |       101       |                                                                                                                                                       |                                                              |         |           Design           |    20     |         1         |
|     104     |       101       |                                                                                                                                                       |                                                              |         |       Implementation       |    30     |         1         |
|     105     |       102       |                                                                    Initial Contact                                                                    |                                                              |         |      Initial Contact       |    10     |         1         |
|     106     |       102       | How likely is the suspect to go ahead ? - Real pressing need with timeline (vs. looking around) - Approved Budget in line with targeted project scope |                                                              |         |   Initial Qualification    |    20     |         1         |
|     107     |       102       |                                  \- What difference does our product / service make - Capabilities %26 Competencies                                   |                                                              |         | Initial Sales Presentation |    30     |         1         |
|     108     |       102       |                                                            Rough estimate and Budget check                                                            |                                                              |         |       Initial Scope        |    40     |         1         |
|     109     |       102       |                              Based on pressing needs and info gathered do tailored overview presentation of the product                               |                                                              |         | First Product Presentation |    50     |         1         |
|     110     |       102       |                                                          Define Scope, Phases and Timelines                                                           |                                                              |         |      Paid Scope Study      |    60     |         1         |
|     111     |       102       |                                                      Based on Scope Study, negotiation of terms                                                       |                                                              |         |    Contract Negotiation    |    70     |         1         |
|     112     |       102       |                                                                   Contract Signed.                                                                    |                                                              |         |           Closed           |    80     |         1         |

</div>

</div>
