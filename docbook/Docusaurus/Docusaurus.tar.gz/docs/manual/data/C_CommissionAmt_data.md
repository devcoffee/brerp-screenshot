<div id="d159119e1" class="table">

<div class="table-title">

Table 1. Valor da
Comissão

</div>

<div class="table-contents">

|                 |                   |                   |                     |                   |                  |
| :-------------: | :---------------: | :---------------: | :-----------------: | :---------------: | :--------------: |
| Quantidade Real | Valor da Comissão | Linha de Comissão | Cálculo de Comissão | Valor da Comissão | Valor Convertido |
|       0.0       |      5000002      |      5000000      |       5000002       |        0.0        |       0.0        |

</div>

</div>
