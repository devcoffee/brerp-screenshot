<div id="d559122e1" class="table">

<div class="table-title">

Table 1. Parâmetros de Serviço
Web

</div>

<div class="table-contents">

|                     |                   |                   |                           |                     |
| :-----------------: | :---------------: | :---------------: | :-----------------------: | :-----------------: |
|   Valor Constante   | Nome do Parâmetro | Tipo de Parâmetro | Parâmetros de Serviço Web | Tipo de Serviço Web |
|         111         |  AD\_Process\_ID  |         C         |           50000           |        50000        |
|         CO          |     DocAction     |         C         |           50001           |        50000        |
|          0          |   AD\_Menu\_ID    |         C         |           50002           |        50000        |
|                     |  AD\_Record\_ID   |         F         |           50003           |        50000        |
|     C\_BPartner     |     TableName     |         C         |           50004           |        50001        |
|                     |     RecordID      |         F         |           50005           |        50001        |
|       Create        |      Action       |         C         |           50006           |        50001        |
|     C\_BPartner     |     TableName     |         C         |          5000000          |       5000000       |
|                     |     RecordID      |         F         |          5000001          |       5000000       |
|       Update        |      Action       |         C         |          5000002          |       5000000       |
|     C\_BPartner     |     TableName     |         C         |          5000003          |       5000001       |
|                     |     RecordID      |         F         |          5000004          |       5000001       |
|        Query        |      Action       |         C         |          5000005          |       5000001       |
|      AD\_Image      |     TableName     |         C         |          5000006          |       5000002       |
|                     |     RecordID      |         F         |          5000007          |       5000002       |
|        Read         |      Action       |         C         |          5000008          |       5000002       |
|      AD\_Image      |     TableName     |         C         |          5000009          |       5000004       |
|                     |     RecordID      |         F         |          5000010          |       5000004       |
|       Create        |      Action       |         C         |          5000011          |       5000004       |
| AD\_FieldSuggestion |     TableName     |         C         |          5000012          |       5000005       |
|       Action        |       Query       |         C         |          5000013          |       5000005       |
|                     |     RecordID      |         F         |          5000014          |       5000005       |

</div>

</div>
