<div id="d255188e1" class="table">

<div class="table-title">

Table 1. Distribuição
RG

</div>

<div class="table-contents">

|         |                                |                |                    |                     |                   |                                |                                 |                      |                          |                  |                  |                           |                    |                    |                  |           |                      |          |                   |                       |                        |               |                 |         |                  |           |                 |                  |                |        |      |         |                     |                    |                    |                 |                 |                   |  |
| :-----: | :----------------------------: | :------------: | :----------------: | :-----------------: | :---------------: | :----------------------------: | :-----------------------------: | :------------------: | :----------------------: | :--------------: | :--------------: | :-----------------------: | :----------------: | :----------------: | :--------------: | :-------: | :------------------: | :------: | :---------------: | :-------------------: | :--------------------: | :-----------: | :-------------: | :-----: | :--------------: | :-------: | :-------------: | :--------------: | :------------: | :----: | :--: | :-----: | :-----------------: | :----------------: | :----------------: | :-------------: | :-------------: | :---------------: |  |
|  Conta  | Organização de Transação (Trx) | Qualquer Conta | Qualquer Atividade | Qualquer P.Negócios | Qualquer Campanha | Qualquer Localização de Origem | Qualquer Localização de Destino | Qualquer Organização | Qualquer Organização Trx | Qualquer Produto | Qualquer Projeto | Qualquer Região de Vendas | Qualquer Usuário 1 | Qualquer Usuário 2 | Esquema Contábil | Atividade | Parceiro de Negócios | Campanha | Tipo de Documento | Localização de Origem | Localização de Destino | Qualquer CFOP | Processar Agora | Projeto | Região de Vendas | Descrição | Distribuição RG | Comentário/Ajuda | Criar Reversão | Válido | CFOP | Produto |        Nome         | Total Porcentagens | Tipo de Lançamento | Processar Agora | Centro de Custo | Centro de Custo 2 |  |
|   451   |                                |     false      |        true        |        true         |       true        |              true              |              true               |         true         |           true           |       true       |       true       |           true            |        true        |        true        |       101        |           |                      |          |                   |                       |                        |     true      |                 |         |                  |           |       100       |                  |      true      |  true  |      |         | Distribute Salaries |        100         |                    |      false      |                 |                   |  |
| 1000076 |                                |     false      |        true        |        true         |       true        |              true              |              true               |         true         |           true           |       true       |       true       |           true            |        true        |        true        |     1000001      |           |                      |          |                   |                       |                        |     true      |        Y        |         |                  |           |     5000000     |                  |      true      | false  |      |         |         gg          |         0          |                    |      false      |                 |                   |  |

</div>

</div>
