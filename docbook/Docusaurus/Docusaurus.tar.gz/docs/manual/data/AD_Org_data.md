<div id="d39880e1" class="table">

<div class="table-title">

Table 1. Organização

</div>

<div class="table-contents">

|                          |                     |                 |               |                |
| :----------------------: | :-----------------: | :-------------: | :-----------: | :------------: |
| Estratégia de Replicação |      Descrição      | Nível de Resumo |     Nome      | Chave de Busca |
|                          |  All Organizations  |      false      |      \*       |       0        |
|                          |  GardenWorld HQ\!   |      false      |      HQ       |       HQ       |
|                          |      Furniture      |      false      |   Furniture   |   Furniture    |
|                          |     Fertilizer      |      false      |  Fertilizer   |   Fertilizer   |
|                          |     Store North     |      false      |  Store North  |  Store North   |
|                          |     Store South     |      false      |  Store South  |  Store South   |
|                          |     Store East      |      false      |  Store East   |   Store East   |
|                          |     Store West      |      false      |  Store West   |   Store West   |
|                          | GardenWorld Store\! |      false      | Store Central | Store Central  |
|                          |                     |      true       |    Stores     |     Stores     |
|                          |                     |      false      |     teste     |     teste      |
|                          |                     |      false      |   Teste Hom   |   Teste Hom    |
|                          |                     |      false      |   Filial SC   |   Filial SC    |
|                          |                     |      false      |   Filial PR   |   Filial PR    |
|                          |                     |      false      |   Matriz-SP   |   Matriz-SP    |

</div>

</div>
