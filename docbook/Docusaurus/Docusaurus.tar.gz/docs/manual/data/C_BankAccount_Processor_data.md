<div id="d155162e1" class="table">

<div class="table-title">

Table 1. Bank Account
Processor

</div>

<div class="table-contents">

|             |            |                          |                    |               |                      |                         |                 |                    |             |                |          |                          |             |            |               |                    |               |                      |                        |                   |                   |             |              |                |              |                                                    |               |                  |
| :---------: | :--------: | :----------------------: | :----------------: | :-----------: | :------------------: | :---------------------: | :-------------: | :----------------: | :---------: | :------------: | :------: | :----------------------: | :---------: | :--------: | :-----------: | :----------------: | :-----------: | :------------------: | :--------------------: | :---------------: | :---------------: | :---------: | :----------: | :------------: | :----------: | :------------------------------------------------: | :-----------: | :--------------: |
| Aceita AMEX | Aceita ATM | Aceita Cheque Eletrônico | Aceita Corporativo | Aceita Diners | Aceita Débito Direto | Aceitar Depósito Direto | Aceita Discover | Aceita Master Card | Aceita Visa | Conta Bancária | Moeda De | Processador de Pagamento | Aceita AMEX | Aceita ATM | Aceita Cheque | Aceite Empresarial | Aceita Diners | Aceita Débito Direto | Aceita Depósito Direto | Aceitar Descobrir | Aceita MasterCard | Aceita Visa | Valor Mínimo | ID do Parceiro |    Senha     | Exige o Código de Verificação do Cartão de Crédito | ID do Usuário | ID do Fornecedor |
|    true     |   false    |          false           |        true        |     true      |        false         |          false          |      true       |        true        |    true     |      100       |   100    |           100            |    true     |   false    |     false     |        true        |     true      |        false         |         false          |       true        |       true        |    true     |      0       |      wfb       | vrn400000000 |                       false                        | vrn400000000  |   vrn400000000   |
|    false    |   false    |          false           |       false        |     false     |        false         |          false          |      false      |       false        |    false    |      101       |   100    |           101            |    false    |   false    |     false     |       false        |     false     |        false         |         false          |       false       |       false       |    false    |      0       |      wfb       | vrn400000000 |                       false                        | vrn400000000  |   vrn400000000   |

</div>

</div>
