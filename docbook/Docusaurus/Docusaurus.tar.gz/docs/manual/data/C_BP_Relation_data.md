<div id="d144945e1" class="table">

<div class="table-title">

Table 1. Relação com
Parceiros

</div>

<div class="table-contents">

|                      |                         |                      |                                     |                       |           |                    |                      |                       |                     |                                |
| :------------------: | :---------------------: | :------------------: | :---------------------------------: | :-------------------: | :-------: | :----------------: | :------------------: | :-------------------: | :-----------------: | :----------------------------: |
| Parceiro de Negócios | Localização do Parceiro | Parceiro Relacionado | Localização do Parceiro Relacionado | Relação com Parceiros | Descrição | Endereço de Fatura | Endereço de Cobrança | Endereço de Pagamento | Endereço de Entrega |              Nome              |
|         118          |                         |         117          |                 112                 |          100          |           |        true        |        false         |         true          |        false        | C%26W may pay invoices for Joe |

</div>

</div>
