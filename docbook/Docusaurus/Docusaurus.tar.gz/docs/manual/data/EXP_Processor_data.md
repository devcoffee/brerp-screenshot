<div id="d250418e1" class="table">

<div class="table-title">

Table 1. Processador de
Exportação

</div>

<div class="table-contents">

|                |                                        |                           |                                   |                                 |                 |                                                      |                 |       |                            |
| :------------: | :------------------------------------: | :-----------------------: | :-------------------------------: | :-----------------------------: | :-------------: | :--------------------------------------------------: | :-------------: | :---: | :------------------------: |
|     Conta      |               Descrição                | Processador de Exportação | Tipo do Processador de Exportação |        Comentário/Ajuda         |    Servidor     |                         Nome                         |  Info de Senha  | Porta |       Chave de Busca       |
| exampleAccount |    HDD Export Processor Description    |           50000           |               50000               |    HDD Export Processor Help    | www.example.com |                 HDD Export Processor                 | examplePassword |       |    HDD Export Processor    |
| exampleAccount | JMS Topic Export Processor Description |           50001           |               50001               | JMS Topic Export Processor Help | www.example.com | Human Readable name for - JMS Topic Export Processor | examplePassword | 61616 | JMS Topic Export Processor |

</div>

</div>
