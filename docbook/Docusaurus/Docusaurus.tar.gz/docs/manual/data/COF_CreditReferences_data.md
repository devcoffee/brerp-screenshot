<div id="d131474e1" class="table">

<div class="table-title">

Table 1. COF\_CreditReferences\_ID

</div>

<div class="table-contents">

|            |           |        |                   |                         |                           |      |                 |        |           |      |
| :--------: | :-------: | :----: | :---------------: | :---------------------: | :-----------------------: | :--: | :-------------: | :----: | :-------: | :--: |
| Núm. Conta | BancoNome | Cidade | Número da Agência | COF\_CreditAnalysis\_ID | COF\_CreditReferences\_ID | Tipo | Nome do Contato | Região | Descrição | Fone |
|    sddd    |   xxxx    |        |       dddd        |         5000003         |          5000000          |  02  |      dddd       |  441   |  cccccc   | dddd |

</div>

</div>
