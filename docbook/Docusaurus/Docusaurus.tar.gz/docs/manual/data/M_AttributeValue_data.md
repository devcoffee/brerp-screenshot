<div id="d413748e1" class="table">

<div class="table-title">

Table 1. Valor de
Atributo

</div>

<div class="table-contents">

|           |          |                   |                     |                |
| :-------: | :------: | :---------------: | :-----------------: | :------------: |
| Descrição | Atributo | Valor de Atributo |        Nome         | Chave de Busca |
|           |   100    |        100        |        Small        |       S        |
|           |   100    |        101        |       Medium        |       M        |
|           |   100    |        102        |        Large        |       L        |
|           |   101    |        103        |         Red         |       R        |
|           |   101    |        104        |        Green        |       G        |
|           |   101    |        105        |        Blue         |       B        |
|           |   102    |        106        |         New         |      New       |
|           |   102    |        107        |        Used         |      Used      |
|           |   102    |        108        |    Slightly Used    |    Slightly    |
|           | 1000000  |      1000000      |    Sul de Minas     |       SM       |
|           | 1000000  |      1000001      |   Cerrado Mineiro   |       CM       |
|           | 1000000  |      1000002      |    Alta Mogiana     |       AM       |
|           | 1000000  |      1000003      |  Cerrado da Bahia   |       CB       |
|           | 1000000  |      1000004      |  Blends Nacionais   |       BN       |
|           | 1000000  |      1000005      |     Importados      |       IM       |
|           | 1000000  |      1000006      | Chapada Diamantina  |       CD       |
|           | 1000001  |      1000008      |     Aromatizado     |       AR       |
|           | 1000001  |      1000009      |      Organico       |       OR       |
|           | 1000001  |      1000010      |    Descafeinado     |       DE       |
|           | 1000002  |      1000011      |        Grãos        |       GR       |
|           | 1000002  |      1000012      |       Cápsula       |       CP       |
|           | 1000002  |      1000013      |        Sachê        |       SA       |
|           | 1000002  |      1000014      | Moído para Expresso |       ME       |
|           | 1000002  |      1000015      |  Moído para Coador  |       MC       |
|           | 1000002  |      1000016      | Moído para Francesa |       MF       |
|           | 1000002  |      1000017      | Moído para Italiana |       MI       |
|           | 1000003  |      1000018      |        127v         |      127v      |
|           | 1000003  |      1000019      |        220v         |      220v      |
|           | 1000004  |      1000022      |        Sachê        |       SA       |
|           | 1000004  |      1000023      |   Superautomática   |       SU       |
|           | 1000004  |      1000024      |       Capsula       |       CA       |
|           | 1000005  |      1000025      |  Extração Farncesa  |       EF       |
|           | 1000005  |      1000026      |    Coador Manual    |       CM       |
|           | 1000005  |      1000027      |   Coador Elétrico   |       CE       |
|           | 1000005  |      1000028      |      Aeropress      |       AE       |
|           | 1000005  |      1000029      |  Globinho (Sifrão)  |       GS       |
|           | 1000005  |      1000030      |      Italiana       |       IT       |
|           | 1000006  |      1000031      |      1 Xícara       |       01       |
|           | 1000006  |      1000032      |      2 Xícaras      |       02       |
|           | 1000006  |      1000033      |      3 Xícaras      |       03       |
|           | 1000006  |      1000034      |      4 Xícaras      |       04       |
|           | 1000006  |      1000035      |      6 Xícaras      |       06       |
|           | 1000006  |      1000036      |      8 Xícaras      |       08       |
|           | 1000006  |      1000037      |      9 Xícaras      |       09       |
|           | 1000006  |      1000038      |     12 Xícaras      |       12       |
|           | 1000006  |      1000039      | Acima de 12 Xícaras |      12+       |
|           | 1000006  |      1000040      |       Outros        |       OU       |
|           | 5000003  |      5000003      |       LISTA 1       |    LISTA 1     |
|           | 5000003  |      5000004      |       LISTA 2       |    LISTA 2     |
|           | 5000003  |      5000005      |       LISTA 3       |    LISTA 3     |

</div>

</div>
