<div id="d543507e1" class="table">

<div class="table-title">

Table 1. Tipo de
Recurso

</div>

<div class="table-contents">

|                         |                      |                      |     |           |               |                      |                  |                      |             |             |               |        |         |              |             |              |                 |                       |                       |                |
| :---------------------: | :------------------: | :------------------: | :-: | :-------: | :-----------: | :------------------: | :--------------: | :------------------: | :---------: | :---------: | :-----------: | :----: | :-----: | :----------: | :---------: | :----------: | :-------------: | :-------------------: | :-------------------: | :------------: |
| Permitir Frações de UDM | Quantidade Debitável | Categoria de Imposto | UDM | Descrição | Faixa de Dias | Somente Tarefa Única | Faixa de Horário | Categoria de Produto |    Nome     | Sexta-feira | Segunda-feira | Sábado | Domingo | Quinta-feira | Terça-feira | Quarta-feira | Tipo de Recurso |     Horário Final     |    Horário Inicial    | Chave de Busca |
|          false          |          0           |         107          | 101 |           |     true      |        false         |       true       |         105          | Consultant  |    true     |     true      | false  |  false  |     true     |    true     |     true     |       100       | 1970-01-01 18:00:00.0 | 1970-01-01 09:00:00.0 |   Consultant   |
|          false          |          0           |         107          | 101 |           |     true      |        false         |      false       |        50003         |   Plants    |    true     |     true      | false  |  true   |     true     |    true     |     true     |      50000      |                       |                       |     Plants     |
|          false          |          0           |         107          | 101 |           |     true      |        false         |      false       |        50003         | Work Center |    true     |     true      |  true  |  false  |     true     |    true     |     true     |      50001      |                       |                       |       WC       |

</div>

</div>
