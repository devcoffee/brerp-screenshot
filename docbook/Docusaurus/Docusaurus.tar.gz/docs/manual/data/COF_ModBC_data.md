<div id="d132487e1" class="table">

<div class="table-title">

Table 1. Modalidade da
BC

</div>

<div class="table-contents">

|                  |      |         |                                        |                |
| :--------------: | :--: | :-----: | :------------------------------------: | :------------: |
| Modalidade da BC | Tipo | Imposto |                  Nome                  | Chave de Busca |
|     1000001      |  VL  | 1106000 |           1 - Pauta (Valor);           |       1        |
|     1000000      |  PE  | 1106000 |     0 - Margem Valor Agregado (%);     |       0        |
|     1000002      |  VL  | 1106000 |    2 - Preço Tabelado Máx. (valor);    |       2        |
|     1000003      |  VL  | 1106000 |         3 - valor da operação.         |       3        |
|     1000004      |  VL  | 1106012 | 0 – Preço tabelado ou máximo sugerido; |       0        |
|     1000005      |  VL  | 1106012 |      1 - Lista Negativa (valor);       |       1        |
|     1000006      |  VL  | 1106012 |      2 - Lista Positiva (valor);       |       2        |
|     1000007      |  VL  | 1106012 |       3 - Lista Neutra (valor);        |       3        |
|     1000008      |  PE  | 1106012 |     4 - Margem Valor Agregado (%);     |       4        |
|     1000009      |  VL  | 1106012 |           5 - Pauta (valor);           |       5        |

</div>

</div>
