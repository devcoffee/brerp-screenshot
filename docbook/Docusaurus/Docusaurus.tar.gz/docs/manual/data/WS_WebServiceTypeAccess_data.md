<div id="d559019e1" class="table">

<div class="table-title">

Table 1. Web Service Type Access

</div>

<div class="table-contents">

|         |                   |                     |
| :-----: | :---------------: | :-----------------: |
| Perfil  | Escrita e Leitura | Tipo de Serviço Web |
|  50004  |       true        |        50000        |
|  50004  |       true        |        50001        |
| 1000000 |       true        |       5000000       |
| 1000000 |       true        |       5000001       |
| 1000000 |       true        |       5000002       |
| 1000000 |       true        |       5000003       |
| 1000000 |       true        |       5000004       |
| 1000002 |       true        |       5000005       |

</div>

</div>
