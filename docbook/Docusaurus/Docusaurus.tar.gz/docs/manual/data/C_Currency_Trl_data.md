<div id="d164647e1" class="table">

<div class="table-title">

Table 1. Moeda De
\*\*

</div>

<div class="table-contents">

|        |          |          |                                           |           |
| :----: | :------: | :------: | :---------------------------------------: | :-------: |
| Idioma | Moeda De | Símbolo  |                 Descrição                 | Traduzida |
| es\_CO |   102    |    €     |                   Euro                    |   true    |
| es\_CO |   103    |    DM    |               Marco Alemán                |   true    |
| es\_CO |   104    |   Sch    |             Chelín Austriaco              |   true    |
| es\_CO |   105    |   BFr    |               Franco Belga                |   true    |
| es\_CO |   106    |    FM    |              Marco Finlandés              |   true    |
| es\_CO |   107    |    I£    |              Libra Irlandesa              |   true    |
| es\_CO |   108    |    L     |               Lira Italiana               |   true    |
| es\_CO |   109    |    Fl    |             Florín Neerlandés             |   true    |
| es\_CO |   110    |    Es    |             Escudo Portugués              |   true    |
| es\_CO |   115    |   SFr    | Franco Suizo (Código no válido - use CHF) |   true    |
| es\_CO |   116    |    C$    |             Dólar Canadiense              |   true    |
| es\_CO |   118    |    $     |              Peso Argentino               |   true    |
| es\_CO |   120    |    $     |             Dólar Australiano             |   true    |
| es\_CO |   121    |    $     |          Dólar de Nueva Zelanda           |   true    |
| es\_CO |   127    |    $     |              Dólar Liberiano              |   true    |
| es\_CO |   130    |    $     |               Peso Mexicano               |   true    |
| es\_CO |   142    |    $U    |               Peso Uruguayo               |   true    |
| es\_CO |   143    |          |               Dram Armenio                |   true    |
| es\_CO |   144    |          |                  Kwanza                   |   true    |
| es\_CO |   145    |          |            Azerbaijanian Manat            |   true    |
| es\_CO |   146    |          |                 Boliviano                 |   true    |
| es\_CO |   147    |          |             Franco Congoleño              |   true    |
| es\_CO |   148    |          |               Corona Checa                |   true    |
| es\_CO |   149    |          |                   Lari                    |   true    |
| es\_CO |   150    |          |                Rial Iraní                 |   true    |
| es\_CO |   152    |          |                Leu Moldavo                |   true    |
| es\_CO |   153    |          |               Peso Filipino               |   true    |
| es\_CO |   154    |          |                   Złoty                   |   true    |
| es\_CO |   155    |          |                Rublo Ruso                 |   true    |
| es\_CO |   157    |          |               Somoni Tayiko               |   true    |
| es\_CO |   158    |          |              Manat Turkmeno               |   true    |
| es\_CO |   159    |          |               Escudo Timor                |   true    |
| es\_CO |   160    |          |             Grivnia Ucraniana             |   true    |
| es\_CO |   161    |          |                Som Uzbeko                 |   true    |
| es\_CO |   163    |    £C    |              Libra Chipriota              |   true    |
| es\_CO |   165    |    £F    |             Libra Malvinense              |   true    |
| es\_CO |   166    |    £G    |            Libra Gibraltareña             |   true    |
| es\_CO |   167    |    £S    |           Libra de Santa Helena           |   true    |
| es\_CO |   168    |    £S    |                Libra Siria                |   true    |
| es\_CO |   170    |    ¢     |                   Cedi                    |   true    |
| es\_CO |   171    |    ¢     |             Colón Salvadoreño             |   true    |
| es\_CO |   195    |    Af    |               Afgani Afgano               |   true    |
| es\_CO |   201    |   Bd$    |              Dólar Bermudeño              |   true    |
| es\_CO |   207    |   BZ$    |              Dólar Beliceño               |   true    |
| es\_CO |   239    |    DH    |              Dirham Marroquí              |   true    |
| es\_CO |   244    |   EC$    |         Dólar del Caribe Oriental         |   true    |
| es\_CO |   309    |   Sf.    |             Florín de Surinam             |   true    |
| es\_CO |   311    |    Sk    |               Corona Sueca                |   true    |
| es\_CO |   312    |    Sk    |              Corona Eslovaca              |   true    |
| es\_CO |   313    |   SLRs   |            Rupia de Sri Lanka             |   true    |
| es\_CO |   314    |   SlT    |                   Tolar                   |   true    |
| es\_CO |   315    | So. Sh.  |               Chelín Somalí               |   true    |
| es\_CO |   317    |   SRls   |                Rial Saudí                 |   true    |
| es\_CO |   318    |   SFr    |               Franco Suizo                |   true    |
| es\_CO |   112    |    Fr    |              Franco Francés               |   true    |
| es\_CO |   113    |    ¥     |                Yen Japonés                |   true    |
| es\_CO |   114    |    £     |              Libra Esterlina              |   true    |
| es\_CO |   156    |          |               Dinar Sudanés               |   true    |
| es\_CO |   164    |    £E    |               Libra Egipcia               |   true    |
| es\_CO |   196    |   Af.    |              Florín Arubeño               |   true    |
| es\_CO |   197    |    B     |                  Balboa                   |   true    |
| es\_CO |   198    |    B$    |              Dólar de Brunéi              |   true    |
| es\_CO |   199    |    B$    |              Dólar Bahameño               |   true    |
| es\_CO |   200    |    BD    |              Dinar Bahreiní               |   true    |
| es\_CO |   202    |   Bds$   |             Dólar de Barbados             |   true    |
| es\_CO |   203    |    BR    |             Rublo Bielorruso              |   true    |
| es\_CO |   204    |    Br    |                   Birr                    |   true    |
| es\_CO |   205    |    Bs    |                  Bolívar                  |   true    |
| es\_CO |   206    |    Bt    |                   Baht                    |   true    |
| es\_CO |   209    |    C$    |              Córdoba de Oro               |   true    |
| es\_CO |   210    | C.V.Esc. |            Escudo Caboverdiano            |   true    |
| es\_CO |   211    |    CF    |              Franco Comorano              |   true    |
| es\_CO |   212    |   CFAF   |             Franco CFA UEMOA              |   true    |
| es\_CO |   214    |   CFAF   |             Franco CFA CEMAC              |   true    |
| es\_CO |   225    |   CFPF   |                Franco CFP                 |   true    |
| es\_CO |   228    |   Ch$    |               Peso Chileno                |   true    |
| es\_CO |   229    |   CI$    |         Dólar de las Islas Caimán         |   true    |
| es\_CO |   230    |    $     |              Peso Colombiano              |   true    |
| es\_CO |   231    |    CR    |                   Riel                    |   true    |
| es\_CO |   232    |   Cu$    |                Peso Cubano                |   true    |
| es\_CO |   233    |    D     |                  Dalasi                   |   true    |
| es\_CO |   234    |    D     |                   Đong                    |   true    |
| es\_CO |   235    |    DA    |              Dinar Argelino               |   true    |
| es\_CO |   236    |    Db    |                   Dobra                   |   true    |
| es\_CO |   237    |    DF    |             Franco Yibutiano              |   true    |
| es\_CO |   240    |   Din    |              Dinar Yugoslavo              |   true    |
| es\_CO |   241    |   Dkr    |               Corona Danesa               |   true    |
| es\_CO |   252    |    F$    |               Dólar Fiyiano               |   true    |
| es\_CO |   253    |   FBu    |             Franco de Burundi             |   true    |
| es\_CO |   254    |   FMG    |              Franco Malgache              |   true    |
| es\_CO |   255    |    Ft    |                  Florín                   |   true    |
| es\_CO |   256    |    G     |                  Gourde                   |   true    |
| es\_CO |   257    |    G$    |               Dólar Guyanés               |   true    |
| es\_CO |   258    |   HK$    |            Dólar de Hong Kong             |   true    |
| es\_CO |   259    |   HRK    |                Kuna Croata                |   true    |
| es\_CO |   260    |    ID    |               Dinar Iraquí                |   true    |
| es\_CO |   261    |   IKr    |             Corona Islandesa              |   true    |
| es\_CO |   262    |    J$    |             Dólar Jamaiquino              |   true    |
| es\_CO |   263    |    JD    |               Dinar Jordano               |   true    |
| es\_CO |   264    |    K     |                   Kyat                    |   true    |

</div>

</div>
