<div id="d54e1" class="table">

<div class="table-title">

Table 1. Processador de
Alertas

</div>

<div class="table-contents">

|                        |           |                              |                          |           |                                 |                        |                 |            |
| :--------------------: | :-------: | :--------------------------: | :----------------------: | :-------: | :-----------------------------: | :--------------------: | :-------------: | :--------: |
| Processador de Alertas | Programar | Data do último processamento | Data da Próxima Execução | Descrição | Dias para manter registro (log) |          Nome          | Processar Agora | Supervisor |
|          100           |  200000   |   2019-01-31 09:50:52.746    | 2019-02-01 09:50:52.746  |           |                7                | System Alert Processor |      false      |     0      |

</div>

</div>
