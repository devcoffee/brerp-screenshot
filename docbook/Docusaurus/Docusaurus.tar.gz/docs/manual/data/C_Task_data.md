<div id="d238652e1" class="table">

<div class="table-title">

Table 1. Tarefa
Padrão

</div>

<div class="table-contents">

|             |               |                                                                        |                  |         |                                      |           |                   |
| :---------: | :-----------: | :--------------------------------------------------------------------: | :--------------: | :-----: | :----------------------------------: | :-------: | :---------------: |
| Fase Padrão | Tarefa Padrão |                               Descrição                                | Comentário/Ajuda | Produto |                 Nome                 | Seqüência | Quantidade Padrão |
|     100     |      100      |                                                                        |                  |         |   Documentation Critical Processes   |    10     |         1         |
|     100     |      101      |                                                                        |                  |         | Documentation Decision Support Needs |    20     |         1         |
|     101     |      103      | Setup of Organization, Warehouses, Example Products, Business Partners |                  |         |        Setup of Main Entities        |    20     |         1         |
|     101     |      104      |                      Get Feedback from Champions                       |                  |         |       Initial CRP to Champions       |    30     |         1         |
|     101     |      105      |              Completing Setup based on Champion Feedback               |                  |         |         Enhancing CRP Setup          |    40     |         1         |
|     101     |      106      |            Get initial Feedback from future users of System            |                  |         |            CRP with Users            |    50     |         1         |
|     102     |      107      |                                                                        |                  |         |         Environment Analysis         |    10     |         1         |
|     102     |      108      |                                                                        |                  |         |        Requirements Gathering        |    20     |         1         |
|     101     |      102      |                Installation of OS, Oracle and iDempiere                |                  |         |             Installation             |    10     |         1         |

</div>

</div>
