<div id="d543593e1" class="table">

<div class="table-title">

Table 1. Indisponibilidade de
Recurso

</div>

<div class="table-contents">

|                       |                       |                |         |                              |
| :-------------------: | :-------------------: | :------------: | :-----: | :--------------------------: |
|        Do dia         |        Ao dia         |   Descrição    | Recurso | Indisponibilidade de Recurso |
| 2002-07-01 00:00:00.0 | 2002-07-01 00:00:00.0 | Training class |   100   |             100              |
| 2002-07-05 00:00:00.0 | 2002-07-12 00:00:00.0 |    Vacation    |   100   |             101              |

</div>

</div>
