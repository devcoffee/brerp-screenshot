<div id="d402046e1" class="table">

<div class="table-title">

Table 1. Serviços Web da
NFe

</div>

<div class="table-contents">

|        |              |                     |                     |              |                      |                                                                                           |                |
| :----: | :----------: | :-----------------: | :-----------------: | :----------: | :------------------: | :---------------------------------------------------------------------------------------: | :------------: |
| Região | Ambiente NFe | Tipo de Emissão NFe | Serviços Web da NFe | Modelo da NF |         Nome         |                                            URL                                            | Núm. da Versão |
|  444   |      2       |          1          |       5000117       |      55      |   NfeInutilizacao    |            https://homnfe.sefaz.am.gov.br/services2/services/NfeInutilizacao4             |      4.00      |
|  444   |      2       |          1          |       5000118       |      55      | NfeConsultaProtocolo |              https://homnfe.sefaz.am.gov.br/services2/services/NfeConsulta4               |      4.00      |
|  444   |      2       |          1          |       5000119       |      55      |   NfeStatusServico   |            https://homnfe.sefaz.am.gov.br/services2/services/NfeStatusServico4            |      4.00      |
|  444   |      2       |          1          |       5000120       |      55      |    RecepcaoEvento    |             https://homnfe.sefaz.am.gov.br/services2/services/RecepcaoEvento4             |      4.00      |
|  444   |      2       |          1          |       5000121       |      55      |    NFeAutorizacao    |             https://homnfe.sefaz.am.gov.br/services2/services/NfeAutorizacao4             |      4.00      |
|  444   |      2       |          1          |       5000122       |      55      |  NFeRetAutorizacao   |           https://homnfe.sefaz.am.gov.br/services2/services/NfeRetAutorizacao4            |      4.00      |
|  445   |      2       |          1          |       5000123       |      55      |   NfeInutilizacao    |      https://hnfe.sefaz.ba.gov.br/webservices/NFeInutilizacao4/NFeInutilizacao4.asmx      |      4.00      |
|  445   |      2       |          1          |       5000124       |      55      | NfeConsultaProtocolo | https://hnfe.sefaz.ba.gov.br/webservices/NFeConsultaProtocolo4/NFeConsultaProtocolo4.asmx |      4.00      |
|  445   |      2       |          1          |       5000125       |      55      |   NfeStatusServico   |     https://hnfe.sefaz.ba.gov.br/webservices/NFeStatusServico4/NFeStatusServico4.asmx     |      4.00      |
|  445   |      2       |          1          |       5000126       |      55      | NfeConsultaCadastro  |  https://hnfe.sefaz.ba.gov.br/webservices/CadConsultaCadastro4/CadConsultaCadastro4.asmx  |      4.00      |
|  445   |      2       |          1          |       5000127       |      55      |    RecepcaoEvento    |    https://hnfe.sefaz.ba.gov.br/webservices/NFeRecepcaoEvento4/NFeRecepcaoEvento4.asmx    |      4.00      |
|  445   |      2       |          1          |       5000128       |      55      |    NFeAutorizacao    |       https://hnfe.sefaz.ba.gov.br/webservices/NFeAutorizacao4/NFeAutorizacao4.asmx       |      4.00      |
|  445   |      2       |          1          |       5000129       |      55      |  NFeRetAutorizacao   |    https://hnfe.sefaz.ba.gov.br/webservices/NFeRetAutorizacao4/NFeRetAutorizacao4.asmx    |      4.00      |
|  446   |      2       |          1          |       5000130       |      55      |   NfeInutilizacao    |             https://nfeh.sefaz.ce.gov.br/nfe4/services/NFeInutilizacao4?WSDL              |      4.00      |
|  446   |      2       |          1          |       5000131       |      55      | NfeConsultaProtocolo |           https://nfeh.sefaz.ce.gov.br/nfe4/services/NFeConsultaProtocolo4?WSDL           |      4.00      |
|  446   |      2       |          1          |       5000132       |      55      |   NfeStatusServico   |             https://nfeh.sefaz.ce.gov.br/nfe4/services/NFeStatusServico4?WSDL             |      4.00      |
|  446   |      2       |          1          |       5000133       |      55      |    NFeAutorizacao    |              https://nfeh.sefaz.ce.gov.br/nfe4/services/NFeAutorizacao4?WSDL              |      4.00      |
|  446   |      2       |          1          |       5000134       |      55      |  NFeRetAutorizacao   |            https://nfeh.sefaz.ce.gov.br/nfe4/services/NFeRetAutorizacao4?WSDL             |      4.00      |
|  449   |      2       |          1          |       5000135       |      55      |   NfeInutilizacao    |            https://homolog.sefaz.go.gov.br/nfe/services/NFeInutilizacao4?wsdl             |      4.00      |
|  449   |      2       |          1          |       5000136       |      55      | NfeConsultaProtocolo |          https://homolog.sefaz.go.gov.br/nfe/services/NFeConsultaProtocolo4?wsdl          |      4.00      |
|  449   |      2       |          1          |       5000137       |      55      |   NfeStatusServico   |            https://homolog.sefaz.go.gov.br/nfe/services/NFeStatusServico4?wsdl            |      4.00      |
|  449   |      2       |          1          |       5000138       |      55      | NfeConsultaCadastro  |          https://homolog.sefaz.go.gov.br/nfe/services/CadConsultaCadastro4?wsdl           |      4.00      |
|  449   |      2       |          1          |       5000139       |      55      |    RecepcaoEvento    |           https://homolog.sefaz.go.gov.br/nfe/services/NFeRecepcaoEvento4?wsdl            |      4.00      |
|  445   |      1       |          1          |       5000153       |      55      |    RecepcaoEvento    |    https://nfe.sefaz.ba.gov.br/webservices/NFeRecepcaoEvento4/NFeRecepcaoEvento4.asmx     |      4.00      |
|  456   |      1       |          1          |       5000168       |      55      |   NfeInutilizacao    |                   https://nfe.sefa.pr.gov.br/nfe/NFeInutilizacao4?wsdl                    |      4.00      |
|  452   |      1       |          1          |       5000192       |      55      | NfeConsultaCadastro  |                   https://nfe.fazenda.ms.gov.br/ws/CadConsultaCadastro4                   |      4.00      |
|  452   |      1       |          1          |       5000193       |      55      |    RecepcaoEvento    |                    https://nfe.fazenda.ms.gov.br/ws/NFeRecepcaoEvento4                    |      4.00      |
|  452   |      1       |          1          |       5000194       |      55      |    NFeAutorizacao    |                     https://nfe.fazenda.ms.gov.br/ws/NFeAutorizacao4                      |      4.00      |
|  451   |      1       |          1          |       5000197       |      55      | NfeConsultaProtocolo |              https://nfe.sefaz.mt.gov.br/nfews/v2/services/NfeConsulta4?wsdl              |      4.00      |
|  451   |      1       |          1          |       5000198       |      55      |   NfeStatusServico   |           https://nfe.sefaz.mt.gov.br/nfews/v2/services/NfeStatusServico4?wsdl            |      4.00      |
|  451   |      1       |          1          |       5000202       |      55      |  NFeRetAutorizacao   |           https://nfe.sefaz.mt.gov.br/nfews/v2/services/NfeRetAutorizacao4?wsdl           |      4.00      |
|  452   |      2       |          1          |       5000207       |      55      |    NFeAutorizacao    |                   https://homologacao.nfe.ms.gov.br/ws/NFeAutorizacao4                    |      4.00      |
|  465   |      2       |          1          |       5000234       |      55      |    NFeAutorizacao    |             https://homologacao.nfe.fazenda.sp.gov.br/ws/nfeautorizacao4.asmx             |      4.00      |
|  465   |      2       |          1          |       5000235       |      55      |  NFeRetAutorizacao   |           https://homologacao.nfe.fazenda.sp.gov.br/ws/nferetautorizacao4.asmx            |      4.00      |
|  447   |      2       |          1          |       5000269       |      55      |    RecepcaoEvento    |       https://nfe-homologacao.svrs.rs.gov.br/ws/recepcaoevento/recepcaoevento4.asmx       |      4.00      |
|  448   |      2       |          1          |       5000273       |      55      | NfeConsultaProtocolo |          https://nfe-homologacao.svrs.rs.gov.br/ws/NfeConsulta/NfeConsulta4.asmx          |      4.00      |
|  448   |      2       |          1          |       5000274       |      55      |   NfeStatusServico   |     https://nfe-homologacao.svrs.rs.gov.br/ws/NfeStatusServico/NfeStatusServico4.asmx     |      4.00      |
|  448   |      2       |          1          |       5000275       |      55      |    RecepcaoEvento    |       https://nfe-homologacao.svrs.rs.gov.br/ws/recepcaoevento/recepcaoevento4.asmx       |      4.00      |
|  448   |      2       |          1          |       5000276       |      55      |    NFeAutorizacao    |       https://nfe-homologacao.svrs.rs.gov.br/ws/NfeAutorizacao/NFeAutorizacao4.asmx       |      4.00      |
|  455   |      2       |          1          |       5000279       |      55      | NfeConsultaProtocolo |          https://nfe-homologacao.svrs.rs.gov.br/ws/NfeConsulta/NfeConsulta4.asmx          |      4.00      |
|  455   |      2       |          1          |       5000282       |      55      |    NFeAutorizacao    |       https://nfe-homologacao.svrs.rs.gov.br/ws/NfeAutorizacao/NFeAutorizacao4.asmx       |      4.00      |
|  455   |      2       |          1          |       5000283       |      55      |  NFeRetAutorizacao   |    https://nfe-homologacao.svrs.rs.gov.br/ws/NfeRetAutorizacao/NFeRetAutorizacao4.asmx    |      4.00      |
|  458   |      2       |          1          |       5000287       |      55      |    RecepcaoEvento    |       https://nfe-homologacao.svrs.rs.gov.br/ws/recepcaoevento/recepcaoevento4.asmx       |      4.00      |
|  450   |      2       |          1          |       5000236       |      55      |   NfeInutilizacao    |      https://hom.sefazvirtual.fazenda.gov.br/NFeInutilizacao4/NFeInutilizacao4.asmx       |      4.00      |
|  450   |      2       |          1          |       5000237       |      55      | NfeConsultaProtocolo | https://hom.sefazvirtual.fazenda.gov.br/NFeConsultaProtocolo4/NFeConsultaProtocolo4.asmx  |      4.00      |
|  454   |      2       |          1          |       5000243       |      55      | NfeConsultaProtocolo | https://hom.sefazvirtual.fazenda.gov.br/NFeConsultaProtocolo4/NFeConsultaProtocolo4.asmx  |      4.00      |
|  454   |      2       |          1          |       5000244       |      55      |   NfeStatusServico   |     https://hom.sefazvirtual.fazenda.gov.br/NFeStatusServico4/NFeStatusServico4.asmx      |      4.00      |
|  454   |      2       |          1          |       5000246       |      55      |    NFeAutorizacao    |       https://hom.sefazvirtual.fazenda.gov.br/NFeAutorizacao4/NFeAutorizacao4.asmx        |      4.00      |
|  450   |      2       |          1          |       5000238       |      55      |   NfeStatusServico   |     https://hom.sefazvirtual.fazenda.gov.br/NFeStatusServico4/NFeStatusServico4.asmx      |      4.00      |
|  450   |      2       |          1          |       5000239       |      55      |    RecepcaoEvento    |    https://hom.sefazvirtual.fazenda.gov.br/NFeRecepcaoEvento4/NFeRecepcaoEvento4.asmx     |      4.00      |
|  455   |      2       |          6          |       5000361       |      55      |  NFeRetAutorizacao   |         https://hom.svc.fazenda.gov.br/NFeRetAutorizacao4/NFeRetAutorizacao4.asmx         |      4.00      |
|  459   |      2       |          6          |       5000363       |      55      |   NfeStatusServico   |          https://hom.svc.fazenda.gov.br/NFeStatusServico4/NFeStatusServico4.asmx          |      4.00      |
|  459   |      2       |          6          |       5000366       |      55      |  NFeRetAutorizacao   |         https://hom.svc.fazenda.gov.br/NFeRetAutorizacao4/NFeRetAutorizacao4.asmx         |      4.00      |
|  460   |      2       |          6          |       5000370       |      55      |    NFeAutorizacao    |            https://hom.svc.fazenda.gov.br/NFeAutorizacao4/NFeAutorizacao4.asmx            |      4.00      |
|  462   |      2       |          6          |       5000374       |      55      |    RecepcaoEvento    |         https://hom.svc.fazenda.gov.br/NFeRecepcaoEvento4/NFeRecepcaoEvento4.asmx         |      4.00      |
|  463   |      2       |          6          |       5000377       |      55      | NfeConsultaProtocolo |      https://hom.svc.fazenda.gov.br/NFeConsultaProtocolo4/NFeConsultaProtocolo4.asmx      |      4.00      |
|  463   |      2       |          6          |       5000380       |      55      |    NFeAutorizacao    |            https://hom.svc.fazenda.gov.br/NFeAutorizacao4/NFeAutorizacao4.asmx            |      4.00      |
|  464   |      2       |          6          |       5000383       |      55      |   NfeStatusServico   |          https://hom.svc.fazenda.gov.br/NFeStatusServico4/NFeStatusServico4.asmx          |      4.00      |
|  464   |      2       |          6          |       5000386       |      55      |  NFeRetAutorizacao   |         https://hom.svc.fazenda.gov.br/NFeRetAutorizacao4/NFeRetAutorizacao4.asmx         |      4.00      |
|  466   |      2       |          6          |       5000389       |      55      |    RecepcaoEvento    |         https://hom.svc.fazenda.gov.br/NFeRecepcaoEvento4/NFeRecepcaoEvento4.asmx         |      4.00      |
|  454   |      1       |          1          |       5000421       |      55      |   NfeStatusServico   |     https://www.sefazvirtual.fazenda.gov.br/NFeStatusServico4/NFeStatusServico4.asmx      |      4.00      |
|  458   |      1       |          1          |       5000465       |      55      |   NfeInutilizacao    |            https://nfe.svrs.rs.gov.br/ws/nfeinutilizacao/nfeinutilizacao4.asmx            |      4.00      |
|  458   |      1       |          1          |       5000467       |      55      |   NfeStatusServico   |           https://nfe.svrs.rs.gov.br/ws/NfeStatusServico/NfeStatusServico4.asmx           |      4.00      |
|  458   |      1       |          1          |       5000468       |      55      |    RecepcaoEvento    |             https://nfe.svrs.rs.gov.br/ws/recepcaoevento/recepcaoevento4.asmx             |      4.00      |
|  458   |      1       |          1          |       5000469       |      55      |    NFeAutorizacao    |             https://nfe.svrs.rs.gov.br/ws/NfeAutorizacao/NFeAutorizacao4.asmx             |      4.00      |
|  459   |      1       |          1          |       5000472       |      55      | NfeConsultaProtocolo |                https://nfe.svrs.rs.gov.br/ws/NfeConsulta/NfeConsulta4.asmx                |      4.00      |
|  459   |      1       |          1          |       5000473       |      55      |   NfeStatusServico   |           https://nfe.svrs.rs.gov.br/ws/NfeStatusServico/NfeStatusServico4.asmx           |      4.00      |
|  459   |      1       |          1          |       5000474       |      55      |    RecepcaoEvento    |             https://nfe.svrs.rs.gov.br/ws/recepcaoevento/recepcaoevento4.asmx             |      4.00      |
|  459   |      1       |          1          |       5000475       |      55      |    NFeAutorizacao    |             https://nfe.svrs.rs.gov.br/ws/NfeAutorizacao/NFeAutorizacao4.asmx             |      4.00      |
|  459   |      1       |          1          |       5000476       |      55      |  NFeRetAutorizacao   |          https://nfe.svrs.rs.gov.br/ws/NfeRetAutorizacao/NFeRetAutorizacao4.asmx          |      4.00      |
|  460   |      1       |          1          |       5000477       |      55      |   NfeInutilizacao    |            https://nfe.svrs.rs.gov.br/ws/nfeinutilizacao/nfeinutilizacao4.asmx            |      4.00      |
|  460   |      1       |          1          |       5000478       |      55      | NfeConsultaProtocolo |                https://nfe.svrs.rs.gov.br/ws/NfeConsulta/NfeConsulta4.asmx                |      4.00      |
|  460   |      1       |          1          |       5000479       |      55      |   NfeStatusServico   |           https://nfe.svrs.rs.gov.br/ws/NfeStatusServico/NfeStatusServico4.asmx           |      4.00      |
|  460   |      1       |          1          |       5000482       |      55      |  NFeRetAutorizacao   |          https://nfe.svrs.rs.gov.br/ws/NfeRetAutorizacao/NFeRetAutorizacao4.asmx          |      4.00      |
|  462   |      1       |          1          |       5000483       |      55      |   NfeInutilizacao    |            https://nfe.svrs.rs.gov.br/ws/nfeinutilizacao/nfeinutilizacao4.asmx            |      4.00      |
|  462   |      1       |          1          |       5000484       |      55      | NfeConsultaProtocolo |                https://nfe.svrs.rs.gov.br/ws/NfeConsulta/NfeConsulta4.asmx                |      4.00      |
|  458   |      1       |          1          |       5000470       |      55      |  NFeRetAutorizacao   |          https://nfe.svrs.rs.gov.br/ws/NfeRetAutorizacao/NFeRetAutorizacao4.asmx          |      4.00      |
|  459   |      1       |          1          |       5000471       |      55      |   NfeInutilizacao    |            https://nfe.svrs.rs.gov.br/ws/nfeinutilizacao/nfeinutilizacao4.asmx            |      4.00      |
|  462   |      1       |          1          |       5000486       |      55      |    RecepcaoEvento    |             https://nfe.svrs.rs.gov.br/ws/recepcaoevento/recepcaoevento4.asmx             |      4.00      |
|  459   |      1       |          6          |       5000543       |      55      | NfeConsultaProtocolo |      https://www.svc.fazenda.gov.br/NFeConsultaProtocolo4/NFeConsultaProtocolo4.asmx      |      4.00      |
|  459   |      1       |          6          |       5000546       |      55      |    NFeAutorizacao    |            https://www.svc.fazenda.gov.br/NFeAutorizacao4/NFeAutorizacao4.asmx            |      4.00      |
|  460   |      1       |          6          |       5000548       |      55      | NfeConsultaProtocolo |      https://www.svc.fazenda.gov.br/NFeConsultaProtocolo4/NFeConsultaProtocolo4.asmx      |      4.00      |
|  460   |      1       |          6          |       5000551       |      55      |    NFeAutorizacao    |            https://www.svc.fazenda.gov.br/NFeAutorizacao4/NFeAutorizacao4.asmx            |      4.00      |
|  462   |      1       |          6          |       5000554       |      55      |   NfeStatusServico   |          https://www.svc.fazenda.gov.br/NFeStatusServico4/NFeStatusServico4.asmx          |      4.00      |
|  463   |      1       |          6          |       5000560       |      55      |    RecepcaoEvento    |         https://www.svc.fazenda.gov.br/NFeRecepcaoEvento4/NFeRecepcaoEvento4.asmx         |      4.00      |
|  464   |      1       |          6          |       5000564       |      55      |   NfeStatusServico   |          https://www.svc.fazenda.gov.br/NFeStatusServico4/NFeStatusServico4.asmx          |      4.00      |
|  464   |      1       |          6          |       5000566       |      55      |    NFeAutorizacao    |            https://www.svc.fazenda.gov.br/NFeAutorizacao4/NFeAutorizacao4.asmx            |      4.00      |
|  466   |      1       |          6          |       5000569       |      55      |   NfeStatusServico   |          https://www.svc.fazenda.gov.br/NFeStatusServico4/NFeStatusServico4.asmx          |      4.00      |
|  466   |      1       |          6          |       5000570       |      55      |    RecepcaoEvento    |         https://www.svc.fazenda.gov.br/NFeRecepcaoEvento4/NFeRecepcaoEvento4.asmx         |      4.00      |
|  467   |      1       |          6          |       5000575       |      55      |    RecepcaoEvento    |         https://www.svc.fazenda.gov.br/NFeRecepcaoEvento4/NFeRecepcaoEvento4.asmx         |      4.00      |
|  453   |      1       |          6          |       5000579       |      55      |   NfeStatusServico   |          https://www.svc.fazenda.gov.br/NFeStatusServico4/NFeStatusServico4.asmx          |      4.00      |
|  461   |      1       |          6          |       5000583       |      55      | NfeConsultaProtocolo |      https://www.svc.fazenda.gov.br/NFeConsultaProtocolo4/NFeConsultaProtocolo4.asmx      |      4.00      |
|  461   |      1       |          6          |       5000586       |      55      |    NFeAutorizacao    |            https://www.svc.fazenda.gov.br/NFeAutorizacao4/NFeAutorizacao4.asmx            |      4.00      |
|  444   |      1       |          7          |       5000594       |      55      | NfeConsultaProtocolo |                https://nfe.svrs.rs.gov.br/ws/NfeConsulta/NfeConsulta4.asmx                |      4.00      |
|  456   |      1       |          7          |       5000653       |      55      |   NfeInutilizacao    |            https://nfe.svrs.rs.gov.br/ws/nfeinutilizacao/nfeinutilizacao4.asmx            |      4.00      |
|  456   |      1       |          7          |       5000656       |      55      |    RecepcaoEvento    |             https://nfe.svrs.rs.gov.br/ws/recepcaoevento/recepcaoevento4.asmx             |      4.00      |
|        |      1       |          1          |       5000659       |      55      |    RecepcaoEvento    |         https://www.nfe.fazenda.gov.br/NFeRecepcaoEvento4/NFeRecepcaoEvento4.asmx         |      4.00      |
|  451   |      1       |          7          |       5000629       |      55      |   NfeInutilizacao    |            https://nfe.svrs.rs.gov.br/ws/nfeinutilizacao/nfeinutilizacao4.asmx            |      4.00      |
|  110   |      1       |          7          |       5000640       |      55      |  NFeRetAutorizacao   |          https://nfe.svrs.rs.gov.br/ws/NfeRetAutorizacao/NFeRetAutorizacao4.asmx          |      4.00      |
|  457   |      1       |          7          |       5000646       |      55      |  NFeRetAutorizacao   |          https://nfe.svrs.rs.gov.br/ws/NfeRetAutorizacao/NFeRetAutorizacao4.asmx          |      4.00      |

</div>

</div>
