<div id="d133860e1" class="table">

<div class="table-title">

Table 1. Roteiro de
Produção

</div>

<div class="table-contents">

|                              |                                    |                      |            |                |             |          |           |                |                      |                 |                     |                   |                  |                 |     |           |         |                |
| :--------------------------: | :--------------------------------: | :------------------: | :--------: | :------------: | :---------: | :------: | :-------: | :------------: | :------------------: | :-------------: | :-----------------: | :---------------: | :--------------: | :-------------: | :-: | :-------: | :-----: | :------------: |
| Fator de conversão (divisão) | Fator de Conversão (multiplicação) | Horas Ciclo Estimada | Instruções | Roteiro Padrão | Lote Minimo | N. Peças | Perda (%) | Perda Estimada | Quantidade de Ciclos | Qtd Horas Setup | Roteiro de Produção | Classe do Produto | Grupo do Produto | Tipo do Produto | UDM | Descrição | Produto | Chave de Busca |
|              0               |                 0                  |          20          |            |      true      |      5      |    30    |     1     |      0.05      |          5           |       1.0       |       5000000       |                   |                  |                 | 100 |           | 5000056 |    1000000     |
|              0               |                 0                  |          20          |            |      true      |    10.0     |    20    |     0     |       0        |         10.0         |        1        |       5000001       |                   |                  |                 | 100 |           | 5000059 |    1000001     |
|              0               |                 0                  |         10.0         |            |     false      |    10.0     |    30    |     1     |     0.100      |         10.0         |        1        |       5000002       |                   |                  |                 | 100 |           | 5000059 |    1000002     |
|              0               |                 0                  |          5           |            |     false      |    10.0     |    20    |   10.0    |      1.00      |         10.0         |        2        |       5000003       |                   |                  |                 | 100 |           | 5000059 |    1000003     |
|              0               |                 0                  |          0           |            |      true      |     10      |    0     |     0     |       0        |          10          |        0        |       5000004       |                   |                  |                 | 100 |           | 5000063 |    1000005     |

</div>

</div>
