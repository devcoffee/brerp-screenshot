<div id="d86899e1" class="table">

<div class="table-title">

Table 1. AD\_User\_OrgAccess

</div>

<div class="table-contents">

|                 |                 |
| :-------------: | :-------------: |
| Usuário/Contato | Somente Leitura |
|     1000000     |      false      |
|     1000005     |      false      |
|     1000005     |      false      |

</div>

</div>
