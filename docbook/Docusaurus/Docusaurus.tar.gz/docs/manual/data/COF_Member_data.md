<div id="d132440e1" class="table">

<div class="table-title">

Table 1. COF\_Member\_ID

</div>

<div class="table-contents">

|             |          |           |                         |                       |                 |             |    |                     |
| :---------: | :------: | :-------: | :---------------------: | :-------------------: | :-------------: | :---------: | :-: | :-----------------: |
| Aniversário | Endereço | % Capital | COF\_CreditAnalysis\_ID |   Data da Inclusão    | COF\_Member\_ID |     CPF     | RG |        Nome         |
|             |          |    50     |         5000000         | 2018-01-25 00:00:00.0 |     5000000     |             |    |        bruno        |
|             |          |    50     |         5000000         | 2018-01-25 00:00:00.0 |     5000001     |             |    |       murilo        |
|             | 5000040  |    100    |         5000003         | 2018-02-14 00:00:00.0 |     5000002     | 22105523897 |    |     vnmcmxmcmxx     |
|             |          |    100    |         5000003         | 2018-02-14 00:00:00.0 |     5000003     | 22105523897 |    | vnmcmxmcmxxcccccccc |

</div>

</div>
