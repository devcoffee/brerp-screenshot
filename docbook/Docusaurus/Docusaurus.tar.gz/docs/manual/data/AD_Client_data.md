<div id="d2793e1" class="table">

<div class="table-title">

Table 1. Empresa

</div>

<div class="table-contents">

|        |                    |                          |               |               |                         |                |                          |                      |              |                   |                   |              |                  |                       |                 |                   |                      |                      |                        |                                 |                   |            |                   |
| :----: | :----------------: | :----------------------: | :-----------: | :-----------: | :---------------------: | :------------: | :----------------------: | :------------------: | :----------: | :---------------: | :---------------: | :----------: | :--------------: | :-------------------: | :-------------: | :---------------: | :------------------: | :------------------: | :--------------------: | :-----------------------------: | :---------------: | :--------: | :---------------: |
| Idioma | Políticas de Senha | Estratégia de Replicação | Auto Arquivar |   Descrição   | Diretório de Documentos | Teste de email | Documentos Multi-Idiomas | Lançar Imediatamente | SMTP SSL/TLS | Servidor de email | Autenticação SMTP | Utiliza SaaS | Use Funções Beta | Política de Materiais | Model Validator |       Nome        |        E-mail        | Pasta de Solicitação | Usuário da Solicitação | Senha do Usuário de Solicitação | Servidor de Email | Porta SMTP |  Chave de Busca   |
| pt\_BR |                    |                          |       N       |  GardenWorld  |                         |                |          false           |        false         |    false     |       false       |       true        |    false     |       true       |           F           |                 |    GardenWorld    | dev@devcoffee.com.br |       request        |         brerp          |          SeHZScBw4777           |   smtplw.com.br   |    587     |    GardenWorld    |
| pt\_BR |                    |                          |       N       |               |                         |                |          false           |        false         |    false     |       false       |       true        |    false     |       true       |           F           |                 | Mundo do Café S/A | dev@devcoffee.com.br |                      |         brerp          |          SeHZScBw4777           |   smtplw.com.br   |    587     | Mundo do Café S/A |
| en\_US |                    |                          |       N       | System Client |                         |                |           true           |        false         |    false     |       false       |       true        |    false     |       true       |           F           |                 |      System       | dev@devcoffee.com.br |                      |         brerp          |          SeHZScBw4777           |   smtplw.com.br   |    587     |      SYSTEM       |

</div>

</div>
