<div id="d156265e1" class="table">

<div class="table-title">

Table 1. Canal

</div>

<div class="table-contents">

|                  |         |                  |          |
| :--------------: | :-----: | :--------------: | :------: |
| Cor de Impressão |  Canal  |    Descrição     |   Nome   |
|                  |   103   | Brochure mailing |  Mailer  |
|                  |   101   |                  | Standard |
|                  | 1000000 |                  |  Padrão  |

</div>

</div>
