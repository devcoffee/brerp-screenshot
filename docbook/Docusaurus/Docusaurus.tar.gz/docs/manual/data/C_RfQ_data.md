<div id="d238372e1" class="table">

<div class="table-title">

Table 1. SdC

</div>

<div class="table-contents">

|                 |                      |                         |          |               |        |          |          |     |               |                       |                   |                       |                  |           |                     |                  |                                 |                            |                   |                   |              |          |               |            |                 |              |             |                 |                         |
| :-------------: | :------------------: | :---------------------: | :------: | :-----------: | :----: | :------: | :------: | :-: | :-----------: | :-------------------: | :---------------: | :-------------------: | :--------------: | :-------: | :-----------------: | :--------------: | :-----------------------------: | :------------------------: | :---------------: | :---------------: | :----------: | :------: | :-----------: | :--------: | :-------------: | :----------: | :---------: | :-------------: | :---------------------: |
| Usuário/Contato | Parceiro de Negócios | Localização do Parceiro | Moeda De | Copiar Linhas | Pedido | Criar PC | Criar PV | SdC | Tópico de SdC |   Data de Resposta    | Trabalho Completo |   Iniciar Trabalho    | Prazo de Entrega | Descrição | Número do Documento | Comentário/Ajuda | Somente Fornecedores Convidados | Cotar Todas as Quantidades | Cotar Valor Total | Respostas Aceitas | Auto-Serviço | Margem % |     Nome      | Processado | Processar Agora | Publicar SdC | Tipo de SdC | Classificar SdC | Representante de Vendas |
|                 |                      |                         |   100    |       N       |        |    N     |    N     | 100 |      101      | 2004-05-07 00:00:00.0 |                   | 2004-05-28 00:00:00.0 |        0         |           |          .          |                  |              false              |           false            |       false       |       true        |     true     |    0     | Summer supply |   false    |      false      |      N       |      S      |        N        |           101           |

</div>

</div>
