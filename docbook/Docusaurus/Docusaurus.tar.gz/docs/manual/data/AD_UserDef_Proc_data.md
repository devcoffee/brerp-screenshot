<div id="d86547e1" class="table">

<div class="table-title">

Table 1. Janela definida pelo
Usuário

</div>

<div class="table-contents">

|        |          |         |                              |                 |                                   |                                                                                                        |                          |                   |
| :----: | :------: | :-----: | :--------------------------: | :-------------: | :-------------------------------: | :----------------------------------------------------------------------------------------------------: | :----------------------: | :---------------: |
| Idioma | Processo | Perfil  | Janela definida pelo Usuário | Usuário/Contato |             Descrição             |                                            Comentário/Ajuda                                            | Atualizável pelo usuário |       Nome        |
| pt\_BR |   145    |         |           5000001            |                 | Lista de Itens em Aberto (Fatura) | Lista os itens a pagar ou receber. No caso de moeda estrangeira efetua conversão em campos específicos |                          | Faturas em aberto |
| pt\_BR |   145    | 1000000 |           5000000            |                 | Lista de Itens em Aberto (Fatura) | Lista os itens a pagar ou receber. No caso de moeda estrangeira efetua conversão em campos específicos |                          | Faturas em Aberto |

</div>

</div>
