<div id="d124642e1" class="table">

<div class="table-title">

Table 1. Adição

</div>

<div class="table-contents">

|         |                          |                                  |                  |                                       |                                            |                                          |
| :-----: | :----------------------: | :------------------------------: | :--------------: | :-----------------------------------: | :----------------------------------------: | :--------------------------------------: |
| Adição  | Declaração de Importação | Código do fabricante estrangeiro | Numero da Adição | Número do ato concessório de Drawback | Numero sequencial do item dentro da Adição | Valor do desconto do item da DI – Adição |
| 5000000 |         5000000          |            999600173             |        1         |                   0                   |                     1                      |                    0                     |
| 5000001 |         5000000          |            999600154             |        2         |                   0                   |                     2                      |                    0                     |
| 5000002 |         5000000          |            999600065             |        3         |                   0                   |                     3                      |                    0                     |
| 5000003 |         5000000          |              002438              |        4         |                   0                   |                     4                      |                    0                     |

</div>

</div>
