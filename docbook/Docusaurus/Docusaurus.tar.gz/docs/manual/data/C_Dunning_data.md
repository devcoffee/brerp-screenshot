<div id="d175063e1" class="table">

<div class="table-title">

Table 1. Cobrança

</div>

<div class="table-contents">

|          |                                      |           |        |                 |                           |
| :------: | :----------------------------------: | :-------: | :----: | :-------------: | :-----------------------: |
| Cobrança | Criar níveis de cobrança sequenciais | Descrição | Padrão |      Nome       | Enviar Cartas de Cobrança |
|   100    |                false                 |           |  true  |     Default     |           true            |
|   101    |                false                 |           | false  |   No Dunning    |           false           |
| 5000000  |                false                 |           |  true  | Cobrança 2 dias |           false           |

</div>

</div>
