<div id="d459648e1" class="table">

<div class="table-title">

Table 1. Linha de
Requisição

</div>

<div class="table-contents">

|                      |            |                          |         |           |            |                |                                    |         |            |                     |                |            |
| :------------------: | :--------: | :----------------------: | :-----: | :-------: | :--------: | :------------: | :--------------------------------: | :-----: | :--------: | :-----------------: | :------------: | :--------: |
| Parceiro de Negócios | Finalidade | Linha de Ordem de Vendas |   UDM   | Descrição | Linha Núm. | Valor da Linha | Instância do Conjunto de Atributos | Produto | Requisição | Linha de Requisição | Preço Unitário | Quantidade |
|                      |            |                          |   100   |           |     10     |     23.75      |                                    |   128   |    100     |         100         |     23.75      |     1      |
|                      |            |                          |   100   |           |     10     |      0.0       |                                    | 1000000 |  5000001   |       5000000       |      0.0       |     50     |
|                      |            |                          |   100   |           |     10     |    1127.70     |                                    | 1000001 |  5000002   |       5000001       |     12.53      |     90     |
|       5000026        |            |                          | 1000033 |           |     10     |      300       |                                    | 5000003 |  5000003   |       5000002       |       15       |     20     |
|       5000000        |            |                          |   100   |           |     10     |     10000      |                                    | 1000001 |  5000004   |       5000003       |      100       |    100     |

</div>

</div>
