<div id="d159253e1" class="table">

<div class="table-title">

Table 1. Atividade do
Contato

</div>

<div class="table-contents">

|                 |                      |                                                    |                   |                        |                                                    |                       |          |                         |                       |
| :-------------: | :------------------: | :------------------------------------------------: | :---------------: | :--------------------: | :------------------------------------------------: | :-------------------: | :------: | :---------------------: | :-------------------: |
| Usuário/Contato | Atividade do Contato |                    Comentários                     | Tipo de Atividade | Oportunidade de Vendas |                     Descrição                      |      Data Final       | Completo | Representante de Vendas |    Data de Início     |
|     5000018     |       5000000        |                                                    |        EM         |        5000000         |                     1º contato                     |                       |  false   |                         | 2018-01-18 10:07:47.0 |
|     5000021     |       5000001        | enviei email para contato ajsdiasdasc naokdnck oco |        EM         |        5000002         | enviei email para contato ajsdiasdasc naokdnck oco | 2018-02-02 00:00:00.0 |  false   |                         | 2018-01-30 11:12:16.0 |
|     5000021     |       5000002        |             conversamos sobre proposta             |        ME         |        5000002         |                      Reunião                       | 2018-01-30 00:00:00.0 |  false   |                         | 2018-01-30 11:15:26.0 |

</div>

</div>
