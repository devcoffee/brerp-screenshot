<div id="d412706e1" class="table">

<div class="table-title">

Table 1. Métrica de
Prevenção

</div>

<div class="table-contents">

|         |       |                       |           |                      |                      |      |             |                |
| :-----: | :---: | :-------------------: | :-------: | :------------------: | :------------------: | :--: | :---------: | :------------: |
|  Ativo  | Valor |   Data da Transação   | Descrição | Métrica de Prevenção | Métrica de Prevenção | Nome | Valor Total | Chave de Busca |
| 5000000 |   0   | 2018-01-18 08:40:01.0 |           |       5000000        |       5000001        |  1   |    42.00    |    1000000     |

</div>

</div>
