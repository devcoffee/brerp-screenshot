<div id="d134747e1" class="table">

<div class="table-title">

Table 1. COF\_RealGoods\_ID

</div>

<div class="table-contents">

|                  |        |       |                         |               |                    |                    |         |    |      |            |        |           |
| :--------------: | :----: | :---: | :---------------------: | :-----------: | :----------------: | :----------------: | :-----: | :-: | :--: | :--------: | :----: | :-------: |
| Valor de Mercado | Cidade | Marca | COF\_CreditAnalysis\_ID | Valor Forçado | COF\_RealGoods\_ID | Número de Registro | RENAVAM | M² | Tipo | Ano Modelo | Região | Descrição |
|      11000       |        |       |         5000003         |      100      |      5000000       |        2322        |         | 0  |  01  |     0      |  441   |   ccccc   |

</div>

</div>
