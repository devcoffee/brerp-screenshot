<div id="d103851e1" class="table">

<div class="table-title">

Table 1. Responsável pelo Fluxo de
Trabalho

</div>

<div class="table-contents">

|        |                 |                                    |                                                                 |                  |              |                          |                  |
| :----: | :-------------: | :--------------------------------: | :-------------------------------------------------------------: | :--------------: | :----------: | :----------------------: | :--------------: |
| Perfil | Usuário/Contato | Responsável pelo Fluxo de Trabalho |                            Descrição                            | Tipo de Entidade |     Nome     | Tipo de Responsabilidade | Roteiro (Script) |
|   0    |       100       |                100                 |      Supervisor of the Organization starting the Workflow       |        D         | Organization |            O             |                  |
|   0    |                 |                101                 | The person stating the Workflow (do not select a specific user) |        D         |   Invoker    |            H             |                  |
|   0    |     1000022     |              1500086               |                                                                 |        U         |   respons.   |            H             |                  |

</div>

</div>
