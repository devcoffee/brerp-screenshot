<div id="d112908e1" class="table">

<div class="table-title">

Table 1. Informações de
Ativo

</div>

<div class="table-contents">

|                |                     |         |                      |                 |                            |                        |                |             |                  |                |                     |                     |                 |          |          |                       |            |
| :------------: | :-----------------: | :-----: | :------------------: | :-------------: | :------------------------: | :--------------------: | :------------: | :---------: | :--------------: | :------------: | :-----------------: | :-----------------: | :-------------: | :------: | :------: | :-------------------: | :--------: |
| Chave de Busca |        Nome         | Produto | Parceiro de Negócios | Usuário/Contato | Data de Entrada em Serviço | Vencimento da Garantia | Núm. da Versão | Organização | No do Inventário | Grupo de Ativo |  Data de Ativação   |  Data de Ativação   | Status do Ativo | Em Posse | Em Poder | Totalmente depreciado | Descartado |
|    1000000     | Produto teste Ativo | 5000052 |         null         |      null       |    2018-01-23 00:00:00     |          null          |      null      |   1000001   |     5000000      |    5000000     | 2018-01-23 00:00:00 | 2018-01-23 00:00:00 |       NW        |    Y     |    Y     |           N           |     N      |
|    1000002     |      Maquina 1      | 5000057 |         null         |      null       |            null            |          null          |      null      |   1000001   |     5000002      |    5000001     |        null         |        null         |       NW        |    N     |    N     |           N           |     N      |
|    1000001     |        teste        | 5000052 |         null         |      null       |    2018-01-23 00:00:00     |          null          |      null      |   1000001   |     5000001      |    5000000     | 2018-01-23 00:00:00 | 2018-01-23 00:00:00 |       DI        |    Y     |    Y     |           N           |     Y      |
|    1000000     |        ATIVO        | 5000052 |         null         |      null       |    2018-02-17 00:00:00     |          null          |      null      |   1000001   |     5000000      |    5000000     | 2018-01-23 00:00:00 | 2018-01-23 00:00:00 |       NW        |    Y     |    Y     |           N           |     N      |
|    1000003     |      VW JETTA       | 5000052 |         null         |      null       |    2018-02-17 00:00:00     |          null          |      null      |   1000001   |     5000004      |    5000000     | 2018-02-17 00:00:00 | 2018-02-17 00:00:00 |       AC        |    Y     |    Y     |           N           |     N      |

</div>

</div>
