<div id="d559393e1" class="table">

<div class="table-title">

Table 1. COF\_Nve\_Product

</div>

<div class="table-contents">

|          |                   |           |         |         |
| :------: | :---------------: | :-------: | :-----: | :-----: |
| COF\_Nve | COF\_Nve\_Product | Descrição |   NCM   | Produto |
| 5000000  |      5000000      |           | 1007094 | 5000006 |
| 5000001  |      5000001      |           | 1007094 | 5000006 |
| 5000002  |      5000002      |           | 1007094 | 5000006 |

</div>

</div>
