<div id="d111457e1" class="table">

<div class="table-title">

Table 1. Grupo de Ativo
\*\*

</div>

<div class="table-contents">

|                |        |                            |                                                        |           |                           |
| :------------: | :----: | :------------------------: | :----------------------------------------------------: | :-------: | :-----------------------: |
| Grupo de Ativo | Idioma |         Descrição          |                    Comentário/Ajuda                    | Traduzida |           Nome            |
|      100       | pt\_BR |   Download Documentation   |                                                        |   false   |       Documentation       |
|     50000      | pt\_BR |         Buildings          |                     All Buildings                      |   false   |         Buildings         |
|     50001      | pt\_BR |          Software          |                        Software                        |   false   |         Software          |
|     50002      | pt\_BR |   Download Documentation   |                                                        |   false   |       Documentation       |
|     50003      | pt\_BR | Data Processing Equipment  |        Group defines Data Processing Equipment         |   false   | Data Processing Equipment |
|     50004      | pt\_BR |         Furniture          |       Office furniture including office and shop       |   false   |         Furniture         |
|     50005      | pt\_BR |          Fixtures          |           Fixtures including tools %26 dies            |   false   |         Fixtures          |
|     50006      | pt\_BR | Trucks Cars Vans Forklifts |                      All vehicles                      |   false   |         Vehicles          |
|     50007      | pt\_BR |         Equipment          | Light equipment including test equipment and computers |   false   |         Equipment         |
|      100       | es\_CO |   Download Documentation   |                                                        |   false   |       Documentation       |
|     50000      | es\_CO |         Buildings          |                     All Buildings                      |   false   |         Buildings         |
|     50001      | es\_CO |          Software          |                        Software                        |   false   |         Software          |
|     50002      | es\_CO |   Download Documentation   |                                                        |   false   |       Documentation       |
|     50003      | es\_CO | Data Processing Equipment  |        Group defines Data Processing Equipment         |   false   | Data Processing Equipment |
|     50004      | es\_CO |         Furniture          |       Office furniture including office and shop       |   false   |         Furniture         |
|     50005      | es\_CO |          Fixtures          |           Fixtures including tools %26 dies            |   false   |         Fixtures          |
|     50006      | es\_CO | Trucks Cars Vans Forklifts |                      All vehicles                      |   false   |         Vehicles          |
|     50007      | es\_CO |         Equipment          | Light equipment including test equipment and computers |   false   |         Equipment         |
|    5000000     | pt\_BR |            G-at            |                                                        |   false   |           G-at            |
|    5000000     | es\_CO |            G-at            |                                                        |   false   |           G-at            |
|    5000001     | pt\_BR |                            |                                                        |   false   |  maquinas e equipamentos  |
|    5000001     | es\_CO |                            |                                                        |   false   |  maquinas e equipamentos  |

</div>

</div>
