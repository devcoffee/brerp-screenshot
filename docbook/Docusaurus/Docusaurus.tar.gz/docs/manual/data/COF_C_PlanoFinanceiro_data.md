<div id="d126494e1" class="table">

<div class="table-title">

Table 1. Plano
Financeiro

</div>

<div class="table-contents">

|               |                  |           |                 |                                                              |                |
| :-----------: | :--------------: | :-------: | :-------------: | :----------------------------------------------------------: | :------------: |
| Tipo de Conta | Plano Financeiro | Descrição | Nível de Resumo |                             Nome                             | Chave de Busca |
|       R       |     5000001      |           |      false      |                    RECEITAS SOBRE VENDAS                     |      1.2.      |
|       R       |     5000002      |           |      false      |                    RECEITA SOBRE SERVIÇOS                    |      1.3.      |
|       R       |     5000003      |           |      false      |            RECEITAS SOBRE JUROS DE INADIMPLÊNCIA             |      1.4.      |
|       R       |     5000004      |           |      false      |          REICEITA SOBRE VENDAS EQUIPAMENTOS USADOS           |      1.5.      |
|       R       |     5000005      |           |      false      |                 OUTRAS RECEITAS OPERACIONAIS                 |      1.6.      |
|       R       |     5000006      |           |      false      |               OUTRAS ENTRADAS NÃO OPERACIONAIS               |      1.7.      |
|       E       |     5000008      |           |      false      |                       MATÉRIAS PRIMAS                        |      2.1.      |
|       E       |     5000009      |           |      false      |            EQUIPAMENTO USADO PARA REFORMA/REVENDA            |      2.2.      |
|       E       |     5000010      |           |      false      |                    PRODUTOS PARA REVENDA                     |      2.3.      |
|       E       |     5000011      |           |      false      |                     INSUMOS DE PRODUÇÃO                      |      2.4.      |
|       E       |     5000012      |           |      false      |              COMPONENTES DE APLICAÇÃO SERVIÇOS               |      2.5.      |
|       E       |     5000013      |           |      false      |                   FERRAMENTAS DE PRODUÇÃO                    |      2.6.      |
|       E       |     5000014      |           |      false      |              SERVIÇOS TERCEIRIZADOS (Sintético)              |      2.7.      |
|       E       |     5000015      |           |      false      |                    SERVIÇOS TERCEIRIZADOS                    |     2.7.1.     |
|       E       |     5000016      |           |      false      |                       OUTROS SERVIÇOS                        |     2.7.3.     |
|       E       |     5000017      |           |      false      |                       FRETES DE COMPRA                       |      2.8.      |
|       E       |     5000018      |           |      false      |                          EMBALAGENS                          |      2.9.      |
|       E       |     5000020      |           |      false      |                 DESPESAS PESSOAL (Sintético)                 |      3.1.      |
|       E       |     5000021      |           |      false      |                         ESTAGIÁRIOS                          |     3.1.1.     |
|       E       |     5000022      |           |      false      |               SERVIÇOS TERCEIRIZADO ENGENHEIRO               |     3.1.2.     |
|       E       |     5000023      |           |      false      |                      FOLHA DE PAGAMENTO                      |     3.1.3.     |
|       E       |     5000024      |           |      false      |                            FÉRIAS                            |     3.1.4.     |
|       E       |     5000025      |           |      false      |                         13°. SALÁRIO                         |     3.1.5.     |
|       E       |     5000026      |           |      false      |                    RESCISÕES TRABALHISTAS                    |     3.1.6.     |
|       E       |     5000027      |           |      false      |                    BENEFÍCIOS (Sintético)                    |     3.1.7.     |
|       E       |     5000028      |           |      false      |                   SEGURO DE VIDA EM GRUPO                    |    3.1.7.1.    |
|       E       |     5000029      |           |      false      |                    CONVÊNIO MÉDICO UNIMED                    |    3.1.7.2.    |
|       E       |     5000030      |           |      false      |       SINDICATO DOS METALÚRGICOS | CONVENÇÃO COLETIVA        |     3.1.8.     |
|       E       |     5000031      |           |      false      |                 GRATIFICAÇÕES | BONIFICAÇÕES                 |     3.1.9.     |
|       E       |     5000032      |           |      false      |                      EXAMES (Sintético)                      |    3.1.10.     |
|       E       |     5000033      |           |      false      |                      PERIÓDICOS | A S O                      |   3.1.10.1.    |
|       E       |     5000034      |           |      false      |                         ADMISSIONAIS                         |   3.1.10.2.    |
|       E       |     5000035      |           |      false      |                         DEMISSIONAIS                         |   3.1.10.3.    |
|       E       |     5000036      |           |      false      |                          TRANSPORTE                          |    3.1.11.     |
|       E       |     5000037      |           |      false      |             EQUIPAMENTOS DE PROTEÇÃO INDIVIDUAL              |    3.1.12.     |
|       E       |     5000038      |           |      false      |                      LAUDOS (Sintético)                      |    3.1.13.     |
|       E       |     5000039      |           |      false      |     P P R A - PROGAMA DE PREVENÇÃO DE RISCOS AMBIENTAIS      |   3.1.13.1.    |
|       E       |     5000040      |           |      false      | P C M S O - PROGRAMA DE CONTROLE MÉDICO E SAÚDE OCUPACIONAL  |   3.1.13.2.    |
|       E       |     5000041      |           |      false      | LTCATI - LAUDO TÉCNICO DAS CONDIÇÕES DO AMBIENTE DE TRABALHO |   3.1.13.3.    |
|       E       |     5000042      |           |      false      |                          UNIFORMES                           |    3.1.14.     |
|       E       |     5000043      |           |      false      |                  CONTRIBUIÇÃO ASSISTENCIAL                   |    3.1.15.     |
|       E       |     5000044      |           |      false      |                  CONTRIBUIÇÃO CONFEDERATIVA                  |    3.1.16.     |
|       E       |     5000045      |           |      false      |              IMPOSTOS FOBRE FOLHA DE PAGAMENTO               |    3.1.17.     |
|       E       |     5000046      |           |      false      |                             FGTS                             |    3.1.17.1    |
|       E       |     5000047      |           |      false      |                             GPS                              |   3.1.17.2.    |
|       E       |     5000048      |           |      false      |                 DESPESAS SÓCIOS (Sintético)                  |      3.2.      |
|       E       |     5000049      |           |      false      |                    PRÓ LABORE (Sintético)                    |     3.2.1.     |
|       E       |     5000007      |           |      true       |                       CMV (Sintético)                        |      2\.       |
|       E       |     5000019      |           |      true       |              DESPESAS OPERACIONAIS (Sintético)               |      3\.       |
|       E       |     5000050      |           |      false      |                          RETIRADAS                           |     3.2.2.     |
|       E       |     5000051      |           |      false      |                 DESPESAS VENDAS (Sintético)                  |      3.3.      |
|       E       |     5000052      |           |      false      |                          COMISSÕES                           |     3.3.1.     |
|       E       |     5000053      |           |      false      |                       FRETES DE VENDA                        |     3.3.2.     |
|       E       |     5000054      |           |      false      |                DESPESAS OCUPAÇÃO (Sintético)                 |      3.4.      |
|       E       |     5000055      |           |      false      |                 ENERGIA ELETRICA (Sintético)                 |     3.4.1.     |
|       E       |     5000056      |           |      false      |               ENERGIA ELETRICA-ADMINISTRATIVO                |    3.4.1.1.    |
|       E       |     5000057      |           |      false      |                  ENERGIA ELETRICA-PRODUÇÃO                   |    3.4.1.2.    |
|       E       |     5000058      |           |      false      |                  ÁGUA E ESGOTO (Sintético)                   |     3.4.2.     |
|       E       |     5000059      |           |      false      |                 ÁGUA E ESGOTO-ADMINISTRATIVO                 |    3.4.2.1.    |
|       E       |     5000060      |           |      false      |                    ÁGUA E ESGOTO-PRODUÇÃO                    |    3.4.2.2.    |
|       E       |     5000061      |           |      false      |                        TELEFONIA FIXA                        |     3.4.3.     |
|       E       |     5000062      |           |      false      |                       TELEFONIA MOVEL                        |     3.4.4.     |
|       E       |     5000063      |           |      false      |               DESPESAS ASSESSORIA (Sintético)                |      3.5.      |
|       E       |     5000064      |           |      false      |                     ASSESSORIA CONTÁBIL                      |     3.5.1.     |
|       E       |     5000065      |           |      false      |                     ASSESSORIA JURÍDICA                      |     3.5.2.     |
|       E       |     5000066      |           |      false      |                     ASSESSORIA EM GESTÃO                     |     3.5.3.     |
|       E       |     5000067      |           |      false      |       DESPESAS COM MAQUINAS E EQUIPAMENTOS (Sintético)       |      3.6.      |
|       E       |     5000068      |           |      false      |                          MANUTENÇÃO                          |     3.6.1      |
|       E       |     5000069      |           |      false      |                           SEGUROS                            |     3.6.2      |
|       E       |     5000070      |           |      false      |                    TROCA DE OLEO | FILTRO                    |     3.6.3      |
|       E       |     5000071      |           |      false      |               AQUISIÇÃO DE PEÇAS | COMPONENTES               |     3.6.4      |
|       E       |     5000072      |           |      false      |      DESPESAS MANUTENÇÃO E REFORMA PREDIAL (Sintético)       |      3.7.      |
|       E       |     5000073      |           |      false      |                   MÃO DE OBRA DE SERVIÇOS                    |     3.7.1.     |
|       E       |     5000074      |           |      false      |                    AQUISIÇÃO DE MATERIAIS                    |     3.7.2.     |
|       E       |     5000075      |           |      false      |               AQUISIÇÃO DE MATERIAIS ELÉTRICOS               |     3.7.3.     |
|       E       |     5000076      |           |      false      |              AQUISIÇÃO DE MATERIAIS HIDRÁULICOS              |     3.7.4.     |
|       E       |     5000077      |           |      false      |              AQUISIÇÃO E RECARGA DE EXTINTORES               |     3.7.5.     |
|       E       |     5000078      |           |      false      |                   LOCAÇÃO DE EQUIPAMENTOS                    |     3.7.6.     |
|       E       |     5000079      |           |      false      |              DESPESAS COM PROJETOS (Sintético)               |      3.8.      |
|       E       |     5000080      |           |      false      |                       PROJETO BOMBEIRO                       |     3.8.1.     |
|       E       |     5000081      |           |      false      |                   DESPESAS COM CONSTRUÇÕES                   |     3.8.2.     |
|       E       |     5000082      |           |      false      |                       ANUIDADE DO CREA                       |     3.8.3.     |
|       E       |     5000083      |           |      false      |      DESPESAS COM TECNOLOGIA DA INFORMAÇÃO (Sintético)       |      3.9.      |
|       E       |     5000084      |           |      false      |                     REDE DE COMPUTADORES                     |     3.9.1.     |
|       E       |     5000085      |           |      false      |                    SERVIÇOS DE HOSPEDAGEM                    |     3.9.2.     |
|       E       |     5000086      |           |      false      |                          PROVEDORES                          |     3.9.3.     |
|       E       |     5000087      |           |      false      |                           DOMINIO                            |     3.9.4.     |
|       E       |     5000088      |           |      false      |                             SITE                             |     3.9.5.     |
|       E       |     5000089      |           |      false      |                   PROGRAMAS INFORMATIZADOS                   |     3.9.6.     |
|       E       |     5000090      |           |      false      |           CRIAÇÃO DE ARTES GRÁFICAS | PUBLICIDADE            |     3.9.7.     |
|       E       |     5000091      |           |      false      |  AQUISIÇÃO DE EQUIPAMENTOS | APARELHOS | PEÇAS | MANUTENÇÃO  |     3.9.8.     |
|       E       |     5000092      |           |      false      |               DESPESAS DE VEÍCULOS (Sintético)               |     3.10.      |
|       E       |     5000093      |           |      false      |                          MANUTENÇÃO                          |    3.10.1.     |
|       E       |     5000094      |           |      false      |                           SEGUROS                            |    3.10.2.     |
|       E       |     5000095      |           |      false      |                         COMBUSTIVEL                          |    3.10.3.     |
|       E       |     5000096      |           |      false      |              LICENCIAMENTO DE VEÍCULOS / PLACAS              |    3.10.4.     |
|       E       |     5000097      |           |      false      |                             IPVA                             |    3.10.5.     |
|       E       |     5000098      |           |      false      |                            DPVAT                             |    3.10.6.     |
|       E       |     5000099      |           |      false      |                      MULTAS DE TRÂNSITO                      |    3.10.7.     |
|       E       |     5000100      |           |      false      |                        ESTACIONAMENTO                        |    3.10.8.     |

</div>

</div>
