<div id="d238434e1" class="table">

<div class="table-title">

Table 1. Região de Vendas
\*\*

</div>

<div class="table-contents">

|        |                  |           |           |                          |
| :----: | :--------------: | :-------: | :-------: | :----------------------: |
| Idioma | Região de Vendas | Descrição | Traduzida |           Nome           |
| pt\_BR |       101        |           |   false   |           East           |
| pt\_BR |       102        |           |   false   |           West           |
| pt\_BR |     1000001      |           |   false   |           SUL            |
| pt\_BR |     1000002      |           |   false   |         SUDESTE          |
| pt\_BR |     1000003      |           |   false   |          NORTE           |
| pt\_BR |     1000004      |           |   false   |         NORDESTE         |
| pt\_BR |     1000005      |           |   true    |   SUDESTE - SÃO PAULO    |
| pt\_BR |     1000006      |           |   false   | SUDESTE - DEMAIS ESTADOS |
| pt\_BR |     1000007      |           |   false   |       CENTRO-OESTE       |
| es\_CO |     1000000      |           |   false   |          Padrão          |
| es\_CO |     1000002      |           |   false   |         SUDESTE          |
| es\_CO |     1000007      |           |   false   |       CENTRO-OESTE       |
| es\_CO |     1000005      |           |   false   |   SUDESTE - SÃO PAULO    |
| es\_CO |     1000006      |           |   false   | SUDESTE - DEMAIS ESTADOS |
| es\_CO |     1000004      |           |   false   |         NORDESTE         |
| es\_CO |     1000003      |           |   false   |          NORTE           |
| es\_CO |     1000001      |           |   false   |           SUL            |
| es\_CO |       101        |           |   false   |           East           |
| es\_CO |       102        |           |   false   |           West           |
| pt\_BR |     1000000      |           |   false   |          Padrão          |

</div>

</div>
