<div id="d2308e1" class="table">

<div class="table-title">

Table 1. Gráfico
\*\*

</div>

<div class="table-contents">

|         |        |                                          |                 |           |                                          |             |
| :-----: | :----: | :--------------------------------------: | :-------------: | :-------: | :--------------------------------------: | :---------: |
| Gráfico | Idioma |                Descrição                 |  Domain Label   | Traduzida |                   Nome                   | Range Label |
| 1500013 | es\_CO |                                          |                 |   false   |          Estoque Por Categoria           |             |
|  50000  | es\_CO |                                          | Etapa de Ventas |   true    |            Mi Flujo de Ventas            |    Valor    |
|  50001  | es\_CO |                                          |   Oportunidad   |   true    |      Mis Oportunidades por Campaña       |   Campaña   |
|  50002  | es\_CO |                                          |       Mes       |   true    |            Ventas de este año            |    Valor    |
|  50003  | es\_CO |                                          |                 |   true    |         Mis Solicitudes Abiertas         |             |
| 1500044 | pt\_BR |                                          |                 |   true    |          Fluxo de Caixa 30 Dias          |             |
| 1500045 | pt\_BR |                                          |                 |   true    |        Vendas por Estado x Cidade        |             |
| 1500046 | pt\_BR |                                          |                 |   true    |      Analise de Curvatura de Fluxo       |             |
| 1500042 | pt\_BR |                                          |                 |   true    |           Clientes por Estado            |             |
| 1500039 | es\_CO |      Top 5 por Categoria de Produto      |                 |   false   |      Top 5 por Categoria de Produto      |             |
| 1500047 | pt\_BR |                                          |     Domain      |   true    |        Maiores Pedidos Hora x Dia        |    Range    |
| 1500040 | es\_CO | 3 - Ranking de Vendedores (3D Bar Chart) |                 |   true    | 3 - Ranking de Vendedores (3D Bar Chart) |             |
| 1500042 | es\_CO |   2 - Clientes por Estado (Ring Chart)   |                 |   false   |   2 - Clientes por Estado (Ring Chart)   |             |
| 1500039 | pt\_BR |                                          |                 |   true    |      Top 5 por Categoria de Produto      |             |
| 1500043 | es\_CO | 4 - Vendas Por Categoria 30 dias (Radar) |                 |   false   | 4 - Vendas Por Categoria 30 dias (Radar) |             |
| 1500044 | es\_CO |    5 - Fluxo de Caixa 30 Dias (Line)     |                 |   false   |    5 - Fluxo de Caixa 30 Dias (Line)     |             |
| 1500045 | es\_CO | 6 - Vendas por Estado x Cidade (Bubble)  |                 |   false   | 6 - Vendas por Estado x Cidade (Bubble)  |             |
| 1500046 | es\_CO |    8 - Analise de Curvatura de Fluxo     |                 |   false   |    8 - Analise de Curvatura de Fluxo     |             |
| 1500047 | es\_CO |  9 - Maiores Pedidos Hora x Dia(Bubble)  |     Domain      |   false   |  9 - Maiores Pedidos Hora x Dia(Bubble)  |    Range    |
| 1500040 | pt\_BR |                                          |                 |   true    |          Ranking de Vendedores           |             |
| 1500043 | pt\_BR |                                          |                 |   true    |       Vendas Por Categoria 30 dias       |             |
|  50000  | pt\_BR |                                          |   Sales Stage   |   false   |            My Sales Pipeline             |    Value    |
|  50001  | pt\_BR |                                          |   Opportunity   |   false   |       My Opportunities by Campaign       |  Campaign   |
|  50002  | pt\_BR |                                          |      Month      |   false   |                Sales YTD                 |    Value    |
|  50003  | pt\_BR |                                          |                 |   false   |             My Open Requests             |             |
| 1500013 | pt\_BR |                                          |                 |   false   |          Estoque Por Categoria           |             |

</div>

</div>
