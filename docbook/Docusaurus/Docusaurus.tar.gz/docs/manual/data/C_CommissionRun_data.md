<div id="d159195e1" class="table">

<div class="table-title">

Table 1. Cálculo de
Comissão

</div>

<div class="table-contents">

|          |                     |        |                               |                     |             |            |                 |                       |
| :------: | :-----------------: | :----: | :---------------------------: | :-----------------: | :---------: | :--------: | :-------------: | :-------------------: |
| Comissão | Cálculo de Comissão | Fatura |           Descrição           | Número do Documento | Total Geral | Processado | Processar Agora |    Data de Início     |
| 5000000  |       5000002       |        | 01/02/2018 - 23/02/2018 - BRL |       1000000       |     0.0     |   false    |      false      | 2018-01-01 00:00:00.0 |

</div>

</div>
