<div id="d132197e1" class="table">

<div class="table-title">

Table 1. COF\_Guarantors\_ID

</div>

<div class="table-contents">

|                         |                     |           |           |             |           |      |
| :---------------------: | :-----------------: | :-------: | :-------: | :---------: | :-------: | :--: |
| COF\_CreditAnalysis\_ID | COF\_Guarantors\_ID | Profissão | Descrição |     CPF     |    RG     | Nome |
|         5000003         |       5000000       |  hdhghd   |   eeee    | 22105523897 | 455637474 | dddd |

</div>

</div>
