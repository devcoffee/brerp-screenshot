<div id="d238270e1" class="table">

<div class="table-title">

Table 1. Quantidade de Linha de
SdC

</div>

<div class="table-contents">

|                     |                          |              |                            |     |                     |                      |                |          |                 |            |
| :-----------------: | :----------------------: | :----------: | :------------------------: | :-: | :-----------------: | :------------------: | :------------: | :------: | :-------------: | :--------: |
| Preço de Referência | Melhor Valor de Resposta | Linha de SdC | Quantidade de Linha de SdC | UDM | Quantidade Ofertada | Quantidade de Compra | Quantidade SdC | Margem % | Valor da Oferta | Quantidade |
|          0          |            0             |     100      |            100             | 100 |        false        |        false         |      true      |    0     |        0        |    100     |
|          0          |            0             |     101      |            101             | 100 |        false        |        false         |      true      |    0     |        0        |     50     |

</div>

</div>
