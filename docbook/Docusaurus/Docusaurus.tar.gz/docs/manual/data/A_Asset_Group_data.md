<div id="d111597e1" class="table">

<div class="table-title">

Table 1. Grupo de
Ativo

</div>

<div class="table-contents">

|                 |                |               |                            |                                                        |                  |        |           |         |                  |          |              |                           |
| :-------------: | :------------: | :-----------: | :------------------------: | :----------------------------------------------------: | :--------------: | :----: | :-------: | :-----: | :--------------: | :------: | :----------: | :-----------------------: |
| Classe do Ativo | Grupo de Ativo | Tipo do Ativo |         Descrição          |                    Comentário/Ajuda                    | Criar como Ativo | Padrão | Depreciar | É Ativo | Um ativo por UDM | Em Poder | Track Issues |           Nome            |
|                 |      100       |               |   Download Documentation   |                                                        |       true       | false  |   true    |  true   |      false       |  false   |    false     |       Documentation       |
|                 |     50000      |               |         Buildings          |                     All Buildings                      |       true       | false  |   true    |  true   |      false       |   true   |    false     |         Buildings         |
|                 |     50001      |               |          Software          |                        Software                        |       true       | false  |   true    |  true   |      false       |   true   |    false     |         Software          |
|                 |     50002      |               |   Download Documentation   |                                                        |       true       | false  |   true    |  true   |      false       |  false   |    false     |       Documentation       |
|                 |     50003      |               | Data Processing Equipment  |        Group defines Data Processing Equipment         |       true       | false  |   true    |  true   |      false       |   true   |    false     | Data Processing Equipment |
|                 |     50004      |               |         Furniture          |       Office furniture including office and shop       |       true       | false  |   true    |  true   |      false       |   true   |    false     |         Furniture         |
|                 |     50005      |               |          Fixtures          |           Fixtures including tools %26 dies            |       true       | false  |   true    |  true   |      false       |   true   |    false     |         Fixtures          |
|                 |     50006      |               | Trucks Cars Vans Forklifts |                      All vehicles                      |       true       | false  |   true    |  true   |      false       |   true   |    false     |         Vehicles          |
|                 |     50007      |               |         Equipment          | Light equipment including test equipment and computers |       true       | false  |   true    |  true   |      false       |   true   |    false     |         Equipment         |
|                 |    5000000     |               |            G-at            |                                                        |       true       | false  |   true    |  true   |      false       |   true   |    false     |           G-at            |
|                 |    5000001     |               |                            |                                                        |       true       | false  |   false   |  true   |      false       |  false   |    false     |  maquinas e equipamentos  |

</div>

</div>
