<div id="d254391e1" class="table">

<div class="table-title">

Table 1. Orçamento

</div>

<div class="table-contents">

|                     |           |           |          |               |
| :-----------------: | :-------: | :-------: | :------: | :-----------: |
| Estado do Orçamento | Descrição | Orçamento | Primário |     Nome      |
|          D          |           |    100    |  false   | Target Budget |

</div>

</div>
