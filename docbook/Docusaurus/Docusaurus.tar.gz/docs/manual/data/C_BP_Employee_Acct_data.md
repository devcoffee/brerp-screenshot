<div id="d144642e1" class="table">

<div class="table-title">

Table 1. C\_BP\_Employee\_Acct

</div>

<div class="table-contents">

|                  |                      |
| :--------------: | :------------------: |
| Esquema Contábil | Parceiro de Negócios |
|       101        |         112          |
|       101        |         113          |
|       101        |         114          |
|       101        |         117          |
|       101        |         118          |
|       101        |         119          |
|       101        |         120          |
|       101        |         121          |
|       101        |        50000         |
|       101        |        50001         |
|       101        |        50002         |
|       101        |        50003         |
|       101        |        50004         |
|       101        |        50005         |
|       101        |        50007         |
|       101        |        50008         |
|       101        |        50009         |

</div>

</div>
