<div id="d140068e1" class="table">

<div class="table-title">

Table 1. Elemento do Esquema
Contábil

</div>

<div class="table-contents">

|        |                              |                  |           |                      |          |          |                    |          |         |                  |      |             |             |         |                          |           |  |
| :----: | :--------------------------: | :--------------: | :-------: | :------------------: | :------: | :------: | :----------------: | :------: | :-----: | :--------------: | :--: | :---------: | :---------: | :-----: | :----------------------: | :-------: |  |
| Coluna | Elemento do Esquema Contábil | Esquema Contábil | Atividade | Parceiro de Negócios | Campanha | Elemento | Elemento de Contas | Endereço | Projeto | Região de Vendas | Tipo | Equilibrado | Obrigatório | Produto |           Nome           | Seqüência |  |
|        |             106              |       101        |           |                      |          |          |                    |          |         |                  |  OO  |    true     |    true     |         |       Organization       |    10     |  |
|        |             107              |       101        |           |                      |          |          |                    |          |         |                  |  PR  |    false    |    false    |   122   |         Product          |    30     |  |
|        |             108              |       101        |           |                      |          |          |                    |          |   100   |                  |  PJ  |    false    |    false    |         |         Project          |    50     |  |
|        |             109              |       101        |           |                      |          |   105    |        697         |          |         |                  |  AC  |    false    |    true     |         |         Account          |    20     |  |
|        |             110              |       101        |           |         112          |          |          |                    |          |         |                  |  BP  |    false    |    false    |         |       Bus.Partner        |    40     |  |
|        |             111              |       101        |           |                      |   101    |          |                    |          |         |                  |  MC  |    false    |    false    |         |         Campaign         |    60     |  |
|        |           1000003            |     1000001      |           |                      |          |          |                    |          |         |                  |  OO  |    true     |    true     |         |       Organização        |    10     |  |
|        |           1000002            |     1000001      |           |       1000000        |          |          |                    |          |         |                  |  BP  |    false    |    false    |         |         Parceiro         |    40     |  |
|        |           1000001            |     1000001      |           |                      |          |          |                    |          |         |                  |  PR  |    false    |    false    | 1000000 |         Produto          |    30     |  |
|        |           1000000            |     1000001      |           |                      |          | 1000000  |      1000777       |          |         |                  |  AC  |    false    |    true     |         |          Conta           |    20     |  |
|        |           5000000            |     1000001      |           |                      |          | 5000001  |      5000002       |          |         |                  |  U1  |    true     |    false    |         |       Centro Custo       |    50     |  |
|        |           5000001            |     1000001      |           |                      |          | 5000003  |      5000040       |          |         |                  |  U2  |    true     |    false    |         | Metodo de Contabilização |    60     |  |
|        |           5000002            |     1000001      |  1000000  |                      |          | 5000003  |      5000040       |          |         |                  |  AY  |    true     |    true     |         |        Atividade         |    70     |  |
|        |           5000003            |     1000001      |           |                      |          |          |                    |          |         |     1000000      |  SR  |    true     |    true     |         |     Região de Vendas     |    80     |  |
|        |           5000004            |     1000001      |           |                      | 1000000  |          |                    |          |         |                  |  MC  |    true     |    false    |         |         Campanha         |    90     |  |
|        |           5000006            |     1000001      |           |                      |          |          |                    |          |         |                  |  LT  |    false    |    false    |         |   Localização Destino    |    110    |  |
|        |           5000007            |     1000001      |           |                      |          |          |                    |          |         |                  |  LF  |    false    |    false    |         |    Localização Origem    |    120    |  |
|        |           5000008            |     1000001      |           |                      |          |          |                    |          |         |                  |  PJ  |    false    |    false    |         |         Projeto          |    130    |  |

</div>

</div>
