<div id="d255828e1" class="table">

<div class="table-title">

Table 1. Diário

</div>

<div class="table-contents">

|                  |                   |          |                   |                   |           |                      |      |                       |                       |              |                   |                     |                     |           |                          |             |         |          |          |         |                    |            |                   |                 |                |               |               |
| :--------------: | :---------------: | :------: | :---------------: | :---------------: | :-------: | :------------------: | :--: | :-------------------: | :-------------------: | :----------: | :---------------: | :-----------------: | :-----------------: | :-------: | :----------------------: | :---------: | :-----: | :------: | :------: | :-----: | :----------------: | :--------: | :---------------: | :-------------: | :------------: | :-----------: | :-----------: |
| Esquema Contábil | Tipo de Conversão | Moeda De | Tipo de Documento | Valor de Controle | Copiar de | Período (Ano Fiscal) | Taxa |     Data da Conta     |   Data do Documento   |  Descrição   | Ação do Documento | Estado do Documento | Número do Documento | Orçamento | Categoria de Razão Geral | Lote Diário | Diário  | Aprovado | Impresso | Lançado | Tipo de Lançamento | Processado |   Processado Em   | Processar Agora | ID de Reversão | Crédito Total | Débito Total  |
|       101        |        114        |   100    |        115        |         0         |           |         155          |  1   | 2002-08-10 00:00:00.0 | 2002-08-10 00:00:00.0 | Intercompany |        \--        |         CO          |        1001         |           |           108            |     100     |   100   |   true   |  false   |  true   |         A          |    true    |   1029022829000   |      false      |                |      100      |      100      |
|     1000001      |        114        |   297    |      1000040      |        0.0        |           |       5000024        | 1.0  | 2018-01-31 00:00:00.0 | 2018-01-31 00:00:00.0 |    teste     |        CO         |         IP          |          1          |           |            0             |             | 5000000 |   true   |  false   |  false  |         C          |   false    | 1518443833960.961 |      false      |                | 72.3700000000 | 72.3700000000 |

</div>

</div>
