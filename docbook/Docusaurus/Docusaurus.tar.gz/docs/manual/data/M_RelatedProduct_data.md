<div id="d459257e1" class="table">

<div class="table-title">

Table 1. Product
Related

</div>

<div class="table-contents">

|           |         |                                            |                     |                             |
| :-------: | :-----: | :----------------------------------------: | :-----------------: | :-------------------------: |
| Descrição | Produto |                    Nome                    | Produto Relacionado | Tipo de Produto Relacionado |
|           |   128   |           Consider a Holly Bush            |         129         |              A              |
|           | 5000017 |    Produto Padrão FCI|CEST - Importado     |       5000002       |              A              |
|           | 5000018 |   Produto Revenda nacional – FCI/IPI/ST    |       5000017       |              A              |
|           | 5000012 |    Produto Padrão FCI|CEST – Importado     |       5000002       |              A              |
|           | 5000022 | Produto Revenda Nacional – Deson. ICMS 30% |       5000021       |              P              |
|           | 5000023 |   Produto Rev Nacional – Deson. ICMS 30%   |       5000021       |              P              |

</div>

</div>
