<div id="d444184e1" class="table">

<div class="table-title">

Table 1. Categoria de Produto
\*\*

</div>

<div class="table-contents">

|        |                          |           |                      |                           |
| :----: | :----------------------: | :-------: | :------------------: | :-----------------------: |
| Idioma |        Descrição         | Traduzida | Categoria de Produto |           Nome            |
| pt\_BR |                          |   false   |         105          |         Standard          |
| pt\_BR |                          |   false   |         106          |           Trees           |
| pt\_BR |                          |   false   |         107          |          Bushes           |
| pt\_BR |       Garden Tools       |   false   |         108          |           Tools           |
| pt\_BR |      Lawn Chemicals      |   false   |         109          |         Chemicals         |
| pt\_BR | Patio and Lawn Furniture |   false   |         110          |           Patio           |
| pt\_BR |  Documentation Download  |   false   |         111          |       Documentation       |
| pt\_BR |                          |   false   |         112          |         Training          |
| pt\_BR |                          |   false   |        50000         |         Assembly          |
| pt\_BR |                          |   false   |        50001         |       Raw Material        |
| pt\_BR |                          |   false   |        50002         |          Packing          |
| pt\_BR |                          |   false   |        50003         |         Resources         |
| pt\_BR |                          |   false   |       1000001        |         Serviços          |
| pt\_BR |                          |   false   |       1000002        |       Matéria Prima       |
| pt\_BR |                          |   false   |       1000003        |       Uso e Consumo       |
| pt\_BR |                          |   false   |       1000005        |           Grãos           |
| pt\_BR |                          |   false   |       1000006        |       Café Gourmet        |
| pt\_BR |                          |   false   |       1000007        |   Máquinas de Expresso    |
| pt\_BR |                          |   true    |       1000008        | Acessórios %26 Utensílios |
| pt\_BR |                          |   false   |       1000009        |      Acompanhamentos      |
| pt\_BR |                          |   false   |       1000010        |         Presentes         |
| es\_CO |                          |   false   |       1000000        |          Padrão           |
| es\_CO |                          |   false   |       1000001        |         Serviços          |
| es\_CO |                          |   false   |       1000002        |       Matéria Prima       |
| es\_CO |                          |   false   |         105          |         Standard          |
| es\_CO |                          |   false   |         106          |           Trees           |
| es\_CO |                          |   false   |         107          |          Bushes           |
| es\_CO |       Garden Tools       |   false   |         108          |           Tools           |
| es\_CO |      Lawn Chemicals      |   false   |         109          |         Chemicals         |
| es\_CO | Patio and Lawn Furniture |   false   |         110          |           Patio           |
| es\_CO |  Documentation Download  |   false   |         111          |       Documentation       |
| es\_CO |                          |   false   |         112          |         Training          |
| es\_CO |                          |   false   |        50000         |         Assembly          |
| es\_CO |                          |   false   |        50001         |       Raw Material        |
| es\_CO |                          |   false   |        50002         |          Packing          |
| es\_CO |                          |   false   |        50003         |         Resources         |
| es\_CO |                          |   false   |       1000003        |       Uso e Consumo       |
| es\_CO |                          |   false   |       1000005        |           Grãos           |
| es\_CO |                          |   false   |       1000006        |       Café Gourmet        |
| es\_CO |                          |   false   |       1000007        |   Máquinas de Expresso    |
| es\_CO |                          |   false   |       1000008        | Acessórios %26 Utensílios |
| es\_CO |                          |   false   |       1000009        |      Acompanhamentos      |
| es\_CO |                          |   false   |       1000010        |         Presentes         |
| pt\_BR |                          |   false   |       1000000        |          Padrão           |
| pt\_BR |                          |   true    |       1000004        |   GERAL TESTES - ATIVO    |
| es\_CO |                          |   true    |       1000004        |   GERAL TESTES - ATIVO    |
| pt\_BR |                          |   true    |       5000002        |  GERAL TESTES - PRODUTOS  |
| es\_CO |                          |   true    |       5000002        |  GERAL TESTES - PRODUTOS  |

</div>

</div>
