<div id="d84166e1" class="table">

<div class="table-title">

Table 1. AD\_Task\_Access

</div>

<div class="table-contents">

|        |           |                   |
| :----: | :-------: | :---------------: |
| Perfil | Tarefa SO | Escrita e Leitura |
|   0    |    102    |       true        |
|   0    |    103    |       true        |
|   0    |    104    |       true        |

</div>

</div>
