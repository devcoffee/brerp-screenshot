<div id="d119223e1" class="table">

<div class="table-title">

Table 1. Ocorrência
Bancária

</div>

<div class="table-contents">

|         |                     |                      |                    |                                                  |                                                              |                |
| :-----: | :-----------------: | :------------------: | :----------------: | :----------------------------------------------: | :----------------------------------------------------------: | :------------: |
|  Banco  | Ocorrência Bancária | Código da Ocorrência | Tipo da Ocorrência |                    Descrição                     |                             Nome                             | Chave de Busca |
| 1000000 |       1000001       |          02          |         O          |                                                  | 02..Entrada Confirmada (verificar motivo na posição 319 a 32 |       02       |
| 1000000 |       1000002       |          03          |         O          |                                                  | 03..Entrada Rejeitada ( verificar motivo na posição 319 a 32 |       03       |
| 1000000 |       1000000       |          06          |         L          |                                                  |              06..Liquidação normal (sem motivo)              |       06       |
| 1000000 |       1000004       |          09          |         L          |                                                  | 09..Baixado Automat. via Arquivo (verificar motivo posição 3 |       09       |
| 1000000 |       1000005       |          10          |         O          |                                                  | 10..Baixado conforme instruções da Agência(verificar motivo  |       10       |
| 1000000 |       1000006       |          11          |         O          |                                                  |    11..Em Ser - Arquivo de Títulos pendentes (sem motivo)    |       11       |
| 1000000 |       1000007       |          12          |         O          |                                                  |            12..Abatimento Concedido (sem motivo)             |       12       |
| 1000000 |       1000008       |          13          |         O          |                                                  |            13..Abatimento Cancelado (sem motivo)             |       13       |
| 1000000 |       1000009       |          14          |         O          |                                                  |             14..Vencimento Alterado (sem motivo)             |       14       |
| 5000003 |       5000000       |          02          |         E          | ENTRADA CONFIRMADA COM POSSIBILIDADE DE MENSAGEM |       ENTRADA CONFIRMADA COM POSSIBILIDADE DE MENSAGEM       |       02       |
| 5000000 |       5000001       |          6           |         M          |                                                  |                         BAIXA MANUAL                         |       6        |
| 5000003 |       5000002       |          6           |         M          |                                                  |                         BAIXA MANUAL                         |       6        |
| 5000003 |       5000003       |          01          |         M          |                                                  |                                                              |    1000000     |
|         |       5000004       |          02          |         M          |                                                  |                                                              |    1000001     |

</div>

</div>
