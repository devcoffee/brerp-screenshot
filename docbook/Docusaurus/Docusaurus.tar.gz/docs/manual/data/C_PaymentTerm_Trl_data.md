<div id="d227565e1" class="table">

<div class="table-title">

Table 1. Condição de Pagamento
\*\*

</div>

<div class="table-contents">

|        |                       |                                                        |                                                                                              |           |                                |
| :----: | :-------------------: | :----------------------------------------------------: | :------------------------------------------------------------------------------------------: | :-------: | :----------------------------: |
| Idioma | Condição de Pagamento |                       Descrição                        |                                      Nota de Documento                                       | Traduzida |              Nome              |
| pt\_BR |          100          |                                                        |                                                                                              |   true    |             30 Net             |
| pt\_BR |          105          |                                                        |                                                                                              |   true    |           Immediate            |
| pt\_BR |          106          |   2% discount if paid in 10 days, net due in 30 days   |          Payment Term Note: Long Term Contracts are eligible for payment discounts.          |   true    |          2%10 Net 30           |
| pt\_BR |          107          |                                                        |                                                                                              |   true    |          30 Days Net           |
| pt\_BR |          108          |                                                        |                                                                                              |   true    | 50% Immediate - 50% in 30 days |
| es\_CO |        1000002        |                                                        |                                                                                              |   false   |          Fixo dia 10           |
| es\_CO |        1000003        |                                                        |                                                                                              |   false   |        Fixo as Segundas        |
| es\_CO |        1000001        |                                                        |                                                                                              |   false   |           30/60 dias           |
| es\_CO |        1000000        |                                                        |                                                                                              |   false   |            Á Vista             |
| es\_CO |        5000000        |                       Programado                       |                                                                                              |   false   |           Programado           |
| es\_CO |          100          |                                                        |                                                                                              |   true    |            30 Neto             |
| es\_CO |          105          |                                                        |                                                                                              |   true    |           Inmediato            |
| es\_CO |          106          | 2% descuento si pago en 10 días, deuda neta en 30 días | Nota Término de Pago: Contratos a Largo Plazo son elegibles para descuentos por pronto pago. |   true    |          2%10 Neto 30          |
| es\_CO |          107          |                                                        |                                                                                              |   true    |          30 Días Neto          |
| es\_CO |          108          |                                                        |                                                                                              |   true    | 50% Inmediato - 50% en 30 días |
| pt\_BR |        1000000        |                                                        |                                                                                              |   false   |            Á Vista             |
| pt\_BR |        1000001        |                                                        |                                                                                              |   false   |           30/60 dias           |
| pt\_BR |        1000002        |                                                        |                                                                                              |   false   |          Fixo dia 10           |
| pt\_BR |        1000003        |                                                        |                                                                                              |   true    |        Fixo as Segundas        |
| pt\_BR |        5000000        |                       Programado                       |                                                                                              |   true    |           Programado           |
| pt\_BR |        5000001        |                                                        |                                                                                              |   false   |            10 vezes            |
| es\_CO |        5000001        |                                                        |                                                                                              |   false   |            10 vezes            |
| pt\_BR |        5000002        |                          25dd                          |                                                                                              |   false   |              25dd              |
| es\_CO |        5000002        |                          25dd                          |                                                                                              |   false   |              25dd              |

</div>

</div>
