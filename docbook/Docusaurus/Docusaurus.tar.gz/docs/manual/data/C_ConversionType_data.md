<div id="d159295e1" class="table">

<div class="table-title">

Table 1. Tipo de
Conversão

</div>

<div class="table-contents">

|                   |                             |        |            |                |
| :---------------: | :-------------------------: | :----: | :--------: | :------------: |
| Tipo de Conversão |          Descrição          | Padrão |    Nome    | Chave de Busca |
|        114        | Spot Conversation Rate Type |  true  |    Spot    |       S        |
|        115        |   Period Conversion Type    | false  | Period End |       P        |
|        200        |        Average Rates        | false  |  Average   |       A        |
|        201        |        Company Rate         | false  |  Company   |       C        |

</div>

</div>
