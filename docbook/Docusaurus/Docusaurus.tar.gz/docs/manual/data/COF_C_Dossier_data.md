<div id="d124717e1" class="table">

<div class="table-title">

Table 1. COF\_C\_Dossier\_ID

</div>

<div class="table-contents">

|                      |                     |                         |                       |                  |
| :------------------: | :-----------------: | :---------------------: | :-------------------: | :--------------: |
| Parceiro de Negócios | COF\_C\_Dossier\_ID | COF\_CreditAnalysis\_ID |   Data do Documento   |    Descrição     |
|       5000000        |       5000000       |         5000000         | 2018-01-25 00:00:00.0 | validado crédito |
|       5000000        |       5000001       |         5000001         | 2018-01-30 00:00:00.0 | teste de analise |
|       5000000        |       5000002       |         5000003         | 2018-01-25 00:00:00.0 |     fffffff      |
|       5000000        |       5000003       |         5000000         | 2018-01-25 00:00:00.0 |        ok        |
|       5000000        |       5000004       |         5000001         | 2018-01-30 00:00:00.0 |       okok       |

</div>

</div>
