<div id="d409552e1" class="table">

<div class="table-title">

Table 1. Localizador

</div>

<div class="table-contents">

|                       |                     |                    |                    |                    |         |
| :-------------------: | :-----------------: | :----------------: | :----------------: | :----------------: | :-----: |
|    Chave de Busca     | Prioridade Relativa |    Corredor (X)    |    Estante (Y)     |     Nível (Z)      | Armazém |
|  Default HQ Locator   |         50          |         0          |         0          |         0          |   103   |
|      HQ Transit       |         50          |     HQ Transit     |     HQ Transit     |     HQ Transit     |  50000  |
|      Store South      |         50          |    Store South     |    Store South     |    Store South     |  50004  |
|      Store North      |         50          |    Store North     |    Store North     |    Store North     |  50003  |
|      Fertilizer       |         50          |     Fertilizer     |     Fertilizer     |     Fertilizer     |  50002  |
|       Furniture       |         50          |     Furniture      |     Furniture      |     Furniture      |  50001  |
|      Store East       |         50          |     Store East     |     Store East     |     Store East     |  50005  |
|      Store West       |         50          |     Store West     |     Store West     |     Store West     |  50006  |
| Default Store Locator |         50          |         0          |         0          |         0          |   104   |
|  Fertilizer Transit   |         50          | Fertilizer Transit | Fertilizer Transit | Fertilizer Transit |  50007  |
|   Furniture Transit   |         50          | Furniture Transit  | Furniture Transit  | Furniture Transit  |  50008  |
|        Padrão         |         50          |         0          |         0          |         0          | 1000002 |
|      MGS Padrao       |         50          |         1          |         1          |         1          | 5000002 |
|      2 \* 2 \* 2      |         50          |         2          |         2          |         2          | 1000002 |
|      1 \* 1 \* 0      |         50          |         1          |         1          |         0          | 1000002 |
|      1 \* 0 \* 0      |         50          |         1          |         0          |         0          | 1000002 |
|         UC01          |         50          |         a          |         b          |         c          | 5000003 |
|         UC02          |         50          |         1          |         2          |         3          | 5000003 |
|         RV02          |         50          |         A          |         B          |         C          | 5000004 |
|         FB02          |         50          |         2          |         3          |         4          | 5000005 |
|         MP01          |         50          |         1          |         1          |         1          | 5000006 |
|         MP02          |         50          |         1          |         2          |         1          | 5000006 |
|         RV01          |         50          |         1          |         2          |         3          | 5000004 |
|        1000001        |         50          |         a          |         a          |         a          | 5000008 |
|      Armazem PR       |         50          |         a          |         a          |         a          | 5000007 |
|      Armazém SC       |         50          |         a          |         a          |         a          | 5000010 |
|         FB01          |         50          |         1          |         2          |         3          | 5000005 |
|        1000003        |         50          |         1          |         1          |         1          | 5000011 |
|        1000004        |         50          |         1          |         1          |         1          | 5000013 |

</div>

</div>
