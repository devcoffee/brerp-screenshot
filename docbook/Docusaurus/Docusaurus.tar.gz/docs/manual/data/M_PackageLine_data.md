<div id="d439787e1" class="table">

<div class="table-title">

Table 1. Linha de
Embalagem

</div>

<div class="table-contents">

|           |                              |           |                    |             |         |            |
| :-------: | :--------------------------: | :-------: | :----------------: | :---------: | :-----: | :--------: |
| Descrição | Linha de Remessa/Recebimento | Embalagem | Linha de Embalagem | Package MPS | Produto | Quantidade |
|           |             126              |    100    |        100         |             |         |     10     |

</div>

</div>
