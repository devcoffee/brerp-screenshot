<div id="d11229e1" class="table">

<div class="table-title">

Table 1. Grupo de Campo
\*\*

</div>

<div class="table-contents">

|                |        |         |               |           |                                              |
| :------------: | :----: | :-----: | :-----------: | :-------: | :------------------------------------------: |
| Grupo de Campo | Idioma | Checked | Pré Traduzido | Traduzida |                     Nome                     |
|      102       | es\_CO |         |               |   true    |                  Cantidades                  |
|      103       | es\_CO |         |               |   true    |                   Totales                    |
|      104       | es\_CO |         |               |   true    |                  Referencia                  |
|      105       | es\_CO |         |               |   true    |                   Historia                   |
|      106       | es\_CO |         |               |   true    |                   Producto                   |
|      107       | es\_CO |         |               |   true    |                   Tercero                    |
|      108       | es\_CO |         |               |   true    |                   Almacén                    |
|      109       | es\_CO |         |               |   true    |              Cuentas Banco/Caja              |
|      110       | es\_CO |         |               |   true    |               Cuentas Caja PDV               |
|      111       | es\_CO |         |               |   true    |               Cuentas Impuesto               |
|      113       | es\_CO |         |               |   true    |                   General                    |
|      114       | es\_CO |         |               |   true    |                    Acción                    |
|      115       | es\_CO |         |               |   true    |                Costo Estándar                |
|      116       | es\_CO |         |               |   true    |               Costos Actuales                |
|      117       | es\_CO |         |               |   true    |                 Estadísticas                 |
|      118       | es\_CO |         |               |   true    |               Predeterminados                |
|      119       | es\_CO |         |               |   true    |            Gestión de Solicitudes            |
|      120       | es\_CO |         |               |   true    |                  Tienda Web                  |
|      121       | es\_CO |         |               |   true    |                   Interno                    |
|      122       | es\_CO |         |               |   true    |                   Externo                    |
|      123       | es\_CO |         |               |   true    |                    Común                     |
|      124       | es\_CO |         |               |   true    |                    Envío                     |
|      125       | es\_CO |         |               |   true    |                  Documento                   |
|      126       | es\_CO |         |               |   true    |                    Línea                     |
|      127       | es\_CO |         |               |   true    |                  Simulación                  |
|      128       | es\_CO |         |               |   true    |                   Cálculos                   |
|      129       | es\_CO |         |               |   true    |                  Apoderado                   |
|      130       | es\_CO |         |               |   true    |                   Entrega                    |
|      131       | es\_CO |         |               |   true    |                 Facturación                  |
|      132       | es\_CO |         |               |   true    |                   Sólo ..                    |
|      133       | es\_CO |         |               |   true    |                  Selección                   |
|      134       | es\_CO |         |               |   true    |               Flujo de Trabajo               |
|      135       | es\_CO |         |               |   true    |                    Acceso                    |
|     50000      | es\_CO |         |               |   true    |         Permitir información en rol          |
|     50001      | es\_CO |         |               |   true    |                   Cuentas                    |
|     50002      | es\_CO |         |               |   true    |                Configuración                 |
|     50003      | es\_CO |         |               |   true    |                    Fechas                    |
|     50004      | es\_CO |         |               |   true    |           Cuentas de Reevaluación            |
|     50005      | es\_CO |         |               |   true    |                   Contrato                   |
|     50006      | es\_CO |         |               |   true    |                   Opciones                   |
|     50007      | es\_CO |         |               |   true    |             Contabilidad General             |
|     50008      | es\_CO |         |               |   true    |                   Máquinas                   |
|     50009      | es\_CO |         |               |   true    |                Base de Datos                 |
|     50010      | es\_CO |         |               |   true    |             Cuentas Manufactura              |
|     50012      | es\_CO |         |               |   true    |                     Logo                     |
|     200003     | es\_CO |         |               |   true    |               Bloqueo Usuario                |
|     200005     | es\_CO |         |               |   true    |             Información Cliente              |
|     200006     | es\_CO |         |               |   true    |            Información Proveedor             |
|     200007     | es\_CO |         |               |   true    |              Información Ventas              |
|     200008     | es\_CO |         |               |   true    |          Preferencias de Documentos          |
|     200009     | es\_CO |         |               |   true    |                 Cuenta Cargo                 |
|    1100000     | es\_CO |         |               |   false   |                Envio de Lote                 |
|    1100001     | es\_CO |         |               |   false   |               Resposta do Lote               |
|    1100002     | es\_CO |         |               |   false   |                     NF-e                     |
|     200008     | pt\_BR |         |               |   true    |          Preferências de Documentos          |
|    1106000     | es\_CO |         |               |   false   |                  Validation                  |
|    1120009     | es\_CO |         |               |   false   |                   Cobranca                   |
|    1120009     | en\_US |         |               |   false   |                   Cobranca                   |
|    1120010     | es\_CO |         |               |   false   |                   Emitente                   |
|    1120010     | en\_US |         |               |   false   |                   Emitente                   |
|    1120011     | es\_CO |         |               |   false   |           Destinatario / Remetente           |
|    1120011     | en\_US |         |               |   false   |           Destinatario / Remetente           |
|    1120012     | es\_CO |         |               |   false   |                   Entrega                    |
|    1120012     | en\_US |         |               |   false   |                   Entrega                    |
|    1120013     | es\_CO |         |               |   false   |                    Fatura                    |
|    1120013     | en\_US |         |               |   false   |                    Fatura                    |
|    1120014     | es\_CO |         |               |   false   |              Calculo do Imposto              |
|    1120014     | en\_US |         |               |   false   |              Calculo do Imposto              |
|    1120015     | es\_CO |         |               |   false   |                Transportador                 |
|    1120015     | en\_US |         |               |   false   |                Transportador                 |
|    1120016     | es\_CO |         |               |   false   |           Dados do Produto/Servico           |
|    1120016     | en\_US |         |               |   false   |           Dados do Produto/Servico           |
|    1120017     | es\_CO |         |               |   false   |                     ICMS                     |
|    1120017     | en\_US |         |               |   false   |                     ICMS                     |
|    1120018     | es\_CO |         |               |   false   |         ICMS Substituicao Tributaria         |
|    1120018     | en\_US |         |               |   false   |         ICMS Substituicao Tributaria         |
|    1120019     | es\_CO |         |               |   false   |                     IPI                      |
|    1120019     | en\_US |         |               |   false   |                     IPI                      |
|    1120020     | es\_CO |         |               |   false   |               Dados Adicionais               |
|    1120020     | en\_US |         |               |   false   |               Dados Adicionais               |
|    1120021     | es\_CO |         |               |   false   |                     PIS                      |
|    1120021     | en\_US |         |               |   false   |                     PIS                      |
|    1120022     | es\_CO |         |               |   false   |                    COFINS                    |
|    1120022     | en\_US |         |               |   false   |                    COFINS                    |
|    1120023     | es\_CO |         |               |   false   |        NF-e (Nota Fiscal Eletronica)         |
|    1120023     | en\_US |         |               |   false   |        NF-e (Nota Fiscal Eletronica)         |
|    1120024     | es\_CO |         |               |   false   |                 Nota Fiscal                  |
|    1120024     | en\_US |         |               |   false   |                 Nota Fiscal                  |
|    1120025     | es\_CO |         |               |   false   |        Nota Fiscal de Produtor Rural         |
|    1120025     | en\_US |         |               |   false   |        Nota Fiscal de Produtor Rural         |
|    1120026     | es\_CO |         |               |   false   | CT-e (Conhecimento de Transporte Eletronico) |
|    1120026     | en\_US |         |               |   false   | CT-e (Conhecimento de Transporte Eletronico) |
|    1120027     | es\_CO |         |               |   false   |                     ECF                      |
|     50017      | es\_CO |         |               |   true    |                 Activo Fijo                  |
|     50018      | es\_CO |         |               |   true    |                Mantenimiento                 |
|     50019      | es\_CO |         |               |   true    |                Financiamiento                |
|     50020      | es\_CO |         |               |   true    |                 Depreciación                 |
|     200000     | es\_CO |         |               |   true    |                Posición Swing                |
|     200001     | es\_CO |         |               |   true    |                 Posición Web                 |
|     200010     | es\_CO |         |               |   true    |               Cuentas Tercero                |

</div>

</div>
