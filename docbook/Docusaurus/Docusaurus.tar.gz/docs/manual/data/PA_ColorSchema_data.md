<div id="d531361e1" class="table">

<div class="table-title">

Table 1. Esquema de
Cores

</div>

<div class="table-contents">

|       |       |       |       |                       |                  |                |                |                |                |                                 |                  |
| :---: | :---: | :---: | :---: | :-------------------: | :--------------: | :------------: | :------------: | :------------: | :------------: | :-----------------------------: | :--------------: |
| Cor 1 | Cor 2 | Cor 3 | Cor 4 |       Descrição       | Tipo de Entidade | Mark 1 Percent | Mark 2 Percent | Mark 3 Percent | Mark 4 Percent |              Nome               | Esquema de Cores |
|  103  |  113  |  102  |       |  \< 100% is the goal  |        D         |       50       |      100       |      9999      |       0        | Green (50) - Yellow (100) - Red |       101        |
|  102  |  113  |  103  |       | \> = 100% is the goal |        D         |       50       |      100       |      9999      |       0        | Red (50) - Yellow (100) - Green |       100        |
|  102  |  113  |  103  |       |          \>           |        U         |       75       |      125       |      200       |       0        |        Vermelho - Verde         |     1500014      |
|  103  |  113  |  102  |       |          \>           |        U         |       75       |      125       |      200       |       0        |         Verde-Vermelho          |     1500013      |

</div>

</div>
