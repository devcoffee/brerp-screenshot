<div id="d402856e1" class="table">

<div class="table-title">

Table 1. Categoria do Produto
(CFOP)

</div>

<div class="table-contents">

|                       |                             |                       |
| :-------------------: | :-------------------------: | :-------------------: |
|       Descrição       | Categoria do Produto (CFOP) |         Nome          |
|                       |           1000000           |       Material        |
|                       |           1000001           |     Eletricidade      |
|                       |           1000002           |      Comunicação      |
|                       |           1000003           |      Transporte       |
|                       |           1000004           |        Animal         |
| Produto ST Sustituído |           5000000           | Produto ST Sustituído |
|                       |           5000001           |  Energia Industrial   |
|                       |           5000002           |   Energia Comercial   |
|                       |           5000003           |      Alimentício      |

</div>

</div>
