<div id="d131970e1" class="table">

<div class="table-title">

Table 1. Motorista

</div>

<div class="table-contents">

|                      |           |                       |           |                       |                       |                    |         |             |                |                   |
| :------------------: | :-------: | :-------------------: | :-------: | :-------------------: | :-------------------: | :----------------: | :-----: | :---------: | :------------: | :---------------: |
| Parceiro de Negócios | Motorista |    Data Vencimento    | Bloqueado |     Data Emissão      | Categoria Habilitação | Número Habilitação | Vinculo | Notificar a |      CPF       |       Nome        |
|       5000001        |  5000000  | 2018-05-18 00:00:00.0 |   false   | 2017-12-01 00:00:00.0 |          AE           |    12222333333     |   EMP   |             | 604.623.423-95 | PF FORA DO ESTADO |

</div>

</div>
