<div id="d140392e1" class="table">

<div class="table-title">

Table 1. C\_AcctSchema\_GL

</div>

<div class="table-contents">

|                  |                           |                         |                                |                              |                             |               |                                   |                           |                            |                   |
| :--------------: | :-----------------------: | :---------------------: | :----------------------------: | :--------------------------: | :-------------------------: | :-----------: | :-------------------------------: | :-----------------------: | :------------------------: | :---------------: |
| Esquema Contábil | Ajuste de Comprometimento | Commitment Offset Sales | Conta de Contrapartida Cambial | Conta de Devido de coligadas | Conta de Devido a coligadas | Ajuste de VPC | Conta de Contrapartidas Suspensas | Use Contrapartida cambial | Use Contrapartida suspensa | Use Erro Suspenso |
|       101        |            300            |          50000          |              221               |             225              |             224             |      291      |                219                |           true            |            true            |       true        |
|     1000001      |          5000462          |         5000462         |            5000247             |           1000004            |           1000005           |    1000006    |              5000462              |           true            |            true            |       true        |

</div>

</div>
