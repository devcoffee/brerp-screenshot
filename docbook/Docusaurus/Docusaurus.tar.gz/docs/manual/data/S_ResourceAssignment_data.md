<div id="d543481e1" class="table">

<div class="table-title">

Table 1. Atribuição de
Recurso

</div>

<div class="table-contents">

|                       |                       |                    |            |               |            |                       |         |
| :-------------------: | :-------------------: | :----------------: | :--------: | :-----------: | :--------: | :-------------------: | :-----: |
|    Atribuir desde     |     Atribuir até      |     Descrição      | Confirmado |     Nome      | Quantidade | Atribuição de Recurso | Recurso |
| 2003-02-05 10:00:00.0 | 2003-02-05 13:00:00.0 | Initial Discussion |   false    | Garden Layout |     3      |          100          |   100   |
| 2003-02-05 17:00:00.0 | 2003-02-05 18:00:00.0 |   Discuss Budget   |   false    | Garden Layout |     1      |          101          |   100   |

</div>

</div>
