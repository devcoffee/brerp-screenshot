<div id="d132992e1" class="table">

<div class="table-title">

Table 1. COF\_OSProduto\_ID

</div>

<div class="table-contents">

|               |          |                    |        |                  |                    |                      |         |                          |                |             |                |         |            |
| :-----------: | :------: | :----------------: | :----: | :--------------: | :----------------: | :------------------: | :-----: | :----------------------: | :------------: | :---------: | :------------: | :-----: | :--------: |
| Baixa Estoque | Faturado | Incorporar Serviço | Motivo | Ordem de Serviço | COF\_OSProduto\_ID | Quantidade (Serviço) | Serviço | Valor Unitário (Serviço) | Valor Unitário | Total Geral | Lista de Preço | Produto | Quantidade |
|     false     |   true   |       false        |        |     5000000      |      5000000       |          0           |         |            0             |       50       |     50      |    1000005     | 5000003 |     1      |
|     false     |   true   |        true        |        |     5000000      |      5000001       |          1           | 5000026 |            20            |       15       |     35      |    1000005     | 5000003 |     1      |
|     true      |   true   |       false        |        |     5000001      |      5000002       |          0           |         |            0             |       50       |     100     |    1000005     | 5000003 |     2      |

</div>

</div>
