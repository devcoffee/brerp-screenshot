<div id="d133757e1" class="table">

<div class="table-title">

Table 1. Recursos

</div>

<div class="table-contents">

|         |           |                         |                    |          |                    |                 |                   |           |           |                 |                |
| :-----: | :-------: | :---------------------: | :----------------: | :------: | :----------------: | :-------------: | :---------------: | :-------: | :-------: | :-------------: | :------------: |
|  Ativo  | Bloqueado | Capacidade Uso em Horas | Centro de Trabalho | Recursos | Recurso Substituto | Tipo do Recurso | Ultima Manutenção | Descrição |   Nome    | Centro de Custo | Chave de Busca |
| 5000002 |   false   |           20            |      5000000       | 5000000  |                    |       ME        |                   |           | Maquina 1 |                 |    1000000     |
|         |   false   |           24            |                    | 5000001  |                    |       ME        |                   |           |   Teste   |                 |    1000001     |

</div>

</div>
