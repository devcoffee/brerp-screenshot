<div id="d106516e1" class="table">

<div class="table-title">

Table 1. Registro (log) do Processador de Fluxo de
Trabalho

</div>

<div class="table-contents">

|                                  |                                                    |                |           |       |             |                                                                 |                   |
| :------------------------------: | :------------------------------------------------: | :------------: | :-------: | :---: | :---------: | :-------------------------------------------------------------: | :---------------: |
| Processador de Fluxo de Trabalho | Registro (log) do Processador de Fluxo de Trabalho | Dados Binários | Descrição | Erro  | Referência  |                             Resumo                              | Texto de Mensagem |
|               100                |                      5004447                       |                |           | false | \#0 - 00.50 | Wakeup \#0 - DynPriority \#0 - EndWaitTime \#0 - Logs deleted=0 |                   |
|               100                |                      5004448                       |                |           | false | \#0 - 00.29 | Wakeup \#0 - DynPriority \#0 - EndWaitTime \#0 - Logs deleted=0 |                   |
|               100                |                      5004449                       |                |           | false | \#0 - 00.26 | Wakeup \#0 - DynPriority \#0 - EndWaitTime \#0 - Logs deleted=0 |                   |
|               100                |                      5004450                       |                |           | false | \#0 - 00.36 | Wakeup \#0 - DynPriority \#0 - EndWaitTime \#0 - Logs deleted=0 |                   |
|               100                |                      5004451                       |                |           | false | \#1 - 00.19 | Wakeup \#0 - DynPriority \#0 - EndWaitTime \#0 - Logs deleted=0 |                   |
|               100                |                      5004452                       |                |           | false | \#1 - 00.28 | Wakeup \#0 - DynPriority \#0 - EndWaitTime \#0 - Logs deleted=0 |                   |
|               100                |                      5004453                       |                |           | false | \#0 - 00.65 | Wakeup \#0 - DynPriority \#0 - EndWaitTime \#0 - Logs deleted=0 |                   |
|               100                |                      5004454                       |                |           | false | \#0 - 00.38 | Wakeup \#0 - DynPriority \#0 - EndWaitTime \#0 - Logs deleted=1 |                   |
|               100                |                      5004455                       |                |           | false | \#1 - 00.22 | Wakeup \#0 - DynPriority \#0 - EndWaitTime \#0 - Logs deleted=0 |                   |
|               100                |                      5004456                       |                |           | false | \#2 - 00.30 | Wakeup \#0 - DynPriority \#0 - EndWaitTime \#0 - Logs deleted=0 |                   |
|               100                |                      5004457                       |                |           | false | \#3 - 00.19 | Wakeup \#0 - DynPriority \#0 - EndWaitTime \#0 - Logs deleted=0 |                   |
|               100                |                      5004458                       |                |           | false | \#4 - 00.54 | Wakeup \#0 - DynPriority \#0 - EndWaitTime \#0 - Logs deleted=0 |                   |
|               100                |                      5004459                       |                |           | false | \#0 - 00.37 | Wakeup \#0 - DynPriority \#0 - EndWaitTime \#0 - Logs deleted=0 |                   |
|               100                |                      5004460                       |                |           | false | \#0 - 00.83 | Wakeup \#0 - DynPriority \#0 - EndWaitTime \#0 - Logs deleted=0 |                   |
|               100                |                      5004461                       |                |           | false | \#0 - 00.48 | Wakeup \#0 - DynPriority \#0 - EndWaitTime \#0 - Logs deleted=0 |                   |
|               100                |                      5004462                       |                |           | false | \#1 - 00.21 | Wakeup \#0 - DynPriority \#0 - EndWaitTime \#0 - Logs deleted=0 |                   |
|               100                |                      5004463                       |                |           | false | \#2 - 00.24 | Wakeup \#0 - DynPriority \#0 - EndWaitTime \#0 - Logs deleted=0 |                   |
|               100                |                      5004464                       |                |           | false | \#0 - 00.64 | Wakeup \#0 - DynPriority \#0 - EndWaitTime \#0 - Logs deleted=2 |                   |
|               100                |                      5004465                       |                |           | false | \#1 - 00.26 | Wakeup \#0 - DynPriority \#0 - EndWaitTime \#0 - Logs deleted=0 |                   |
|               100                |                      5004466                       |                |           | false | \#2 - 00.19 | Wakeup \#0 - DynPriority \#0 - EndWaitTime \#0 - Logs deleted=0 |                   |
|               100                |                      5004467                       |                |           | false | \#3 - 00.26 | Wakeup \#0 - DynPriority \#0 - EndWaitTime \#0 - Logs deleted=0 |                   |
|               100                |                      5004468                       |                |           | false | \#4 - 00.30 | Wakeup \#0 - DynPriority \#0 - EndWaitTime \#0 - Logs deleted=0 |                   |
|               100                |                      5004469                       |                |           | false | \#0 - 00.45 | Wakeup \#0 - DynPriority \#0 - EndWaitTime \#0 - Logs deleted=7 |                   |
|               100                |                      5004470                       |                |           | false | \#1 - 00.24 | Wakeup \#0 - DynPriority \#0 - EndWaitTime \#0 - Logs deleted=0 |                   |
|               100                |                      5004471                       |                |           | false | \#2 - 00.26 | Wakeup \#0 - DynPriority \#0 - EndWaitTime \#0 - Logs deleted=0 |                   |
|               100                |                      5004472                       |                |           | false | \#3 - 00.30 | Wakeup \#0 - DynPriority \#0 - EndWaitTime \#0 - Logs deleted=0 |                   |

</div>

</div>
