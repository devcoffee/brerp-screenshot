<div id="d156227e1" class="table">

<div class="table-title">

Table 1. Plano de
Caixa

</div>

<div class="table-contents">

|                                |           |                        |                      |          |                |           |         |                       |           |                     |                       |             |          |                     |            |                 |                   |
| :----------------------------: | :-------: | :--------------------: | :------------------: | :------: | :------------: | :-------: | :-----: | :-------------------: | :-------: | :-----------------: | :-------------------: | :---------: | :------: | :-----------------: | :--------: | :-------------: | :---------------: |
| Organização de Transação (Trx) | Atividade | Tipo de Fluxo de Caixa | Parceiro de Negócios | Campanha | Plano de Caixa | Copiar de | Projeto |   Data do Documento   | Descrição | Número do Documento | Gerar Plano Periódico | Total Geral | Aprovado | Transação de Vendas | Processado | Centro de Custo | Centro de Custo 2 |
|                                |           |                        |                      |          |    5000000     |     N     |         | 2018-02-23 00:00:00.0 |           |       1000000       |           N           |      0      |  false   |        false        |   false    |                 |                   |

</div>

</div>
