<div id="d81322e1" class="table">

<div class="table-title">

Table 1. AD\_Table\_Access

</div>

<div class="table-contents">

|                |        |        |         |                 |
| :------------: | :----: | :----: | :-----: | :-------------: |
| Tipo de Acesso | Perfil | Tabela | Excluir | Somente Leitura |
|       E        |  103   |  520   |  true   |      false      |

</div>

</div>
