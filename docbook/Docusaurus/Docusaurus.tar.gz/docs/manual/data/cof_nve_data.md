<div id="d559366e1" class="table">

<div class="table-title">

Table 1. COF\_Nve

</div>

<div class="table-contents">

|          |           |         |      |                |
| :------: | :-------: | :-----: | :--: | :------------: |
| COF\_Nve | Descrição |   NCM   | Nome | Chave de Busca |
| 5000001  |  AD0004   | 1007094 |      |     AD0004     |
| 5000002  |  AD9999   | 1007094 |      |     AD9999     |
| 5000000  |  AD0002   | 1007094 |      |     AD0002     |
| 5000003  |  AD0003   | 1007094 |      |     AD0003     |

</div>

</div>
