<div id="d140581e1" class="table">

<div class="table-title">

Table 1. Atividade

</div>

<div class="table-contents">

|           |           |                  |                 |           |                |
| :-------: | :-------: | :--------------: | :-------------: | :-------: | :------------: |
| Atividade | Descrição | Comentário/Ajuda | Nível de Resumo |   Nome    | Chave de Busca |
|  1000000  |           |                  |      false      |  Padrão   |     Padrão     |
|  5000000  |           |                  |      false      | Industria |      IND       |
|  5000001  |           |                  |      false      | Comercial |      COM       |

</div>

</div>
