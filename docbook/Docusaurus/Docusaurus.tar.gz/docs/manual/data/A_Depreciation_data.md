<div id="d112819e1" class="table">

<div class="table-title">

Table 1. Tipo de
Depreciação

</div>

<div class="table-contents">

|                     |                     |                                                                         |                            |            |       |
| :-----------------: | :-----------------: | :---------------------------------------------------------------------: | :------------------------: | :--------: | :---: |
| Tipo de Depreciação | Tipo de Depreciação |                                Descrição                                |            Nome            | Processado | Texto |
|        50003        |         SL          |                       Straight Line Depreciation                        |       Straight Line        |   false    | Test  |
|        50000        |        DB200        |                Declining Balance 200% (DB) Depreciation                 |   200% Declining Balance   |   false    | Test  |
|        50001        |        DB150        |                Declining Balance 150% (DB) Depreciation                 |   150% Declining Balance   |   false    | Test  |
|        50002        |         SYD         |                     Sum of Year Digits Depreciation                     |     Sum of Years Digit     |   false    | Test  |
|        50004        |         UOP         |                    Units of Production Depreciation                     |    Units of Production     |   false    | Test  |
|        50005        |      ARH\_VAR       |                          Variable Accelerated                           |    Variable Accelerated    |   false    | Test  |
|        50006        |         MAN         |                           Manual Depreciation                           |           Manual           |   false    | Test  |
|        50008        |        DB2SL        | Declining Balance 200% (DB) Depreciation with a switch to Straight Line |       200% DB to SL        |   false    | Test  |
|        50007        |         TAB         |              Depreciate asset by use of depreciation table              |           Table            |   false    | Test  |
|        50009        |        DB1SL        | Declining Balance 150% (DB) Depreciation with a switch to Straight Line |       150% DB to SL        |   false    | Test  |
|        50010        |        VARSL        |           Variable Accelerated with a switch to Straight Line           | Variable Accelerated to SL |   false    | Test  |
|       5000000       |         SL          |                               DEPRECIAÇÃO                               |        DEPRECIAÇÃO         |   false    |       |

</div>

</div>
