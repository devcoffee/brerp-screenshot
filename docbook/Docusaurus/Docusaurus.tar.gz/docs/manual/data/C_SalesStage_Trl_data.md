<div id="d238619e1" class="table">

<div class="table-title">

Table 1. Estágio de Vendas \*\*

</div>

<div class="table-contents">

|        |                   |           |           |         |
| :----: | :---------------: | :-------: | :-------: | :-----: |
| Idioma | Estágio de Vendas | Descrição | Traduzida |  Nome   |
| pt\_BR |      5000000      |           |   false   | etapa 1 |
| es\_CO |      5000000      |           |   false   | etapa 1 |

</div>

</div>
