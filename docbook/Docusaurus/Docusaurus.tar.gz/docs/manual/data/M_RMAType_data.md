<div id="d458755e1" class="table">

<div class="table-title">

Table 1. Tipo de
ARM

</div>

<div class="table-contents">

|                                          |                                          |             |                                          |
| :--------------------------------------: | :--------------------------------------: | :---------: | :--------------------------------------: |
|                Descrição                 |             Comentário/Ajuda             | Tipo de ARM |                   Nome                   |
|                                          |                                          |     100     |            Damaged on Arrival            |
|           Desacordo Comercial            |           Desacordo Comercial            |   5000000   |           Desacordo Comercial            |
|          Problemas de Qualidade          |          Problemas de Qualidade          |   5000001   |          Problemas de Qualidade          |
|           Problemas de Avarias           |           Problemas de Avarias           |   5000002   |           Problemas de Avarias           |
|      Retorno de Remessa armazenagem      |      Retorno de Remessa armazenagem      |   5000005   |      Retorno de Remessa armazenagem      |
|      Mercadoria fatura erroneamente      |      Mercadoria fatura erroneamente      |   5000007   |      Mercadoria fatura erroneamente      |
|               Consignação                |               Consignação                |   5000004   |               Consignação                |
|      Troca de Mercadoria(Comercial)      |      Troca de Mercadoria(Comercial)      |   5000003   |      Troca de Mercadoria(Comercial)      |
| Retorno de Remessa Demonstração/Conserto | Retorno de Remessa Demonstração/Conserto |   5000006   | Retorno de Remessa Demonstração/Conserto |
|      Troca de Mercadoria(Garantia)       |      Troca de Mercadoria(Garantia)       |   5000008   |      Troca de Mercadoria(Garantia)       |
|   Retorno de Material Remessa Concerto   |   Retorno de Material Remessa Concerto   |   5000009   |   Retorno de Material Remessa Concerto   |

</div>

</div>
