<div id="d532935e1" class="table">

<div class="table-title">

Table 1. Document Status
\*\*

</div>

<div class="table-contents">

|        |           |                                  |                 |
| :----: | :-------: | :------------------------------: | :-------------: |
| Idioma | Traduzida |               Nome               | Document Status |
| es\_CO |   false   |      Unprocessed Documents       |     200005      |
| es\_CO |   false   |       Workflow Activities        |     200004      |
| es\_CO |   false   |             Request              |     200003      |
| es\_CO |   false   |              Notice              |     200002      |
| es\_CO |   false   |    Pending Customer Shipments    |     200001      |
| pt\_BR |   false   |    Pending Customer Shipments    |     200001      |
| es\_CO |   false   |   Sales Orders received today    |     200000      |
| pt\_BR |   false   |   Sales Orders received today    |     200000      |
| pt\_BR |   true    | Atividades de Fluxos de Trabalho |     200004      |
| pt\_BR |   true    |    Documentos Não Processados    |     200005      |
| pt\_BR |   true    |           Solicitação            |     200003      |
| pt\_BR |   true    |              Aviso               |     200002      |

</div>

</div>
