<div id="d542041e1" class="table">

<div class="table-title">

Table 1. Modelo de
Correspondência

</div>

<div class="table-contents">

|       |                          |                                                                                                                                                                                                                                                                                                                                                                                                                                                                    |                  |                  |                    |                           |
| :---: | :----------------------: | :----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------: | :--------------: | :--------------: | :----------------: | :-----------------------: |
| HTML  |         Assunto          |                                                                                                                                                                                                                      Texto de Correspondência                                                                                                                                                                                                                      | Texto de email 2 | Texto de email 3 |        Nome        | Modelo de Correspondência |
| false |    Order Confirmation    |                                                                                                                                                                                             Dear @Name@, Thank you for your order. Best regards, The GardenWorld Team                                                                                                                                                                                              |                  |                  | Order Confirmation |            100            |
| false | iDempiere Reset Password | Dear @Name@, You are receiving this email because you (or somebody pretending to be you) said you have lost your iDempiere password. To access your iDempiere, use the temporary password from @AD\_Client\_ID\< Name\> @ below: @\#NewPassword@ Once you login, you will be directed to change password screen. Please change your password to something you can remember. Sincerely, The iDempiere Accounts Team Note: This email address cannot accept replies. |                  |                  |   Reset Password   |          200000           |
| false |                          |                                                                                                                                                                                                                                 .                                                                                                                                                                                                                                  |                  |                  |        Alan        |          5000000          |

</div>

</div>
