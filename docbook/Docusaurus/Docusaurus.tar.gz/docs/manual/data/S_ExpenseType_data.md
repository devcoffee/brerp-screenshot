<div id="d543463e1" class="table">

<div class="table-title">

Table 1. Tipo de
Despesa

</div>

<div class="table-contents">

|                      |     |                      |                         |                      |             |                 |                |
| :------------------: | :-: | :------------------: | :---------------------: | :------------------: | :---------: | :-------------: | :------------: |
| Categoria de Imposto | UDM |      Descrição       | Faturado (Nota Emitida) | Categoria de Produto |    Nome     | Tipo de Despesa | Chave de Busca |
|         107          | 100 | Travel related costs |          true           |         105          | Travel cost |       100       |     Travel     |

</div>

</div>
