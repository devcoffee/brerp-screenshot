<div id="d39862e1" class="table">

<div class="table-title">

Table 1. Tipo da Organização

</div>

<div class="table-contents">

|                     |                  |           |             |
| :-----------------: | :--------------: | :-------: | :---------: |
| Tipo da Organização | Cor de Impressão | Descrição |    Nome     |
|         100         |                  |           |  Division   |
|         101         |       121        |           |    Store    |
|         102         |                  |           | Cost Center |

</div>

</div>
