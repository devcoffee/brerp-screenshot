<div id="d559294e1" class="table">

<div class="table-title">

Table 1. Loja de
Web

</div>

<div class="table-contents">

|                       |           |                 |                    |                  |        |                |                  |               |                 |                 |                    |                   |                      |              |                  |                |         |             |                         |                 |                  |              |                        |                     |                     |                           |                 |                 |                 |                 |                       |             |                         |                       |
| :-------------------: | :-------: | :-------------: | :----------------: | :--------------: | :----: | :------------: | :--------------: | :-----------: | :-------------: | :-------------: | :----------------: | :---------------: | :------------------: | :----------: | :--------------: | :------------: | :-----: | :---------: | :---------------------: | :-------------: | :--------------: | :----------: | :--------------------: | :-----------------: | :-----------------: | :-----------------------: | :-------------: | :-------------: | :-------------: | :-------------: | :-------------------: | :---------: | :---------------------: | :-------------------: |
| Condição de Pagamento | Descrição | Rodapé de email | Cabeçalho de email | Comentário/Ajuda | Padrão | Menu de Ativos | Menu de Contatos | Menu de Juros | Menu de Faturas | Menu de Pedidos | Menu de Pagamentos | Menu de Registros | Menu de Solicitações | Menu de RdCs | Menu de Entregas | Lista de Preço | Armazém |    Nome     | Representante de Vendas |   Stylesheet    |       URL        | Contexto Web | Informação da Loja Web | Email de Pedido Web |   Parâmetro Web 1   |      Parâmetro Web 2      | Parâmetro Web 3 | Parâmetro Web 4 | Parâmetro Web 5 | Parâmetro Web 6 | Email da Loja Virtual | Loja de Web | Usuário da Loja Virtual | Senha da Loja Virtual |
|          105          |           |                 |                    |                  | false  |      true      |       true       |     true      |      true       |      true       |        true        |       true        |         true         |     true     |       true       |      101       |   103   | GardenWorld |           101           | gardenworld.css | http://localhost |   /wstore    |                        |                     | iDempiere120x60.png | \< h1\> Web Store\< /h1\> |   Parameter3    |   Parameter4    |   Parameter5    |   Parameter6    |                       |     11      |                         |                       |

</div>

</div>
