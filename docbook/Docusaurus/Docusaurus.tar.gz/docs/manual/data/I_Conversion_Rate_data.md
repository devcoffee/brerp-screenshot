<div id="d319111e1" class="table">

<div class="table-title">

Table 1. Importar Taxa de
Conversão

</div>

<div class="table-contents">

|                   |                   |          |            |                        |                      |                                          |                            |                                |           |                     |                                |                                          |            |                 |                       |            |
| :---------------: | :---------------: | :------: | :--------: | :--------------------: | :------------------: | :--------------------------------------: | :------------------------: | :----------------------------: | :-------: | :-----------------: | :----------------------------: | :--------------------------------------: | :--------: | :-------------: | :-------------------: | :--------: |
| Taxa de Conversão | Tipo de Conversão | Moeda De | Moeda para | Chave de Tipo de Moeda | Criar Taxa Recíproca |              Taxa Divisora               | Importar Taxa de Conversão | Mensagem de Erro de Importação | Importado | Código de Moeda ISO | Código de Moeda ISO de Destino |           Taxa Multiplicadora            | Processado | Processar Agora |     Válido desde      | Válido até |
|        135        |        114        |   100    |    102     |           S            |         true         | 1.17647058823529411764705882352941176471 |            100             |                                |   true    |         USD         |              EUR               |                   0.85                   |    true    |      false      | 2003-11-26 00:00:00.0 |            |
|        137        |        114        |   100    |    102     |           S            |         true         |                  1.249                   |            101             |                                |   true    |         USD         |              EUR               | 0.80064051240992794235388310648518815052 |    true    |      false      | 2003-12-29 00:00:00.0 |            |

</div>

</div>
