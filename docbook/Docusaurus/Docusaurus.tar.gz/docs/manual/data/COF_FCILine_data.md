<div id="d131994e1" class="table">

<div class="table-title">

Table 1. COF\_FCILine\_ID

</div>

<div class="table-contents">

|                        |         |                  |                        |                 |                 |                                 |                            |                           |     |           |                     |         |                             |                   |         |                                     |               |                |
| :--------------------: | :-----: | :--------------: | :--------------------: | :-------------: | :-------------: | :-----------------------------: | :------------------------: | :-----------------------: | :-: | :-------: | :-----------------: | :-----: | :-------------------------: | :---------------: | :-----: | :---------------------------------: | :-----------: | :------------: |
| Conteúdo de Importação |   FCI   | COF\_FCILine\_ID |       Número FCI       | Origem Sugerida | Processar Agora | Tipo do Produto (Item, Serviço) | Valor de Parcela Importada | Valor de Saída Mercadoria | UDM | Produzido | Grupo de Tributação |   NCM   | Categoria do Produto (CFOP) | Origem do Produto | Produto |                Nome                 |    UPC/EAN    | Chave de Busca |
|          0.00          | 5000008 |     5000005      |                        |        0        |        Y        |               01                |            0.00            |           88.00           | 100 |   false   |                     | 1009793 |                             |         5         | 5000002 | Produto Padrão FCI|CEST - Importado | 7894900300017 |    1000048     |
|          0.00          | 5000008 |     5000006      |                        |        0        |        Y        |               04                |            0.00            |          880.00           | 100 |   true    |                     | 1009793 |                             |         0         | 5000012 | Prod Produzido B – ZERO IPI/COM ST  | 7894900300017 |    1000055     |
|         20.35          | 5000002 |     5000014      |                        |        5        |        Y        |               04                |           179.12           |          880.00           | 100 |   true    |                     | 1009793 |                             |         0         | 5000012 | Prod Produzido B – ZERO IPI/COM ST  | 7894900300017 |    1000055     |
|         203.55         | 5000002 |     5000013      | 1111111111111111111111 |        8        |        N        |               01                |           179.12           |           88.00           | 100 |   false   |                     | 1009793 |                             |         5         | 5000002 | Produto Padrão FCI|CEST - Importado | 7894900300017 |    1000048     |

</div>

</div>
