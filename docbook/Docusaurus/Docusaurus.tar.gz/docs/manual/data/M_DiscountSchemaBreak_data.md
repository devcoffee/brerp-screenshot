<div id="d418712e1" class="table">

<div class="table-title">

Table 1. Esquema de Descontos
Incrementais

</div>

<div class="table-contents">

|                        |                   |                             |                                   |                      |                      |         |           |
| :--------------------: | :---------------: | :-------------------------: | :-------------------------------: | :------------------: | :------------------: | :-----: | :-------: |
| Desconto Incremental % | Ponto de Inflexão | Desconto Raso do P.Negócios | Esquema de Descontos Incrementais | Esquema de Descontos | Categoria de Produto | Produto | Seqüência |
|           5            |        100        |            false            |                100                |         102          |                      |         |    10     |

</div>

</div>
