<div id="d81334e1" class="table">

<div class="table-title">

Table 1. Tabela
\*\*

</div>

<div class="table-contents">

|        |        |           |                                         |
| :----: | :----: | :-------: | :-------------------------------------: |
| Idioma | Tabela | Traduzida |                  Nome                   |
| es\_CO |  894   |   false   |         Bitácora de acceso Web          |
| es\_CO |  459   |   true    |         Escritorio Mesa Trabajo         |
| es\_CO |  523   |   true    |        Formato Impresión Grilla         |
| es\_CO |  468   |   true    |              Mesa Trabajo               |
| es\_CO |  831   |   false   |            Esquema de Color             |
| es\_CO |  853   |   false   |              Proyecto web               |
| es\_CO | 50002  |   false   |      Copia de seguridad de objetos      |
| es\_CO | 50006  |   false   |        Detalle Paquete Exportado        |
| es\_CO | 50007  |   false   |         Paquete Común Exportar          |
| es\_CO |  902   |   false   |             Procesador LDAP             |
| es\_CO |  903   |   false   |       Bitácora de procesador LDAP       |
| es\_CO |  904   |   false   |               Acceso LDAP               |
| es\_CO |  580   |   true    |            Bitácora Cambios             |
| es\_CO |  585   |   true    |          Organización Asignado          |
| es\_CO |  749   |   true    |         Disposición Teclado PDV         |
| es\_CO |  750   |   true    |                Tecla PDV                |
| es\_CO |  316   |   true    |                Actividad                |
| es\_CO |  368   |   true    |              Bitácora EDI               |
| es\_CO |  383   |   true    |                Línea LDM                |
| es\_CO |  402   |   true    |                 Carrito                 |
| es\_CO | 53299  |   false   |               Flujo Caja                |
| es\_CO |  838   |   false   |            Estado de Edición            |
| es\_CO |  768   |   false   |         Línea Lote de Facturas          |
| es\_CO |  823   |   false   |    Fondos de la contabilidad general    |
| es\_CO |  824   |   false   |          Restricción de fondos          |
| es\_CO |  743   |   true    |               Medida SLA                |
| es\_CO |  254   |   true    |                 Adjunto                 |
| es\_CO |  293   |   true    |          Dirección del Tercero          |
| es\_CO |  855   |   false   |             Contenedor Web              |
| es\_CO |  854   |   false   |                Plantilla                |
| es\_CO |  870   |   false   |            Canal de noticas             |
| es\_CO |  469   |   true    |          Ventana Mesa Trabajo           |
| es\_CO |  637   |   true    |           Tipo de Conversión            |
| es\_CO |  640   |   true    |      Cargador de Estado de Cuenta       |
| es\_CO |  659   |   true    |   Bitácora Procesador de Solicitudes    |
| es\_CO |  660   |   true    |      Línea Autorización Devolución      |
| es\_CO |  603   |   true    |        Ejecución de Replicación         |
| es\_CO |  573   |   true    |        Ejecución de Recurrencias        |
| es\_CO |  597   |   true    |         Importar Pagos/Recaudos         |
| es\_CO |  780   |   false   |             Mensaje Correo              |
| es\_CO |  282   |   true    |          Instancia de Proceso           |
| es\_CO |  285   |   true    |          Parámetro de Proceso           |
| es\_CO |  288   |   true    |                  Arbol                  |
| es\_CO |  291   |   true    |                 Tercero                 |
| es\_CO |  276   |   true    |          Elemento del Sistema           |
| es\_CO |  599   |   true    |      Importar Nota de Contabilidad      |
| es\_CO |  846   |   false   |           Tree Node CM Media            |
| es\_CO |  604   |   true    |          Bitácora Replicación           |
| es\_CO |  707   |   true    |     Línea Distribución Contabilidad     |
| es\_CO | 50005  |   false   |            Paquete Exportado            |
| es\_CO |  407   |   true    |             Diario Caja PDV             |
| es\_CO |  224   |   true    |              Nota Contable              |
| es\_CO |  226   |   true    |         Línea de Nota Contable          |
| es\_CO |  533   |   true    |            Importar Terceros            |
| es\_CO |  708   |   true    |        Distribución Contabilidad        |
| es\_CO |  873   |   false   |        Dominio del proyecto Web         |
| es\_CO |  365   |   true    |                T\_Spool                 |
| es\_CO |  667   |   true    |        Liberación de Suscripción        |
| es\_CO |  673   |   true    |        Línea Respuesta SCP (RfQ)        |
| es\_CO |  675   |   true    |        Cantidad Línea SCP (RfQ)         |
| es\_CO |  676   |   true    |             Línea SCP (RfQ)             |
| es\_CO |  678   |   true    |          Relación con Terceros          |
| es\_CO |  813   |   false   |         Acceso Usuario Tercero          |
| es\_CO |  828   |   false   |            Problema Sistema             |
| es\_CO |  877   |   false   |             Entrada de chat             |
| es\_CO |  879   |   false   |             Tabla plantilla             |
| es\_CO |  881   |   false   |        Tabla plantilla Temporal         |
| es\_CO |  882   |   false   |             Tipo de entidad             |
| es\_CO |  883   |   false   |              Modificación               |
| es\_CO |  885   |   false   |          Perfil de acceso Web           |
| es\_CO |  559   |   true    |     Instancia Conjunto de Atributos     |
| es\_CO |  555   |   true    |       Control de número de Serie        |
| es\_CO |  866   |   false   |        Contenedor Web de pruebas        |
| es\_CO |  860   |   false   |           Elemento contenedor           |
| es\_CO |  859   |   false   |             Servidor media              |
| es\_CO |  871   |   false   |           Noticias / Artículo           |
| es\_CO |  118   |   true    |                Tarea SO                 |
| es\_CO |  899   |   false   |           Indice de Bitácora            |
| es\_CO |  858   |   false   |           Aviso publicitario            |
| es\_CO |  694   |   true    |     Bitácora de Procesador Contable     |
| es\_CO |  696   |   true    | Bitácora Procesador de Flujo de Trabajo |
| es\_CO |  699   |   true    |     Bitácora Procesador de Alertas      |
| es\_CO | 53046  |   false   |              Ventana SaaS               |
| es\_CO | 53047  |   false   |              Pestaña SaaS               |
| es\_CO | 53048  |   false   |               Campo SaaS                |
| es\_CO | 53049  |   false   |              Proceso SaaS               |
| es\_CO | 53051  |   false   |               Forma SaaS                |
| es\_CO | 53052  |   false   |               Tarea SaaS                |
| es\_CO | 53053  |   false   |           Flujo Trabajo SaaS            |
| es\_CO | 53058  |   false   |                  Regla                  |
| es\_CO | 53064  |   false   |           Script de migración           |
| es\_CO | 50009  |   false   |        Configurador del Sistema.        |
| es\_CO | 53014  |   false   |           Validador de modelo           |
| es\_CO | 52000  |   false   |           Cheque Lista Negra            |
| es\_CO | 52002  |   false   |                Menú Rol                 |
| es\_CO | 52001  |   false   |             Propiedades Web             |
| es\_CO | 53054  |   false   |               Módulo SaaS               |
| es\_CO | 53055  |   false   |               Nivel SaaS                |
| es\_CO | 53018  |   false   |              LDM y Fórmula              |
| es\_CO | 53037  |   false   |           Orden Distribución            |

</div>

</div>
