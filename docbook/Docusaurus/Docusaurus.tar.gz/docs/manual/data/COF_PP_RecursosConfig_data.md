<div id="d133728e1" class="table">

<div class="table-title">

Table 1. COF\_PP\_RecursosConfig\_ID

</div>

<div class="table-contents">

|            |            |                             |          |                   |                  |                 |            |         |
| :--------: | :--------: | :-------------------------: | :------: | :---------------: | :--------------: | :-------------: | :--------: | :-----: |
| Ferramenta | Instruções | COF\_PP\_RecursosConfig\_ID | Recursos | Classe do Produto | Grupo do Produto | Tipo do Produto | Linha Núm. | Produto |
|  5000000   |            |           5000000           | 5000000  |                   |                  |                 |     10     |         |
|  5000000   |            |           5000001           | 5000001  |                   |                  |                 |     10     |         |

</div>

</div>
