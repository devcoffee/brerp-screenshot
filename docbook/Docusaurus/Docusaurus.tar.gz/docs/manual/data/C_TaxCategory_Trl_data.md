<div id="d238734e1" class="table">

<div class="table-title">

Table 1. Categoria de Imposto
\*\*

</div>

<div class="table-contents">

|        |                      |                    |           |                         |
| :----: | :------------------: | :----------------: | :-------: | :---------------------: |
| Idioma | Categoria de Imposto |     Descrição      | Traduzida |          Nome           |
| pt\_BR |         107          |                    |   true    |        Standard         |
| es\_CO |       1000000        |                    |   false   |         Padrão          |
| es\_CO |       1000001        |                    |   false   |          VENDA          |
| es\_CO |       1000002        |                    |   false   |         COMPRA          |
| es\_CO |       1000003        |                    |   false   |    REMESSA (ENTRADA)    |
| es\_CO |       1000004        |                    |   false   |     REMESSA (SAIDA)     |
| es\_CO |       1000006        |                    |   false   |    DEVOLUÇÃO (VENDA)    |
| es\_CO |       1000005        |                    |   false   |   DEVOLUÇÃO (COMPRA)    |
| es\_CO |       1000007        |                    |   false   | TRANSFERÊNCIA (ENTRADA) |
| es\_CO |       1000008        |                    |   false   |  TRANSFERÊNCIA (SAIDA)  |
| es\_CO |       1000009        |                    |   false   |    SIMPLES NACIONAL     |
| es\_CO |         107          |                    |   true    |        Estándar         |
| pt\_BR |       5000000        |   SERVIÇO SAIDA    |   false   |      SERVIÇO SAIDA      |
| es\_CO |       5000000        |   SERVIÇO SAIDA    |   false   |      SERVIÇO SAIDA      |
| pt\_BR |       5000001        | DESPESAS - ENTRADA |   false   |   DESPESAS - ENTRADA    |
| es\_CO |       5000001        | DESPESAS - ENTRADA |   false   |   DESPESAS - ENTRADA    |
| pt\_BR |       1000000        |                    |   false   |         Padrão          |
| pt\_BR |       1000001        |                    |   false   |          VENDA          |
| pt\_BR |       1000002        |                    |   false   |         COMPRA          |
| pt\_BR |       1000003        |                    |   false   |    REMESSA (ENTRADA)    |
| pt\_BR |       1000004        |                    |   false   |     REMESSA (SAIDA)     |
| pt\_BR |       1000005        |                    |   true    |   DEVOLUÇÃO (COMPRA)    |
| pt\_BR |       1000006        |                    |   false   |    DEVOLUÇÃO (VENDA)    |
| pt\_BR |       1000007        |                    |   false   | TRANSFERÊNCIA (ENTRADA) |
| pt\_BR |       1000008        |                    |   false   |  TRANSFERÊNCIA (SAIDA)  |
| pt\_BR |       1000009        |                    |   false   |    SIMPLES NACIONAL     |
| pt\_BR |       5000002        |     Importacao     |   false   |       Importacao        |
| es\_CO |       5000002        |     Importacao     |   false   |       Importacao        |
| es\_CO |       1000010        |  SERVIÇO ENTRADA   |   true    |     SERVIÇO ENTRADA     |
| pt\_BR |       1000010        |                    |   true    |     SERVIÇO ENTRADA     |

</div>

</div>
