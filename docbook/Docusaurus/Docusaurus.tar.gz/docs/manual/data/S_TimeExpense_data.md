<div id="d543956e1" class="table">

<div class="table-title">

Table 1. Relatório de
Despesa

</div>

<div class="table-contents">

|                    |                      |                       |           |                   |                     |                     |          |                |         |            |                 |                      |
| :----------------: | :------------------: | :-------------------: | :-------: | :---------------: | :-----------------: | :-----------------: | :------: | :------------: | :-----: | :--------: | :-------------: | :------------------: |
| Valor da Aprovação | Parceiro de Negócios |   Data do Relatório   | Descrição | Ação do Documento | Estado do Documento | Número do Documento | Aprovado | Lista de Preço | Armazém | Processado | Processar Agora | Relatório de Despesa |
|         30         |         119          | 2003-02-03 00:00:00.0 | Expenses  |        CL         |         CO          |      10000000       |  false   |      101       |   103   |    true    |      false      |         100          |

</div>

</div>
