<div id="d166469e1" class="table">

<div class="table-title">

Table 1. C\_CyclePhase

</div>

<div class="table-contents">

|                |             |
| :------------: | :---------: |
| Passo de Ciclo | Fase Padrão |
|      107       |     102     |
|      108       |     105     |
|      110       |     112     |
|      110       |     111     |
|      109       |     110     |
|      108       |     106     |
|      108       |     107     |
|      108       |     108     |
|      109       |     109     |
|      107       |     100     |

</div>

</div>
