<div id="d134592e1" class="table">

<div class="table-title">

Table 1. COF\_PreferenciaXML\_ID

</div>

<div class="table-contents">

|          |        |        |             |                |                   |                   |           |                      |          |         |          |                                 |            |                |          |              |         |             |         |             |                         |                   |                       |         |        |           |      |         |              |         |                              |                 |                  |                 |                   |
| :------: | :----: | :----: | :---------: | :------------: | :---------------: | :---------------: | :-------: | :------------------: | :------: | :-----: | :------: | :-----------------------------: | :--------: | :------------: | :------: | :----------: | :-----: | :---------: | :-----: | :---------: | :---------------------: | :---------------: | :-------------------: | :-----: | :----: | :-------: | :--: | :-----: | :----------: | :-----: | :--------------------------: | :-------------: | :--------------: | :-------------: | :---------------: |
| Endereço | Número | Bairro | Complemento | Endereço do PN |    Nome do PN     |    Nome2 do PN    | Atividade | Parceiro de Negócios | Campanha | Cidade  | CFOP XML | CNPJ do Adquirente/Encomendante | CST COFINS | CST COFINS XML | CST ICMS | CST ICMS XML | CST IPI | CST IPI XML | CST PIS | CST PIS XML | COF\_PreferenciaXML\_ID | Cod. Regime Trib. | Condição de Pagamento | Projeto | Região | Descrição | CFOP |  CNAE   |      IE      | Produto | Chave da LDM(BOM) do Produto | Nome do Produto | Chave de Produto | Centro de Custo | Centro de Custo 2 |
|          |        |        |             |    5000000     | Mundo do Cafe S/A | Mundo do Cafe S/A |           |       5000000        |          | 1005026 |          |         13823508000131          |            |                |          |              |         |             |         |             |         5000000         |         3         |        1000000        |         |  465   |           |      | 1081302 | 415092169117 |         |                              |                 |                  |                 |                   |

</div>

</div>
