<div id="d543610e1" class="table">

<div class="table-title">

Table 1. Recurso

</div>

<div class="table-contents">

|                 |                      |                   |           |            |                        |                                |         |                            |              |                           |               |         |                 |                            |                 |
| :-------------: | :------------------: | :---------------: | :-------: | :--------: | :--------------------: | :----------------------------: | :-----: | :------------------------: | :----------: | :-----------------------: | :-----------: | :-----: | :-------------: | :------------------------: | :-------------: |
| Usuário/Contato | Quantidade Debitável | Capacidade Diária | Descrição | Disponível | Recursos de Fabricação | Tipo de Recursos de Fabricação | Armazém |            Nome            | % Utilização | Horizonte de Planejamento | Tempo de Fila | Recurso | Tipo de Recurso |       Chave de Busca       | Tempo de Espera |
|                 |          0           |                   |           |    true    |         false          |                                |   103   |      Mary Consultant       |     100      |             0             |               |   100   |       100       |            Mary            |                 |
|                 |          0           |         0         |           |    true    |          true          |               PT               |  50001  |      Furniture Plant       |     100      |            120            |       0       |  50005  |      50000      |      Furniture Plant       |        0        |
|                 |          0           |         0         |           |    true    |          true          |               PT               |  50002  |      Fertilizer Plant      |     100      |            120            |       0       |  50000  |      50000      |      Fertilizer Plant      |        0        |
|                 |          0           |  8.000000000000   |           |    true    |          true          |               WC               |  50001  |       Assembly Area        |     100      |             0             |       0       |  50001  |      50001      |       Assembly Area        |        0        |
|                 |          0           |  8.000000000000   |           |    true    |          true          |               WC               |  50001  |  Chrome Subcontract Area   |     100      |             0             |       0       |  50003  |      50001      |  Chrome Subcontract Area   |        0        |
|                 |          0           |  8.000000000000   |           |    true    |          true          |               WC               |  50002  |          Dry Area          |     100      |             0             |       0       |  50008  |      50001      |          Dry Area          |        0        |
|                 |          0           |  8.000000000000   |           |    true    |          true          |               WC               |  50002  | Fertilizer Inspection Area |     100      |             0             |       0       |  50009  |      50001      | Fertilizer Inspection Area |        0        |
|                 |          0           |  8.000000000000   |           |    true    |          true          |               WC               |  50001  |      Inspection Area       |     100      |             0             |       0       |  50004  |      50001      |      Inspection Area       |        0        |
|                 |          0           |  8.000000000000   |           |    true    |          true          |               WC               |  50002  |         Mixed Area         |     100      |             0             |       0       |  50007  |      50001      |         Mixed Area         |        0        |
|                 |          0           |  8.000000000000   |           |    true    |          true          |               PL               |  50002  |  Packing Production Line   |     100      |             0             |       0       |  50006  |      50001      |  Packing Production Line   |        0        |
|                 |          0           |  8.000000000000   |           |    true    |          true          |               WC               |  50001  |         Paint Area         |     100      |             0             |       0       |  50002  |      50001      |         Paint Area         |        0        |

</div>

</div>
