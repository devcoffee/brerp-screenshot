<div id="d146875e1" class="table">

<div class="table-title">

Table 1. Product Business
Partner

</div>

<div class="table-contents">

|                      |           |            |            |         |                            |                                 |                           |                       |                              |
| :------------------: | :-------: | :--------: | :--------: | :-----: | :------------------------: | :-----------------------------: | :-----------------------: | :-------------------: | :--------------------------: |
| Parceiro de Negócios | Descrição | Fabricante | Fabricante | Produto | Classificação de Qualidade | Mín. Vida de Prateleira em Dias | Mín. Vida de Prateleira % | Categoria do Parceiro | Chave de Produto de Parceiro |
|         118          |           |   false    |            |   128   |             0              |                0                |             0             |                       |                              |
|       5000026        |           |   false    |            | 1000001 |             0              |                0                |             0             |                       |                              |

</div>

</div>
