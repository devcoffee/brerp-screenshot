<div id="d237011e1" class="table">

<div class="table-title">

Table 1. Tipo de
Projeto

</div>

<div class="table-contents">

|                 |                                         |                  |                    |                      |
| :-------------: | :-------------------------------------: | :--------------: | :----------------: | :------------------: |
| Tipo de Projeto |                Descrição                | Comentário/Ajuda |        Nome        | Categoria de Projeto |
|       100       |         Implementation Project          |                  |   Implementation   |          S           |
|       101       |           Consulting Project            |                  |     Consulting     |          S           |
|       103       |                                         |                  |  Work Order (Job)  |          W           |
|       102       | Presales Project to implement iDempiere |                  | iDempiere Presales |          N           |

</div>

</div>
