<div id="d132426e1" class="table">

<div class="table-title">

Table 1. Região de
Entrega

</div>

<div class="table-contents">

|                   |                      |                   |        |                   |                |
| :---------------: | :------------------: | :---------------: | :----: | :---------------: | :------------: |
| Região de Entrega | Sequência de Entrega |     Descrição     | Padrão |       Nome        | Chave de Busca |
|      5000000      |                      | INTERIOR PAULISTA | false  | INTERIOR PAULISTA |    1000000     |

</div>

</div>
