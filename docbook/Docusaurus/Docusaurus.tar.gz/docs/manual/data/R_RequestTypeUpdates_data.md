<div id="d543055e1" class="table">

<div class="table-title">

Table 1. Request Type Updates

</div>

<div class="table-contents">

|                 |              |                     |
| :-------------: | :----------: | :-----------------: |
| Usuário/Contato | Auto-Serviço | Tipo de Solicitação |
|       101       |    false     |         100         |

</div>

</div>
