<div id="d166493e1" class="table">

<div class="table-title">

Table 1. Passo de
Ciclo

</div>

<div class="table-contents">

|                  |                |               |               |           |
| :--------------: | :------------: | :-----------: | :-----------: | :-------: |
| Ciclo de Projeto | Passo de Ciclo |     Nome      | Peso Relativo | Seqüência |
|       101        |      108       |    Suspect    |      0.1      |    10     |
|       101        |      109       |   Prospect    |      0.5      |    20     |
|       101        |      110       |   Customer    |      0.9      |    30     |
|       100        |      107       | Initial Phase |       1       |    10     |

</div>

</div>
