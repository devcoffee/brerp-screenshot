<div id="d414005e1" class="table">

<div class="table-title">

Table 1. Atributo

</div>

<div class="table-contents">

|                           |           |                       |             |          |                     |                            |
| :-----------------------: | :-------: | :-------------------: | :---------: | :------: | :-----------------: | :------------------------: |
| Tipo de Valor de Atributo | Descrição | Atributo de Instância | Obrigatório | Atributo | Procura de Atributo |            Nome            |
|             L             |           |         false         |    false    |   100    |         100         |        Size (S-M-L)        |
|             L             |           |         false         |    false    |   101    |                     |       Color (R-G-B)        |
|             L             |           |         true          |    false    |   102    |                     |         Use Factor         |
|             S             |           |         true          |    false    |   103    |                     |      Use Description       |
|             L             |           |         false         |    true     | 1000000  |                     |       Região do Café       |
|             L             |           |         false         |    false    | 1000001  |                     |        Tipo do Café        |
|             L             |           |         false         |    false    | 1000002  |                     |      Modo de Preparo       |
|             L             |           |         false         |    true     | 1000003  |                     |          Voltagem          |
|             L             |           |         false         |    false    | 1000004  |                     |      Tipo de Máquina       |
|             L             |           |         false         |    false    | 1000005  |                     |     Tipo de Cafeteira      |
|             L             |           |         false         |    false    | 1000006  |                     |         Capacidade         |
|             S             |           |         false         |    true     | 5000000  |                     |   ATRIBUTO PRODUTO TEXTO   |
|             N             |           |         false         |    true     | 5000001  |                     |  ATRIBUTO PRODUTO NÚMERO   |
|             S             |           |         true          |    true     | 5000002  |                     | ATRIBUTO PRODUTO INSTÂNCIA |
|             L             |           |         false         |    true     | 5000003  |                     |   ATRIBUTO PRODUTO LISTA   |

</div>

</div>
