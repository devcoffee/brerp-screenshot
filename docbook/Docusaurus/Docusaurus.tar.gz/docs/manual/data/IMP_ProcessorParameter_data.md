<div id="d318990e1" class="table">

<div class="table-title">

Table 1. Importar os Paramêtros do
Processo

</div>

<div class="table-contents">

|                                        |                                           |                   |                                    |                                                   |                    |                       |
| :------------------------------------: | :---------------------------------------: | :---------------: | :--------------------------------: | :-----------------------------------------------: | :----------------: | :-------------------: |
|               Descrição                |             Comentário/Ajuda              | Importar Processo | Importar os Paramêtros do Processo |                       Nome                        | Valor de Parâmetro |    Chave de Busca     |
| Import Processor Parameter Description |    HDD Import Processor Parameter Help    |       50000       |               50000                |   Name of file from where xml will be imported    |      C\_Order      |       fileName        |
| Import Processor Parameter Description | JMS Topic Import Processor Parameter Help |       50001       |               50001                | Name of JMS Topic from where xml will be Imported |    ExampleTopic    |       topicName       |
| Import Processor Parameter Description | JMS Topic Import Processor Parameter Help |       50001       |               50002                |  protocol which will be used for JMS connection   |        tcp         |       protocol        |
| Import Processor Parameter Description | JMS Topic Import Processor Parameter Help |       50001       |               50003                |               Durable Subscription                |        true        | isDurableSubscription |
| Import Processor Parameter Description | JMS Topic Import Processor Parameter Help |       50001       |               50004                |                 Subscription Name                 |   exampleSubName   |   subscriptionName    |
| Import Processor Parameter Description | JMS Topic Import Processor Parameter Help |       50001       |               50005                |             JMS Connection Client ID              |    ImpClientID     |       clientID        |

</div>

</div>
