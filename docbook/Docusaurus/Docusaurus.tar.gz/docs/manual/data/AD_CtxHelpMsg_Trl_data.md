<div id="d7945e1" class="table">

<div class="table-title">

Table 1. Menssagem de ajuda de contexto
\*\*

</div>

<div class="table-contents">

|                                |        |           |                                                                                                                                                                                                                                                                             |
| :----------------------------: | :----: | :-------: | :-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------: |
| Menssagem de ajuda de contexto | Idioma | Traduzida |                                                                                                                              Texto de Mensagem                                                                                                                              |
|            5000000             | es\_CO |   false   | Temos diversas varíaveis disponíveis para o uso dentro das instruções, que são elas: @JUROS@ - Exibe o valor dos juros, @CONDPAG@ - Exibe a condição de pagamento, @NOTAFISCAL@ - Exibe o número da nota fiscal, @MULTA@ - Exibe a quantidade de dias de atraso permitidos. |
|            5000000             | pt\_BR |   false   | Temos diversas varíaveis disponíveis para o uso dentro das instruções, que são elas: @JUROS@ - Exibe o valor dos juros, @CONDPAG@ - Exibe a condição de pagamento, @NOTAFISCAL@ - Exibe o número da nota fiscal, @MULTA@ - Exibe a quantidade de dias de atraso permitidos. |

</div>

</div>
