<div id="d86622e1" class="table">

<div class="table-title">

Table 1. Janela Definida pelo
Usuário

</div>

<div class="table-contents">

|        |         |                              |                 |        |             |                                      |                                                                                                                                                                                                     |        |                 |                          |                     |
| :----: | :-----: | :--------------------------: | :-------------: | :----: | :---------: | :----------------------------------: | :-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------: | :----: | :-------------: | :----------------------: | :-----------------: |
| Idioma | Perfil  | Janela Definida pelo Usuário | Usuário/Contato | Janela | Observações |              Descrição               |                                                                                          Comentário/Ajuda                                                                                           | Padrão | Somente Leitura | Atualizável pelo usuário |        Nome         |
| pt\_BR |         |           5000000            |                 |  143   |             | Introduzir e Alterar Ordens de Venda |                                                                A Janela "Pedido" permite a você digitar e modificar Ordens de Venda.                                                                | false  |      false      |          false           |   Ordem de Venda    |
| pt\_BR | 1000000 |           5000002            |       100       |  167   |             |   Lançamento de Fatura de Clientes   |           A Janela "Fatura de Cliente" permite a você mostrar e digitar faturas para um cliente. Faturas também podem ser geradas a partir das Ordens de Venda ou Documentos de Entrega.            | false  |      false      |          false           |  Fatura (Cliente)   |
| pt\_BR |         |           5000003            |                 |  183   |             |   Registro de Fatura de Fornecedor   | A Janela "Fatura de Fornecedor" permite a você mostrar e digitar faturas de um Fornecedor. Faturas de Fornecedor também podem ser geradas a partir de Pedidos de Compra ou Recebimentos de Entrega. | false  |      false      |          false           | Fatura (Fornecedor) |

</div>

</div>
