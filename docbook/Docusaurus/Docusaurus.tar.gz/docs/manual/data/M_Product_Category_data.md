<div id="d444431e1" class="table">

<div class="table-title">

Table 1. Categoria de
Produto

</div>

<div class="table-contents">

|                |                  |                          |        |              |                       |                       |                      |                          |                           |                    |                           |
| :------------: | :--------------: | :----------------------: | :----: | :----------: | :-------------------: | :-------------------: | :------------------: | :----------------------: | :-----------------------: | :----------------: | :-----------------------: |
| Grupo de Ativo | Cor de Impressão |        Descrição         | Padrão | Auto-Serviço | Conjunto de Atributos | Política de Materiais | Categoria de Produto | Categoria de Produto Pai |           Nome            | Margem Planejada % |      Chave de Busca       |
|      100       |       110        |  Documentation Download  | false  |     true     |                       |           F           |         111          |                          |       Documentation       |         0          |            Doc            |
|                |                  |                          | false  |     true     |                       |           F           |         112          |                          |         Training          |         0          |         Training          |
|                |                  |                          |  true  |     true     |                       |           F           |         105          |                          |         Standard          |         0          |         Standard          |
|                |       116        |                          | false  |     true     |                       |           F           |         106          |                          |           Trees           |         20         |           Tree            |
|                |       117        |                          | false  |     true     |                       |           F           |         107          |                          |          Bushes           |         30         |           Bush            |
|                |                  |       Garden Tools       | false  |     true     |                       |           F           |         108          |                          |           Tools           |         0          |           Tools           |
|                |                  |      Lawn Chemicals      | false  |     true     |                       |           F           |         109          |                          |         Chemicals         |         0          |         Chemicals         |
|                |                  | Patio and Lawn Furniture | false  |     true     |                       |           F           |         110          |                          |           Patio           |         0          |           Patio           |
|                |       111        |                          | false  |    false     |                       |           F           |        50000         |                          |         Assembly          |         0          |         Assembly          |
|                |       100        |                          | false  |     true     |                       |           F           |        50001         |                          |       Raw Material        |         0          |       Raw Material        |
|                |       100        |                          | false  |    false     |                       |           F           |        50002         |                          |          Packing          |         0          |          Packing          |
|                |                  |                          | false  |    false     |                       |           F           |        50003         |                          |         Resources         |         0          |         Resources         |
|                |                  |                          |  true  |     true     |                       |           F           |       1000000        |                          |          Padrão           |        0.0         |          Padrão           |
|                |       100        |                          | false  |     true     |                       |           F           |       1000001        |                          |         Serviços          |         0          |         Serviços          |
|                |       100        |                          | false  |     true     |                       |           F           |       1000002        |                          |       Matéria Prima       |         0          |       Matéria Prima       |
|                |       100        |                          | false  |     true     |                       |           F           |       1000003        |                          |       Uso e Consumo       |         0          |       Uso e Consumo       |
|                |       100        |                          | false  |     true     |                       |           F           |       1000005        |                          |           Grãos           |         0          |           Grãos           |
|                |       100        |                          | false  |     true     |        1000000        |           F           |       1000006        |                          |       Café Gourmet        |         0          |       Café Gourmet        |
|                |       100        |                          | false  |     true     |        1000001        |           F           |       1000007        |                          |   Máquinas de Expresso    |         0          |   Máquinas de Expresso    |
|                |       100        |                          | false  |     true     |                       |           F           |       1000008        |                          | Acessórios %26 Utensílios |         0          | Acessórios %26 Utensílios |
|                |       100        |                          | false  |     true     |                       |           F           |       1000009        |                          |      Acompanhamentos      |         0          |      Acompanhamentos      |
|                |       100        |                          | false  |     true     |                       |           F           |       1000010        |                          |         Presentes         |         0          |         Presentes         |
|                |                  |                          |  true  |     true     |                       |           F           |       5000002        |                          |  GERAL TESTES - PRODUTOS  |        0.0         |  GERAL TESTES - PRODUTOS  |
|    5000000     |                  |                          | false  |     true     |                       |           F           |       1000004        |                          |   GERAL TESTES - ATIVO    |         0          |   GERAL TESTES - ATIVO    |

</div>

</div>
