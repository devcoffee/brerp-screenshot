<div id="d140427e1" class="table">

<div class="table-title">

Table 1. Esquema
Contábil

</div>

<div class="table-contents">

|                    |                                |                  |          |                         |                  |                             |                      |           |             |                                  |                                      |                      |             |                              |                                             |                           |                            |                               |                           |               |                            |              |                   |                 |                        |                   |
| :----------------: | :----------------------------: | :--------------: | :------: | :---------------------: | :--------------: | :-------------------------: | :------------------: | :-------: | :---------: | :------------------------------: | :----------------------------------: | :------------------: | :---------: | :--------------------------: | :-----------------------------------------: | :-----------------------: | :------------------------: | :---------------------------: | :-----------------------: | :-----------: | :------------------------: | :----------: | :---------------: | :-------------: | :--------------------: | :---------------: |
| Apenas Organização | Controle Automático de Período | Esquema Contábil | Moeda De | Tipo de Comprometimento | Nível de Custeio | Método de Formação de Custo | Período (Ano Fiscal) | Descrição | PCGA (GAAP) | Use Pseudônimo de Contas (Alias) | Use Controle de Combinação de Contas | Provisão/Competência | Ajustar CMV | Permitir Lançamento Negativo | Corrigir Impostos para Descontos / Despesas | Ajuste de Custo Explícito | Lançar Transitórias Iguais | Lançar Serviços Separadamente | Lançar Desconto Comercial | Tipo de Custo |            Nome            | Dias Futuros | Dias de Histórico | Processar Agora | Separador de Elementos | Corrigir Impostos |
|                    |             false              |     1000000      |   297    |            N            |        C         |              I              |                      |           |     UN      |               true               |                false                 |         true         |    false    |             true             |                    false                    |           false           |            true            |             false             |           false           |      100      | GardenWorld Loja BR / Real |      0       |         0         |      false      |           \-           |         N         |
|                    |              true              |       101        |   100    |            N            |        C         |              A              |        200035        |           |     UN      |               true               |                false                 |         true         |    true     |             true             |                    false                    |           false           |            true            |             false             |           false           |      100      | GardenWorld US/A/US Dollar |     100      |       10000       |                 |           \-           |         B         |
|                    |             false              |     1000001      |   297    |            N            |        O         |              I              |       1000001        |           |     UN      |               true               |                false                 |         true         |    false    |            false             |                    false                    |           true            |            true            |             false             |           false           |    5000000    | Fatos Contábeis Mundo Café |      2       |         2         |      false      |           \-           |         N         |

</div>

</div>
