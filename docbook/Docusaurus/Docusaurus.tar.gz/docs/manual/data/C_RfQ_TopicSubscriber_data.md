<div id="d238337e1" class="table">

<div class="table-title">

Table 1. Assinante de
SdC

</div>

<div class="table-contents">

|                 |                      |                         |               |                  |                     |                    |
| :-------------: | :------------------: | :---------------------: | :-----------: | :--------------: | :-----------------: | :----------------: |
| Usuário/Contato | Parceiro de Negócios | Localização do Parceiro | Tópico de SdC | Assinante de SdC | Data da desistência | Data da Assinatura |
|       105       |         120          |           114           |      101      |       102        |                     |                    |
|       103       |         114          |           109           |      101      |       103        |                     |                    |

</div>

</div>
