<div id="d373125e1" class="table">

<div class="table-title">

Table 1. LBR\_DocFiscal\_Line\_detExport\_ID

</div>

<div class="table-contents">

|                                  |                       |                       |                    |                        |                                  |                         |                                  |                                        |                                       |                                     |                      |  |
| :------------------------------: | :-------------------: | :-------------------: | :----------------: | :--------------------: | :------------------------------: | :---------------------: | :------------------------------: | :------------------------------------: | :-----------------------------------: | :---------------------------------: | :------------------: |  |
| Data do Conhecimento de Embarque |  Data da Declaração   |   Data de Registro    | Tipo da Exportação | Natureza da Exportação | Tipo do Conhecimento de Embarque | Chave de Acesso da NF-e | Número do Registro de Exportação | Quantidade do Item Realmente Exportado | Número do ato concessório de Drawback | LBR\_DocFiscal\_Line\_detExport\_ID | Doc. Fiscal - Linhas |  |
|      2018-01-11 00:00:00.0       | 2018-01-11 00:00:00.0 | 2018-01-11 00:00:00.0 |         0          |           D            |                10                |                         |                                  |                                        |                   0                   |               5000000               |       5000107        |  |
|      2018-01-11 00:00:00.0       | 2018-01-11 00:00:00.0 | 2018-01-11 00:00:00.0 |         0          |           D            |                10                |                         |                                  |                                        |                   0                   |               5000002               |       5000109        |  |

</div>

</div>
