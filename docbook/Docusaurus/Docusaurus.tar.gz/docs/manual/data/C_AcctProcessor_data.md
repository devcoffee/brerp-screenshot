<div id="d139875e1" class="table">

<div class="table-title">

Table 1. Processador de
Contabilidade

</div>

<div class="table-contents">

|           |        |                              |                  |                              |                          |           |                                 |                                                  |                 |            |
| :-------: | :----: | :--------------------------: | :--------------: | :--------------------------: | :----------------------: | :-------: | :-----------------------------: | :----------------------------------------------: | :-------------: | :--------: |
| Programar | Tabela | Processador de Contabilidade | Esquema Contábil | Data do último processamento | Data da Próxima Execução | Descrição | Dias para manter registro (log) |                       Nome                       | Processar Agora | Supervisor |
|  200002   |        |           1000000            |                  |   2019-01-31 12:20:55.278    | 2019-01-31 12:30:55.278  |           |                7                | Mundo do Café S/A - Processador de Contabilidade |      false      |  1000000   |
|  200002   |        |             100              |                  |   2019-01-31 12:20:55.276    | 2019-01-31 12:30:55.276  |           |                7                |         GardenWorld Accounting Processor         |      false      |    101     |

</div>

</div>
