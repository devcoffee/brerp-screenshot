<div id="d130886e1" class="table">

<div class="table-title">

Table 1. Configuração de
Anexo

</div>

<div class="table-contents">

|          |                       |                      |                     |                        |         |                      |
| :------: | :-------------------: | :------------------: | :-----------------: | :--------------------: | :-----: | :------------------: |
| Extensao | Configuração de Anexo | Lógica para Exclusão | Tamanho Máximo (kb) | Extensao nao permitida | Tabela  | Registros Excluíveis |
|          |        1000001        |  @Processed@==false  |          0          |                        | 1120289 |         true         |
|          |        1000002        |  @Processed@==false  |          0          |                        | 1120247 |         true         |
|          |        1000003        |  @Processed@==false  |          0          |                        | 1100001 |         true         |

</div>

</div>
