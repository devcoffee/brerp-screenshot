<div id="d156108e1" class="table">

<div class="table-title">

Table 1. Campanha
\*\*

</div>

<div class="table-contents">

|        |          |                             |           |               |
| :----: | :------: | :-------------------------: | :-------: | :-----------: |
| Idioma | Campanha |          Descrição          | Traduzida |     Nome      |
| pt\_BR |   101    |                             |   false   |   Standard    |
| pt\_BR |   102    | Brochure Mailing for Spring |   false   | Spring Mailer |
| es\_CO | 1000000  |                             |   false   |    Padrão     |
| es\_CO |   101    |                             |   false   |   Standard    |
| es\_CO |   102    | Brochure Mailing for Spring |   false   | Spring Mailer |
| pt\_BR | 1000000  |                             |   false   |    Padrão     |

</div>

</div>
