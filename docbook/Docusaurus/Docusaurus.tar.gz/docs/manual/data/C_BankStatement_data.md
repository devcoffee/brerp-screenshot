<div id="d155816e1" class="table">

<div class="table-title">

Table 1. Extrato
Bancário

</div>

<div class="table-contents">

|               |                |                  |           |                          |                        |                       |              |                   |                     |                        |                              |             |          |        |                    |                     |         |            |                    |                 |                       |                         |
| :-----------: | :------------: | :--------------: | :-------: | :----------------------: | :--------------------: | :-------------------: | :----------: | :---------------: | :-----------------: | :--------------------: | :--------------------------: | :---------: | :------: | :----: | :----------------: | :-----------------: | :-----: | :--------: | :----------------: | :-------------: | :-------------------: | :---------------------: |
| Saldo Inicial | Conta Bancária | Extrato Bancário | Copiar de | Criar linhas a partir de | Criar a partir do lote |     Data da Conta     |  Descrição   | Ação do Documento | Estado do Documento | Data do Extrato da TEF | Referência do Extrato da TEF | Saldo Final | Aprovado | Manual | Confrontar Extrato |        Nome         | Lançado | Processado |   Processado Em    | Processar Agora |    Data do Extrato    | Diferença de Declaração |
|       0       |      100       |       101        |     N     |            N             |                        | 2006-10-31 00:00:00.0 |              |        CO         |         DR          |                        |                              |      0      |  false   |  true  |         N          | 2006-10-31 00:00:00 |  false  |   false    |                    |      false      | 2006-10-31 00:00:00.0 |            0            |
|       0       |      100       |       100        |     N     |            N             |                        | 2002-02-22 00:00:00.0 |              |        CL         |         CO          |                        |                              |     148     |   true   |  true  |                    |     2002-02-22      |  true   |    true    |   1014436428000    |      false      | 2002-02-22 00:00:00.0 |           148           |
|       0       |    5000001     |     5000002      |     N     |            N             |           N            | 2018-02-24 00:00:00.0 |              |        CL         |         CO          |                        |                              | \-32467.00  |   true   |  true  |         N          | 2018-02-24 14:19:22 |  true   |    true    | 1519492945276.2769 |      false      | 2018-02-24 00:00:00.0 |       \-32467.00        |
|       0       |    5000003     |     5000000      |     N     |            N             |           N            | 2018-02-15 00:00:00.0 | \*\* Anulado |        \--        |         VO          |                        |                              |     0.0     |   true   |  true  |         N          | 2018-02-15 11:04:45 |  true   |    true    | 1518702990919.9192 |      false      | 2018-02-15 00:00:00.0 |           0.0           |
|    111.40     |    5000000     |     5000004      |     N     |            N             |           N            | 2018-03-02 00:00:00.0 |              |        CO         |         DR          |                        |                              |   111.40    |  false   |  true  |         N          | 2018-03-02 08:04:48 |  false  |   false    |         0          |      false      | 2018-03-02 00:00:00.0 |            0            |
|    111.40     |    5000000     |     5000005      |     N     |            N             |           N            | 2018-03-02 00:00:00.0 |              |        CO         |         DR          |                        |                              |   111.40    |  false   |  true  |         N          | 2018-03-02 08:04:48 |  false  |   false    |         0          |      false      | 2018-03-02 00:00:00.0 |            0            |
|      50       |    5000000     |     5000001      |     N     |            N             |           N            | 2018-02-16 00:00:00.0 |              |        CL         |         CO          |                        |                              |   161.40    |   true   |  true  |         N          | 2018-02-16 14:55:40 |  true   |    true    | 1518803246673.6738 |      false      | 2018-02-16 00:00:00.0 |         111.40          |
|    111.40     |    5000000     |     5000006      |     N     |            N             |           N            | 2018-03-05 00:00:00.0 |              |        CL         |         CO          |                        |                              |  \-4888.60  |   true   |  true  |         N          | 2018-03-05 13:02:42 |  true   |    true    | 1520267239775.7756 |      false      | 2018-03-05 00:00:00.0 |        \-5000.0         |

</div>

</div>
