<div id="d7967e1" class="table">

<div class="table-title">

Table 1. Ajuda de
Contexto

</div>

<div class="table-contents">

|                   |                  |                                                                                                          |                                |
| :---------------: | :--------------: | :------------------------------------------------------------------------------------------------------: | :----------------------------: |
| Ajuda de Contexto | Tipo de Contexto |                                                Descrição                                                 |              Nome              |
|      5000000      |        T         | Essa ajuda e para instruir o usuário a como utilizar as variáveis nas instruções da integração bancária. | Ajuda variáveis das instruções |

</div>

</div>
