<div id="d462412e1" class="table">

<div class="table-title">

Table 1. Monitoramento de
Estoques

</div>

<div class="table-contents">

|             |                      |         |                          |                     |                   |                     |                   |                      |           |                         |         |                         |                 |         |                       |                        |                       |                      |                        |                           |                                       |                            |                     |
| :---------: | :------------------: | :-----: | :----------------------: | :-----------------: | :---------------: | :-----------------: | :---------------: | :------------------: | :-------: | :---------------------: | :-----: | :---------------------: | :-------------: | :-----: | :-------------------: | :--------------------: | :-------------------: | :------------------: | :--------------------: | :-----------------------: | :-----------------------------------: | :------------------------: | :-----------------: |
| Organização | Parceiro de Negócios | Pedido  | Linha de Ordem de Vendas |   Data do Pedido    | Região de Entrega |   Data Prometida    | Tipo de Documento | Referência do Pedido | Descrição | Representante de Vendas | Armazém | Localização do Parceiro | Usuário/Contato | Produto | Quantidade a Entregar | Quantidade Requisitada | Quantidade em Estoque | Quantidade Reservada | Quantidade Requisitada | Quantidade Não Confirmada | Quantidade Movimentada Não Confirmada | Movimentações em Progresso | Possível Movimentar |
|   1000001   |       5000000        | 5000240 |         5000275          | 2018-03-02 00:00:00 |       null        | 2018-03-02 00:00:00 |      1000072      |         null         |   null    |         1000021         | 5000005 |         5000000         |     5000000     | 1000003 |           1           |           1            |        1387.0         |         1.0          |         100.0          |           null            |                 null                  |             N              |          N          |
|   1000001   |       5000000        | 5000239 |         5000274          | 2018-03-02 00:00:00 |      5000000      | 2018-03-02 00:00:00 |      1000072      |         null         |   null    |         1000000         | 5000005 |         5000000         |     5000020     | 1000001 |          10           |           10           |        9897.0         |         10.0         |          50.0          |            90             |                 null                  |             N              |          N          |

</div>

</div>
