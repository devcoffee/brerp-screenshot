<div id="d134775e1" class="table">

<div class="table-title">

Table 1. Motivo de Encerramento (Ordem de
Venda)

</div>

<div class="table-contents">

|                                         |             |              |           |                |
| :-------------------------------------: | :---------: | :----------: | :-------: | :------------: |
| Motivo de Encerramento (Ordem de Venda) | Reason List | Reason title | Descrição | Chave de Busca |
|                 5000000                 |     04      |  Desacordo   |           |    1000000     |

</div>

</div>
