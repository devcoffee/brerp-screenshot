<div id="d419428e1" class="table">

<div class="table-title">

Table 1. Linha de Confirmação de
Envio/Recebimento

</div>

<div class="table-contents">

|                 |                  |                       |           |           |                                  |                                           |                              |                         |            |                      |                 |
| :-------------: | :--------------: | :-------------------: | :-------: | :-------: | :------------------------------: | :---------------------------------------: | :--------------------------: | :---------------------: | :--------: | :------------------: | :-------------: |
| Linha de Fatura | Núm. Confirmação | Quantidade Confirmada | Descrição | Diferença | Confirmação de Envio/Recebimento | Linha de Confirmação de Envio/Recebimento | Linha de Remessa/Recebimento | Linha de Estoque Físico | Processado | Quantidade Sucateada | Quantidade Alvo |
|                 |                  |          10           |           |     0     |               100                |                    100                    |             126              |                         |   false    |          0           |       10        |
|                 |                  |           1           |           |    0.0    |             5000000              |                  5000000                  |           5000234            |                         |   false    |         0.0          |        1        |
|                 |                  |          20           |           |    0.0    |             5000001              |                  5000001                  |           5000278            |                         |    true    |         0.0          |       20        |
|                 |                  |          \-3          |           |    0.0    |             5000002              |                  5000002                  |           5000316            |                         |    true    |         0.0          |       \-3       |
|                 |                  |          90           |           |    0.0    |             5000003              |                  5000003                  |           5000344            |                         |   false    |         0.0          |       90        |
|                 |                  |           1           |           |    0.0    |             5000004              |                  5000004                  |           5000364            |                         |    true    |         0.0          |        1        |

</div>

</div>
