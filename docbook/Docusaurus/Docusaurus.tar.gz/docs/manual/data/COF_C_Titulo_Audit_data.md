<div id="d130860e1" class="table">

<div class="table-title">

Table 1. COF\_C\_Titulo\_Audit\_ID

</div>

<div class="table-contents">

|                 |                      |                           |            |                   |                            |                         |                                                                                                                |
| :-------------: | :------------------: | :-----------------------: | :--------: | :---------------: | :------------------------: | :---------------------: | :------------------------------------------------------------------------------------------------------------: |
| Usuário/Contato | Nome do Arquivo CNAB | COF\_C\_Titulo\_Audit\_ID | Gerar CNAB | CNAB Reprocessado | Retorno de CNAB Processado |    Data da Transação    |                                                   Descrição                                                    |
|       100       |     CB150218.REM     |          5000000          |    true    |       false       |           false            | 2018-02-15 10:46:11.812 | Form Transaction - CNAB\_9ab33926-9c53-43e4-b8c0-525bec6d948c Processamento Em - Thu Feb 15 10:46:11 BRST 2018 |
|       100       |     CB280218.REM     |          5000001          |    true    |       false       |           false            | 2018-02-28 14:41:16.836 | Form Transaction - CNAB\_c5de8aa4-2122-49d3-8d03-35567b93a3c5 Processamento Em - Wed Feb 28 14:41:16 BRT 2018  |

</div>

</div>
