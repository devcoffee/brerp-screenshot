<div id="d199658e1" class="table">

<div class="table-title">

Table 1. Categoria de
Posição

</div>

<div class="table-contents">

|                      |           |                  |                    |
| :------------------: | :-------: | :--------------: | :----------------: |
| Categoria de Posição | Descrição | Comentário/Ajuda |        Nome        |
|         100          |           |                  |     Management     |
|         101          |           |                  | Salaried Positions |
|         102          |           |                  |    Hourly Wage     |
|         103          |           |                  |      External      |

</div>

</div>
