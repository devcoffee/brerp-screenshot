<div id="d533096e1" class="table">

<div class="table-title">

Table 1. Objetivo

</div>

<div class="table-contents">

|        |                 |                 |        |                              |        |                                             |                    |                 |              |                 |               |                |                                             |      |                  |          |             |         |               |           |
| :----: | :-------------: | :-------------: | :----: | :--------------------------: | :----: | :-----------------------------------------: | :----------------: | :-------------: | :----------: | :-------------: | :-----------: | :------------: | :-----------------------------------------: | :--: | :--------------: | :------: | :---------: | :-----: | :-----------: | :-------: |
| Perfil | Usuário/Contato | Tipo de Gráfico | Do dia | Data do último processamento | Ao dia |                  Descrição                  | Meta de Desempenho | Nível de Resumo | Medição Real | Measure Display | Measure Scope | Alvo da Medida |                    Nome                     | Nota | Esquema de Cores | Objetivo | Parent Goal | Medida  | Peso Relativo | Seqüência |
|        |                 |       BC        |        |   2019-01-24 11:38:26.577    |        |       Open Service Requests by Status       |      0.100000      |      false      |      1       |                 |       0       |       10       |         Total Open Service Requests         |      |       101        |   105    |             |   104   |       1       |     0     |
|        |                 |       BC        |        |   2019-01-24 11:38:26.612    |        |               100k in Revenue               |      0.000000      |      false      |     0.0      |        5        |       1       |     100000     |               Invoice Revenue               |      |       100        |   101    |             |   101   |       1       |     0     |
|        |                 |       BC        |        |   2019-01-24 11:38:26.643    |        |           Open Invoices max $1000           |      0.161120      |      false      |    161.12    |        5        |       0       |      1000      |                Open Invoices                |      |       101        |   102    |             |   102   |       1       |     0     |
|        |                 |       BC        |        |    2019-01-24 11:38:26.65    |        |        Open Service Requests in Time        |      0.000000      |      false      |      0       |                 |       3       |       10       |         Service Requests (Quarter)          |      |       101        |   104    |             |   103   |       1       |     0     |
|        |                 |       BC        |        |   2019-01-31 14:24:47.873    |        | Margem Contribuição(10% Vendas -\> 100.000) |      0.681950      |      false      |  68195.0000  |        5        |       1       |     100000     | Margem Contribuição(10% Vendas -\> 100.000) |      |     1500014      | 5000001  |             | 5000002 |       1       |     0     |
|        |                 |       BC        |        |   2019-01-31 14:24:48.046    |        |    Financiamento ao Cliente(Max 200.000)    |      0.835100      |      false      |  167019.98   |        5        |       1       |     200000     |    Financiamento ao Cliente(Max 200.000)    |      |     1500013      | 5000000  |             | 5000000 |       1       |     0     |
|        |                 |       BC        |        |   2019-01-31 14:24:48.054    |        |      Carteira de Venda(300 Parceiros)       |      0.100000      |      false      |      30      |        5        |       1       |      300       |      Carteira de Venda(300 Parceiros)       |      |     1500014      | 5000002  |             | 5000001 |       1       |     0     |
|        |                 |       BC        |        |   2019-01-31 14:24:48.061    |        |        Meta de Faturamento(500.000)         |      0.102643      |      false      |   51321.64   |        5        |       5       |     500000     |        Meta de Faturamento(500.000)         |      |     1500014      | 5000003  |             | 5000003 |       1       |     0     |

</div>

</div>
