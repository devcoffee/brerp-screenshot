<div id="d134554e1" class="table">

<div class="table-title">

Table 1. COF\_Participant\_ID

</div>

<div class="table-contents">

|                      |          |             |                       |         |              |                      |                           |        |                 |                          |                      |
| :------------------: | :------: | :---------: | :-------------------: | :-----: | :----------: | :------------------: | :-----------------------: | :----: | :-------------: | :----------------------: | :------------------: |
| Parceiro de Negócios | Cod. CVM |     CRC     |    Data Vencimento    | Auditor | Participante | COF\_Participant\_ID | Qualificação do Assinante | UF CRC | Tipo da Relação | Número Sequencial do CRC | Período (Ano Fiscal) |
|       5000001        |          |             |                       |  false  |     true     |       5000000        |            203            |        |                 |                          |       5000024        |
|       1000002        |          | SP-000032/O | 2019-12-31 00:00:00.0 |  false  |     true     |       5000001        |            900            |  465   |                 |           123            |       5000024        |

</div>

</div>
