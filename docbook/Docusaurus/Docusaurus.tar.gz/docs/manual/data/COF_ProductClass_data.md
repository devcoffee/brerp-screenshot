<div id="d134666e1" class="table">

<div class="table-title">

Table 1. Classe do
Produto

</div>

<div class="table-contents">

|                   |                 |           |        |                |
| :---------------: | :-------------: | :-------: | :----: | :------------: |
| Classe do Produto | Tipo do Produto | Descrição |  Nome  | Chave de Busca |
|      5000001      |     5000000     |           | CLASSE |     CLASSE     |
|      5000002      |     5000001     |           |  CON   |      CON       |
|      5000003      |     5000003     |           |  REV   |      REV       |
|      5000004      |     5000002     |           |  PROD  |      PROD      |

</div>

</div>
