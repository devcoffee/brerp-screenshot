<div id="d399397e1" class="table">

<div class="table-title">

Table 1. Inutilização de Numeração de
NFe

</div>

<div class="table-contents">

|                       |           |     |                |                                  |                    |            |              |       |                    |                                                      |                                   |                    |            |                 |                 |              |                         |
| :-------------------: | :-------: | :-: | :------------: | :------------------------------: | :----------------: | :--------: | :----------: | :---: | :----------------: | :--------------------------------------------------: | :-------------------------------: | :----------------: | :--------: | :-------------: | :-------------: | :----------: | :---------------------: |
|   Data da Transação   | Núm.Final | Ano |      CNPJ      | Inutilização de Numeração de NFe | Modelo Doc. Fiscal | Status NFe | Código da UF | Série | Ident. do Ambiente |                    Justificativa                     |              Motivo               | Serviço Solicitado | Processado | Processar Agora |    Protocol     | Núm. Inicial |         Versão          |
| 2018-01-11 16:15:49.0 |   5008    | 18  | 13823508000131 |             5000000              |         55         |    102     |      35      |   1   |         2          |        aaaannjks sll jdsd vsdvsdknmvkvlsdv m         | Inutilização de número homologado |     INUTILIZAR     |    true    |      false      | 135180009117893 |     5008     |   SP\_NFE\_PL009\_V4    |
| 2018-01-12 15:06:06.0 |   5029    | 18  | 08836461000100 |             5000001              |         55         |    102     |      42      |   1   |         2          |           documento com erro desconhecido            | Inutilizacao de numero homologado |     INUTILIZAR     |    true    |      false      | 342180000010924 |     5029     |    SVRS201710241705     |
| 2018-01-12 16:50:27.0 |   10003   | 18  | 79961116000147 |             5000002              |         55         |    102     |      41      |   1   |         2          |                  nota fiscal erada                   | Inutilizacao de numero homologado |     INUTILIZAR     |    true    |      false      | 141180000017035 |    10003     |      PR-v4\_0\_10       |
| 2018-01-12 17:12:08.0 |   10004   | 18  | 79961116000147 |             5000003              |         55         |    102     |      41      |   1   |         2          |                Nota Fiscal Incorreta                 | Inutilizacao de numero homologado |     INUTILIZAR     |    true    |      false      | 141180000017071 |    10004     |      PR-v4\_0\_10       |
| 2018-01-24 14:50:58.0 |    205    | 18  | 13823508000131 |             5000004              |         65         |    102     |      35      |   1   |         2          | sr boiii virou um homem centrado e de DEUS, DEUS é + | Inutilização de número homologado |     INUTILIZAR     |    true    |      false      | 135180000029757 |     205      | SP\_NFCE\_PL\_009\_V400 |

</div>

</div>
