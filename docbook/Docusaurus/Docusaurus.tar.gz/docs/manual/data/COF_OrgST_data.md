<div id="d133256e1" class="table">

<div class="table-title">

Table 1. Inscrição Estadual Substituta

</div>

<div class="table-contents">

|       |                               |        |
| :---: | :---------------------------: | :----: |
| IE ST | Inscrição Estadual Substituta | Região |
|       |            5000000            |        |

</div>

</div>
