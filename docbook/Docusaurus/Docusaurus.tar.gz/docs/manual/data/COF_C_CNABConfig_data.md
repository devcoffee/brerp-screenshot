<div id="d122362e1" class="table">

<div class="table-title">

Table 1. Configuração de
CNAB

</div>

<div class="table-contents">

|                      |                    |                  |                |                     |                 |                 |
| :------------------: | :----------------: | :--------------: | :------------: | :-----------------: | :-------------: | :-------------: |
| Configuração de CNAB | Formato do Arquivo | Tipo de Operação |   Descrição    | Transação de Vendas | Nível de Resumo | Processar Agora |
|       5000000        |       UTF-8        |       REM        | Itaú - Remessa |        true         |                 |      false      |
|       5000001        |       UTF-8        |       RET        | Itaú - Retorno |        true         |                 |      false      |

</div>

</div>
