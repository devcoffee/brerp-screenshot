<div id="d350507e1" class="table">

<div class="table-title">

Table 1. Categoria do Parceiro (CFOP)

</div>

<div class="table-contents">

|           |                              |              |
| :-------: | :--------------------------: | :----------: |
| Descrição | Categoria do Parceiro (CFOP) |     Nome     |
|           |           1000000            |  Indústria   |
|           |           1000001            | Eletricidade |
|           |           1000002            | Comunicação  |
|           |           1000003            |  Transporte  |
|           |           1000004            |   Serviço    |
|           |           1000005            | Ind. Consumo |
|           |           1000006            |    Isento    |
|           |           1000007            |   Agrícola   |

</div>

</div>
