<div id="d95490e1" class="table">

<div class="table-title">

Table 1. Condição de
Transição

</div>

<div class="table-contents">

|        |                       |                 |      |                  |          |           |                |            |
| :----: | :-------------------: | :-------------: | :--: | :--------------: | :------: | :-------: | :------------: | :--------: |
| Coluna | Condição de Transição | Transição de Nó | E/Ou | Tipo de Entidade | Operação | Seqüência | Chave de Busca | Valor Para |
| 11487  |          102          |       100       |  O   |        D         |  \> \>   |    10     |      100       |            |
|  2175  |        1500344        |     1500380     |  O   |        U         |   \==    |    10     |       Y        |            |
|  3718  |        1500345        |     1500381     |  O   |        U         |   \==    |    10     |       Y        |            |
|  2172  |        1500346        |     1500381     |  O   |        U         |   \==    |    20     |    1000072     |            |
|  3718  |        1500347        |     1500380     |  O   |        U         |   \==    |    20     |       Y        |            |

</div>

</div>
