<div id="d227204e1" class="table">

<div class="table-title">

Table 1. Seleção de
Pagamento

</div>

<div class="table-contents">

|                |                      |                          |           |          |                                                      |                       |            |                 |             |
| :------------: | :------------------: | :----------------------: | :-------: | :------: | :--------------------------------------------------: | :-------------------: | :--------: | :-------------: | :---------: |
| Conta Bancária | Seleção de Pagamento | Criar linhas a partir de | Descrição | Aprovado |                         Nome                         |   Data do Pagamento   | Processado | Processar Agora | Valor Total |
|      100       |         100          |            N             |           |   true   | Payment selection (manual) - 2002-09-07 20:18:51.041 | 2002-09-07 00:00:00.0 |    true    |      false      |    352.8    |
|    5000005     |       5000000        |            N             |           |  false   |                 2018-02-15 09:59:45                  | 2018-02-15 00:00:00.0 |    true    |      false      |  25993.25   |
|    5000000     |       5000001        |                          |           |   true   |      Pagamento: 237053100180001085262500075363       | 2018-02-16 00:00:00.0 |    true    |      false      |    1000     |
|    5000005     |       5000002        |                          |           |   true   |                  Pagamento: 1000058                  | 2018-03-01 00:00:00.0 |    true    |      false      |     100     |

</div>

</div>
