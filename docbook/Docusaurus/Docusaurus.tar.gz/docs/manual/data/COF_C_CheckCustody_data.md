<div id="d122507e1" class="table">

<div class="table-title">

Table 1. Tipo de
Portador

</div>

<div class="table-contents">

|                  |                 |                 |                |
| :--------------: | :-------------: | :-------------: | :------------: |
| Tipo de Portador |    Descrição    |      Nome       | Chave de Busca |
|     5000000      | Caixa de Cheque | Caixa de Cheque |  Caixa Cheque  |
|     5000001      |   Fornecedor    |   Fornecedor    |   Fornecedor   |

</div>

</div>
