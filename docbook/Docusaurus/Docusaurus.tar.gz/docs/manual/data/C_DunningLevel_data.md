<div id="d174981e1" class="table">

<div class="table-title">

Table 1. Nível de
Cobrança

</div>

<div class="table-contents">

|          |                   |                         |              |                       |                                |                               |                                 |                                  |                          |            |                    |                  |                            |                        |                     |              |                      |                                                       |                              |
| :------: | :---------------: | :---------------------: | :----------: | :-------------------: | :----------------------------: | :---------------------------: | :-----------------------------: | :------------------------------: | :----------------------: | :--------: | :----------------: | :--------------: | :------------------------: | :--------------------: | :-----------------: | :----------: | :------------------: | :---------------------------------------------------: | :--------------------------: |
| Cobrança | Nível de Cobrança | Cobrar Encargos de Mora | Cobrar Juros | Condição de Pagamento | Dias Após a Data do Vencimento | Dias entre Avisos de Cobrança |            Descrição            | Formato de Impressão de Cobrança | Valor de Encargo de Mora | Juros em % | Estado da Cobrança | Cancelar Crédito | Definir Prazo de Pagamento | Mostrar Todas Vencidas | Mostrar Não Vencido | É Declaração |         Nome         |                         Nota                          |      Texto de Impressão      |
|   100    |        100        |          false          |    false     |                       |             \-9999             |               0               | Include due an non-due invoices |               151                |            0             |     0      |                    |      false       |           false            |          true          |        true         |     true     |      Statement       | Please review your statement and submit due payments. |          Statement           |
|   100    |        101        |          false          |    false     |                       |               0                |               0               |                                 |               151                |            0             |     0      |                    |      false       |           false            |          true          |        false        |    false     | Dun all due invoices |        Please pay the due invoices immediately        |        Dunning Letter        |
| 5000000  |      5000000      |          true           |    false     |        1000000        |               2                |               2               |                                 |               151                |          100.00          |     0      |         D          |      false       |           false            |          true          |        false        |    false     |    2 Dias atraso     |                                                       | Valores atrasado \> - 2 dias |

</div>

</div>
