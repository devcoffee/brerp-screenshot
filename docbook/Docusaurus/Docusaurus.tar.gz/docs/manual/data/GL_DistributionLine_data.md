<div id="d255096e1" class="table">

<div class="table-title">

Table 1. Linha de Distribuição Razão
Geral

</div>

<div class="table-contents">

|       |                                |           |                      |          |                       |                        |         |                  |             |                 |                                   |            |         |                    |                        |                             |                       |                                    |                                     |                          |                              |                        |                        |                               |                       |                       |             |                 |                   |  |
| :---: | :----------------------------: | :-------: | :------------------: | :------: | :-------------------: | :--------------------: | :-----: | :--------------: | :---------: | :-------------: | :-------------------------------: | :--------: | :-----: | :----------------: | :--------------------: | :-------------------------: | :-------------------: | :--------------------------------: | :---------------------------------: | :----------------------: | :--------------------------: | :--------------------: | :--------------------: | :---------------------------: | :-------------------: | :-------------------: | :---------: | :-------------: | :---------------: |  |
| Conta | Organização de Transação (Trx) | Atividade | Parceiro de Negócios | Campanha | Localização de Origem | Localização de Destino | Projeto | Região de Vendas |  Descrição  | Distribuição RG | Linha de Distribuição Razão Geral | Linha Núm. | Produto | Sobrescrever Conta | Sobrescrever Atividade | Sobrescrever Parc. Negócios | Sobrescrever Campanha | Sobrescrever Localização de Origem | Sobrescrever Localização de Destino | Sobrescrever Organização | Sobrescrever Organização Trx | Sobrescrever o Produto | Sobrescrever o Projeto | Sobrescrever Região de Vendas | Sobrescrever Usuário1 | Sobrescrever Usuário2 | Porcentagem | Centro de Custo | Centro de Custo 2 |  |
|       |                                |           |                      |          |                       |                        |         |                  |   50% HQ    |       100       |                100                |     10     |         |       false        |         false          |            false            |         false         |               false                |                false                |           true           |            false             |         false          |         false          |             false             |         false         |         false         |     50      |                 |                   |  |
|       |                                |           |                      |          |                       |                        |         |                  | Rest: Store |       100       |                101                |     20     |         |       false        |         false          |            false            |         false         |               false                |                false                |           true           |            false             |         false          |         false          |             false             |         false         |         false         |      0      |                 |                   |  |

</div>

</div>
