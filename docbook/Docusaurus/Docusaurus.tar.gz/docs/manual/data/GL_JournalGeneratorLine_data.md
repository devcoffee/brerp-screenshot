<div id="d255349e1" class="table">

<div class="table-title">

Table 1. Gerador de
Linha

</div>

<div class="table-contents">

|                     |              |                      |                      |          |          |                                                      |                  |                  |                  |                          |               |                         |           |
| :-----------------: | :----------: | :------------------: | :------------------: | :------: | :------: | :--------------------------------------------------: | :--------------: | :--------------: | :--------------: | :----------------------: | :-----------: | :---------------------: | :-------: |
| Valor Multiplicador | Coluna do BP | Type of BP Dimension | Parceiro de Negócios | Conta CR | Conta DR |                      Descrição                       | Gerador de Razão | Gerador de Linha | Comentário/Ajuda | Copie Todas as Dimensões | Mesmo Produto | Fator de Arredondamento | Seqüência |
|  \-1.000000000000   |              |                      |                      |          |          |        Close (4) Sales and (80) Other Income         |      200000      |      200000      |                  |           true           |     false     |            2            |    10     |
|  \-1.000000000000   |              |                      |                      |          |          |             Close (5) Cost of Goods Sold             |      200000      |      200001      |                  |           true           |     false     |            2            |    20     |
|  \-1.000000000000   |              |                      |                      |          |          |                  Close (6) Expenses                  |      200000      |      200002      |                  |           true           |     false     |            2            |    30     |
|  \-1.000000000000   |              |                      |                      |          |          |                  Close (7) Expenses                  |      200000      |      200003      |                  |           true           |     false     |            2            |    40     |
|  \-1.000000000000   |              |                      |                      |          |          | Close (82) Other Expense and (83) Expense (Absorbed) |      200000      |      200004      |                  |           true           |     false     |            2            |    50     |
|          1          |              |                      |                      |   771    |          |       Move Income Summary to Retained Earnings       |      200001      |      200005      |                  |          false           |     false     |            2            |    10     |
|        \-1.0        |              |                      |                      |          |          |                                                      |     5000000      |     5000001      |                  |           true           |     false     |           10            |    10     |

</div>

</div>
