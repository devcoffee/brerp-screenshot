<div id="d159133e1" class="table">

<div class="table-title">

Table 1. Linha de
Comissão

</div>

<div class="table-contents">

|                     |                  |                      |                    |          |                   |                       |                   |                  |                 |                                      |                  |           |             |            |                      |         |                    |                             |                      |  |
| :-----------------: | :--------------: | :------------------: | :----------------: | :------: | :---------------: | :-------------------: | :---------------: | :--------------: | :-------------: | :----------------------------------: | :--------------: | :-------: | :---------: | :--------: | :------------------: | :-----: | :----------------: | :-------------------------: | :------------------: |  |
| Valor Multiplicador | Valor a Subtrair | Parceiro de Negócios | Grupo de Parceiros | Comissão | Linha de Comissão | Grupo de Fornecedores | Classe do Produto | Grupo do Produto | Tipo do Produto | Comissionar só Pedidos especificados | Região de Vendas | Descrição | Só Positivo | Linha Núm. | Categoria de Produto | Produto | Regra de Pagamento | Multiplicador de Quantidade | Quantidade a Deduzir |  |
|          0          |        0         |                      |                    |   103    |        101        |                       |                   |                  |                 |                false                 |                  |           |    false    |     10     |                      |         |                    |            0.01             |          0           |  |
|          3          |        0         |       5000000        |      1000001       | 5000000  |      5000000      |                       |                   |                  |                 |                 true                 |                  |           |    true     |     10     |       1000000        |         |                    |              0              |          0           |  |

</div>

</div>
