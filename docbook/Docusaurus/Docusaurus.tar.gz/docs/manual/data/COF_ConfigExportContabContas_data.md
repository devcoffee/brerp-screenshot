<div id="d130916e1" class="table">

<div class="table-title">

Table 1. COF\_ConfigExportContabContas\_ID

</div>

<div class="table-contents">

|                    |                                   |                                                    |                |
| :----------------: | :-------------------------------: | :------------------------------------------------: | :------------: |
| Elemento de Contas | COF\_ConfigExportContabContas\_ID | Configuração de Exportação de Movimentos Contábeis | Chave de Busca |
|      1000074       |              5000000              |                      5000000                       |    1000000     |
|      1000139       |              5000001              |                      5000000                       |    1000001     |
|      1000074       |              5000002              |                      5000001                       |    1000000     |
|      1000139       |              5000003              |                      5000001                       |    1000001     |
|      1000142       |              5000004              |                      5000002                       |    1000002     |
|      1000253       |              5000005              |                      5000002                       |    1000003     |

</div>

</div>
