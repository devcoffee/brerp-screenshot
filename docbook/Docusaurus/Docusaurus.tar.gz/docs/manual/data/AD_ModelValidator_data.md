<div id="d37896e1" class="table">

<div class="table-title">

Table 1. Model
Validator

</div>

<div class="table-contents">

|                 |               |                  |                                                             |                                           |                                                    |           |
| :-------------: | :-----------: | :--------------: | :---------------------------------------------------------: | :---------------------------------------: | :------------------------------------------------: | :-------: |
| Model Validator |   Descrição   | Tipo de Entidade |                      Comentário/Ajuda                       |          Model Validation Class           |                        Nome                        | Seqüência |
|      50000      |               |       EE01       |                                                             |   org.eevolution.model.LiberoValidator    | Model Validator to Libero Manufacturing Management |     1     |
|      50004      | Fixed Assets  |        D         |                        Fixed Assets                         |   org.idempiere.fa.model.ModelValidator   |          Model Validator to Fixed Assets           |    70     |
|     200002      | Product Price |        D         | Auto sync corresponding price list with the base price list | org.adempiere.model.ProductPriceValidator |          Model Validator to Product Price          |     1     |

</div>

</div>
