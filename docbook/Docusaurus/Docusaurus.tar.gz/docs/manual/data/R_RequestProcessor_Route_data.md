<div id="d542997e1" class="table">

<div class="table-title">

Table 1. Encaminhamento de
Solicitação

</div>

<div class="table-contents">

|                 |               |                            |                               |                     |           |
| :-------------: | :-----------: | :------------------------: | :---------------------------: | :-----------------: | :-------: |
| Usuário/Contato | Palavra-Chave | Processador de Solicitação | Encaminhamento de Solicitação | Tipo de Solicitação | Seqüência |
|       102       |    garden     |            100             |              100              |                     |    10     |

</div>

</div>
