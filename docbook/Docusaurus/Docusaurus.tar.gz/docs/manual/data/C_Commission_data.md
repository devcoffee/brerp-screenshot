<div id="d159215e1" class="table">

<div class="table-title">

Table 1. Comissão

</div>

<div class="table-contents">

|                      |            |          |          |                          |                              |                 |                 |                    |                 |                 |                 |
| :------------------: | :--------: | :------: | :------: | :----------------------: | :--------------------------: | :-------------: | :-------------: | :----------------: | :-------------: | :-------------: | :-------------: |
| Parceiro de Negócios | Finalidade | Comissão | Moeda De | Criar linhas a partir de | Data do último processamento |    Descrição    | Base de Cálculo | Tipo de Freqüência | Listar Detalhes |      Nome       | Processar Agora |
|         113          |    101     |   103    |   100    |            N             |    2003-10-01 00:00:00.0     | 1% on all sales |        I        |         Q          |      true       | Base Commission |      false      |
|       5000000        |  5000434   | 5000000  |   297    |            N             |    2018-02-01 00:00:00.0     |                 |        R        |         M          |      true       |    Ronaldoo     |      false      |

</div>

</div>
