<div id="d419268e1" class="table">

<div class="table-title">

Table 1. Categoria de
Frete

</div>

<div class="table-contents">

|           |                  |                    |        |                |
| :-------: | :--------------: | :----------------: | :----: | :------------: |
| Descrição | Comentário/Ajuda | Categoria de Frete |  Nome  | Chave de Busca |
|           |                  |        100         | Ground |     Ground     |
|           |                  |        101         |  Air   |      Air       |

</div>

</div>
