<div id="d238305e1" class="table">

<div class="table-title">

Table 1. Linha de
SdC

</div>

<div class="table-contents">

|     |              |                   |                  |                  |           |                  |            |                                    |         |
| :-: | :----------: | :---------------: | :--------------: | :--------------: | :-------: | :--------------: | :--------: | :--------------------------------: | :-----: |
| SdC | Linha de SdC | Trabalho Completo | Iniciar Trabalho | Prazo de Entrega | Descrição | Comentário/Ajuda | Linha Núm. | Instância do Conjunto de Atributos | Produto |
| 100 |     100      |                   |                  |        0         |           |                  |     10     |                 0                  |   128   |
| 100 |     101      |                   |                  |        0         |           |                  |     20     |                 0                  |   129   |

</div>

</div>
