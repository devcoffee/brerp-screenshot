<div id="d199680e1" class="table">

<div class="table-title">

Table 1. Posição

</div>

<div class="table-contents">

|                      |         |                                     |                  |             |                     |
| :------------------: | :-----: | :---------------------------------: | :--------------: | :---------: | :-----------------: |
| Categoria de Posição | Posição |              Descrição              | Comentário/Ajuda | Funcionário |        Nome         |
|         100          |   100   |          Internal Manager           |                  |    true     |       Manager       |
|         101          |   101   |           Internal Sales            |                  |    true     |        Sales        |
|         103          |   102   | Primary contact of Business Partner |                  |    false    | BP Primary Contact  |
|         103          |   103   |                                     |                  |    false    | BP Payables Contact |

</div>

</div>
