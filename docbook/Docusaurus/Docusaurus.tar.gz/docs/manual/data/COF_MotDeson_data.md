<div id="d132544e1" class="table">

<div class="table-title">

Table 1. Motivo de
Desoneração

</div>

<div class="table-contents">

|                       |         |                                                             |                |
| :-------------------: | :-----: | :---------------------------------------------------------: | :------------: |
| Motivo de Desoneração | Imposto |                            Nome                             | Chave de Busca |
|        5000000        | 1106000 |                            Táxi                             |       1        |
|        5000001        | 1106000 |                     Deficiente condutor                     |       10       |
|        5000002        | 1106000 |                   Deficiente Não Condutor                   |       11       |
|        5000003        | 1106000 |                    Produtor Agropecuário                    |       3        |
|        5000004        | 1106000 |                      Frotista/Locadora                      |       4        |
|        5000005        | 1106000 |                    Diplomático/Consular                     |       5        |
|        5000006        | 1106000 | Utilitários e Motocicletas da Amazônia Ocidental e Áreas de |       6        |
|        5000007        | 1106000 |                           Suframa                           |       7        |
|        5000008        | 1106000 |                   Venda ao Orgão público                    |       8        |

</div>

</div>
