<div id="d543011e1" class="table">

<div class="table-title">

Table 1. Processador de
Solicitação

</div>

<div class="table-contents">

|           |                              |                          |           |                               |                                 |                                                |                             |                             |                 |                  |                            |                     |            |
| :-------: | :--------------------------: | :----------------------: | :-------: | :---------------------------: | :-----------------------------: | :--------------------------------------------: | :-------------------------: | :-------------------------: | :-------------: | :--------------: | :------------------------: | :-----------------: | :--------: |
| Programar | Data do último processamento | Data da Próxima Execução | Descrição | Dias de Alerta de Inatividade | Dias para manter registro (log) |                      Nome                      | Alertar após Dias em Atraso | Escalar após Dias de Atraso | Processar Agora | Dias de Lembrete | Processador de Solicitação | Tipo de Solicitação | Supervisor |
|  200003   |    2002-02-24 13:14:10.0     |  2002-02-25 13:14:10.0   |           |               1               |                7                |         GardenWorld Request Processor          |              2              |              3              |      false      |        1         |            100             |                     |    101     |
|  200003   |   2019-01-31 15:20:53.929    | 2019-01-31 15:35:53.929  |           |               0               |                7                | Mundo do Café S/A - Processador de Solicitação |              0              |              0              |      false      |        0         |          1000000           |                     |  1000000   |

</div>

</div>
