<div id="d237256e1" class="table">

<div class="table-title">

Table 1. Região \*\*

</div>

<div class="table-contents">

|        |        |           |                           |
| :----: | :----: | :-------: | :-----------------------: |
| Idioma | Região | Traduzida |           Nome            |
| pt\_BR |  105   |   false   |            ME             |
| pt\_BR |  106   |   false   |            NH             |
| pt\_BR |  107   |   false   |            RI             |
| pt\_BR |  110   |   false   |            PA             |
| pt\_BR |  111   |   false   |            VA             |
| pt\_BR |  112   |   false   |            WV             |
| pt\_BR |  115   |   false   |            DE             |
| pt\_BR |  116   |   false   |            WA             |
| pt\_BR |  118   |   false   |            AK             |
| pt\_BR |  119   |   false   |            TN             |
| pt\_BR |  120   |   false   |            GA             |
| pt\_BR |  122   |   false   |            SD             |
| pt\_BR |  123   |   false   |            MN             |
| pt\_BR |  124   |   false   |            IA             |
| pt\_BR |  126   |   false   |            OH             |
| pt\_BR |  127   |   false   |            IL             |
| pt\_BR |  128   |   false   |            SC             |
| pt\_BR |  130   |   false   |            KY             |
| pt\_BR |  131   |   false   |            LA             |
| pt\_BR |  135   |   false   |            MS             |
| pt\_BR |  160   |   false   | Newfoundland and Labrador |
| pt\_BR |  171   |   false   |            SA             |
| pt\_BR |  198   |   false   |           Q.ROO           |
| pt\_BR |  201   |   false   |            SON            |
| pt\_BR |  205   |   false   |            VER            |
| pt\_BR |  235   |   false   |         Albacete          |
| pt\_BR |  279   |   false   |          Teruel           |
| pt\_BR |  281   |   false   |         Valencia          |
| pt\_BR |  282   |   false   |        Valladolid         |
| pt\_BR |  402   |   false   |            福島県            |
| pt\_BR |  403   |   false   |            茨城県            |
| pt\_BR |  404   |   false   |            群馬県            |
| pt\_BR |  406   |   false   |            千葉県            |
| pt\_BR |  407   |   false   |            東京都            |
| pt\_BR |  409   |   false   |            新潟県            |
| pt\_BR |  410   |   false   |            富山県            |
| pt\_BR |  412   |   false   |            福井県            |
| pt\_BR |  413   |   false   |            山梨県            |
| pt\_BR |  415   |   false   |            静岡県            |
| pt\_BR |  417   |   false   |            三重県            |
| pt\_BR |  418   |   false   |            滋賀県            |
| pt\_BR |  419   |   false   |            京都府            |
| pt\_BR |  420   |   false   |            大阪府            |
| pt\_BR |  421   |   false   |            兵庫県            |
| pt\_BR |  422   |   false   |            奈良県            |
| pt\_BR |  423   |   false   |           和歌山県            |
| pt\_BR |  424   |   false   |            鳥取県            |
| pt\_BR |  425   |   false   |            島根県            |
| pt\_BR |  426   |   false   |            岡山県            |
| pt\_BR |  427   |   false   |            広島県            |
| pt\_BR |  428   |   false   |            山口県            |
| pt\_BR |  429   |   false   |            徳島県            |
| pt\_BR |  430   |   false   |            香川県            |
| pt\_BR |  431   |   false   |            愛媛県            |
| pt\_BR |  432   |   false   |            高知県            |
| pt\_BR |  433   |   false   |            福岡県            |
| pt\_BR |  434   |   false   |            佐賀県            |
| pt\_BR |  435   |   false   |            長崎県            |
| pt\_BR |  437   |   false   |            大分県            |
| pt\_BR |  440   |   false   |            沖縄県            |
| pt\_BR |  133   |   false   |            OK             |
| pt\_BR |  136   |   false   |            MT             |
| pt\_BR |  137   |   false   |            MO             |
| pt\_BR |  138   |   false   |            KS             |
| pt\_BR |  139   |   false   |            NE             |
| pt\_BR |  141   |   false   |            NM             |
| pt\_BR |  142   |   false   |            OR             |
| pt\_BR |  144   |   false   |            AR             |
| pt\_BR |  147   |   false   |            ID             |
| pt\_BR |  149   |   false   |            CO             |
| pt\_BR |  150   |   false   |            HI             |
| pt\_BR |  153   |   false   |            WI             |
| pt\_BR |  154   |   false   |            MD             |
| pt\_BR |  156   |   false   |          Alberta          |
| pt\_BR |  158   |   false   |         Manitoba          |
| pt\_BR |  159   |   false   |       New Brunswick       |
| pt\_BR |  162   |   false   |   Northwest Territories   |
| pt\_BR |  163   |   false   |          Nunavut          |
| pt\_BR |  164   |   false   |          Ontario          |
| pt\_BR |  165   |   false   |   Prince Edward Island    |
| pt\_BR |  167   |   false   |       Saskatchewan        |
| pt\_BR |  168   |   false   |           Yukon           |
| pt\_BR |  169   |   false   |            VIC            |
| pt\_BR |  170   |   false   |            NSW            |
| pt\_BR |  172   |   false   |            NT             |
| pt\_BR |  173   |   false   |            WA             |
| pt\_BR |  174   |   false   |            QLD            |
| pt\_BR |  175   |   false   |            TAS            |
| pt\_BR |  176   |   false   |            ACT            |
| pt\_BR |  177   |   false   |            AGS            |
| pt\_BR |  178   |   false   |           B.C.            |
| pt\_BR |  180   |   false   |           CAMP            |
| pt\_BR |  181   |   false   |            COL            |
| pt\_BR |  183   |   false   |           CHIH            |
| pt\_BR |  184   |   false   |           D.F.            |
| pt\_BR |  185   |   false   |            DGO            |
| pt\_BR |  187   |   false   |            GRO            |
| pt\_BR |  188   |   false   |            HGO            |
| pt\_BR |  191   |   false   |           MICH            |
| pt\_BR |  193   |   false   |            NAY            |

</div>

</div>
