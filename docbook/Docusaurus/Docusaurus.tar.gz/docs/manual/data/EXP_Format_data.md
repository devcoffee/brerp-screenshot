<div id="d250217e1" class="table">

<div class="table-title">

Table 1. Formato de
Exportação

</div>

<div class="table-contents">

|        |           |                       |                  |                                 |                 |                               |                               |                         |         |           |
| :----: | :-------: | :-------------------: | :--------------: | :-----------------------------: | :-------------: | :---------------------------: | :---------------------------: | :---------------------: | :-----: | :-------: |
| Tabela | Descrição | Formato de Exportação | Comentário/Ajuda |              Nome               | Processar Agora | Modelo de Teste de Exportação | Modelo de Teste de Importação |     Chave de Busca      | Versão  | Sql WHERE |
|  112   |           |         50000         |                  |          Client Value           |      false      |                               |                               |      Client\_Value      |  3.2.0  |           |
|  155   |           |         50001         |                  |          Organization           |      false      |                               |                               |       Org\_Value        |  3.2.0  |           |
|  114   |           |         50002         |                  |              User               |      false      |                               |                               |       User\_Name        |  3.2.0  |           |
|  394   |           |         50003         |                  |     Business Partner Group      |      false      |                               |                               |    C\_BP\_Group-Key     |  3.2.0  |           |
|  259   |           |         50004         |                  |            Order key            |      false      |                               |                               |      C\_Order-Key       |  3.2.0  |           |
|  259   |           |         50005         |                  |              Order              |      false      |                               |                               |        C\_Order         |  3.2.0  |           |
|  260   |           |         50006         |                  |           Order Line            |      false      |                               |                               |      C\_OrderLine       |  3.2.0  |           |
|  291   |           |         50007         |                  |        Business Partner         |      false      |                               |                               |       C\_BPartner       |  3.2.0  |           |
|  291   |           |         50008         |                  |        Business Partner         |      false      |                               |                               | GardenWorld-C\_BPartner | 3.2.0.1 |           |
|  112   |           |         50009         |                  | All BPartners for Client/Tenant |      false      |                               |                               |     clientPartners      |  3.2.0  |           |

</div>

</div>
