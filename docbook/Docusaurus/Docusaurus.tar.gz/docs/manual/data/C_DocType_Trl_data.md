<div id="d166558e1" class="table">

<div class="table-title">

Table 1. Tipo de Documento
\*\*

</div>

<div class="table-contents">

|        |                   |                                                            |           |                                      |                                      |
| :----: | :---------------: | :--------------------------------------------------------: | :-------: | :----------------------------------: | :----------------------------------: |
| Idioma | Tipo de Documento |                     Nota de Documento                      | Traduzida |                 Nome                 |          Texto de Impressão          |
| es\_CO |        115        |                                                            |   true    |         Nota de Contabilidad         |         Nota de Contabilidad         |
| es\_CO |        116        | Nota de tipo de documento para texto general y promocional |   true    |            Factura de CxC            |             Factura CxC              |
| es\_CO |        117        | Nota de tipo de documento para texto general y promocional |   true    |      Facturas de CxC indirecta       |        Factura CxC Indirecta         |
| es\_CO |        118        |                                                            |   true    |           Nota Crédito CxC           |           Nota Crédito CxC           |
| es\_CO |        119        |                                                            |   true    |        Comprobante de Ingreso        |        Comprobante de Ingreso        |
| es\_CO |        120        |                                                            |   true    |         Entrega de Productos         |           Nota de Entrega            |
| es\_CO |        121        |                                                            |   true    |    Entrega de Productos Indirecto    |             Nota Entrega             |
| es\_CO |        122        |                                                            |   true    |        Recepción de Productos        |           Envío Proveedor            |
| es\_CO |        123        |                                                            |   true    |            Factura de CxP            |            Factura de CxP            |
| es\_CO |        124        |                                                            |   true    |        Nota Crédito Proveedor        |        Nota Crédito Proveedor        |
| es\_CO |        125        |                                                            |   true    |        Comprobante de Egreso         |        Comprobante de Egreso         |
| es\_CO |        126        |                                                            |   true    |           Orden de compra            |           Orden de compra            |
| es\_CO |        127        |                                                            |   true    |        Requisición de compra         |        Requisición de compra         |
| es\_CO |        128        |                                                            |   true    |              Cotización              |              Cotización              |
| es\_CO |        129        |                                                            |   true    |              Propuesta               |              Propuesta               |
| es\_CO |        130        |                                                            |   true    |           Orden Prepagada            |           Orden Prepagada            |
| es\_CO |        131        |                                                            |   true    |         Retorno de material          | Autorización de Retorno de Material  |
| es\_CO |        132        |                                                            |   true    |            Orden Estandar            |        Confirmación de orden         |
| es\_CO |        133        |                                                            |   true    |           Orden a Crédito            |        Confirmación de orden         |
| es\_CO |        134        |                                                            |   true    |           Orden de Almacén           |        Confirmación de orden         |
| es\_CO |        135        |                                                            |   true    |         Orden Punto de Venta         |        Confirmación de orden         |
| es\_CO |        136        |                                                            |   true    |           Tópico Proyecto            |           Tópico Proyecto            |
| es\_CO |        137        |                                                            |   true    |      Asignación de pago/recaudo      |      Asignación de pago/recaudo      |
| es\_CO |        138        |                                                            |   true    |        Asignación de Factura         |        Asignación de Factura         |
| es\_CO |        139        |                                                            |   true    |        Producción de Material        |        Producción de material        |
| es\_CO |        140        |                                                            |   true    |  Documento de Contabilidad General   |  Documento de contabilidad general   |
| es\_CO |        141        |                                                            |   true    |           Diario Caja PDV            |           Diario Caja PDV            |
| es\_CO |        142        |                                                            |   true    |    Asignación de Orden de Compra     |    Asignación de Orden de Compra     |
| es\_CO |        143        |                                                            |   true    |        Movimiento de Material        |        Movimiento de material        |
| es\_CO |        144        |                                                            |   true    |    Inventario Físico de Material     |    Inventario Físico de Material     |
| es\_CO |        145        |                                                            |   true    |         Factura ProForma CxC         |         Factura ProForma CxC         |
| es\_CO |        146        |                                                            |   true    |          Extracto Bancario           |          Extracto Bancario           |
| es\_CO |        147        |                                                            |   true    | Recibo de Productos con Confirmación |           Envío Proveedor            |
| es\_CO |        148        |                                                            |   true    |    Entrega Productos con Recogida    |           Nota de Entrega            |
| es\_CO |        149        |                                                            |   true    |     Devolución Productos Cliente     |     Devolución Productos Cliente     |
| es\_CO |        151        |                                                            |   true    |     Retorno Productos Proveedor      |     Retorno Productos Proveedor      |
| es\_CO |       50000       |                                                            |   true    |                Nómina                |                Nómina                |
| es\_CO |       50001       |                                                            |   true    |       Lote de Notas Contables        |       Lote de Notas Contables        |
| es\_CO |       50002       |                                                            |   true    |         Orden de Manufactura         |         Orden de Manufactura         |
| es\_CO |       50010       |                                                            |   true    |        Orden de Mantenimiento        |        Orden de Mantenimiento        |
| es\_CO |       50011       |                                                            |   true    |           Orden de Calidad           |           Orden de Calidad           |
| es\_CO |       50012       |                                                            |   true    |        Orden de Distribución         |        Orden de Distribución         |
| es\_CO |       50013       |                                                            |   true    | Recolector de Costos de Manufactura  | Recolector de Costos de Manufactura  |
| es\_CO |      1000032      |        Tipo de documento para envio de consignação         |   false   |    Fatura de Envio de Consignação    |    Fatura de Envio de Consignação    |
| es\_CO |      1000033      |                                                            |   false   |       MM Envio de Consignação        |       MM Envio de Consignação        |
| es\_CO |      1000034      |       Tipo de documento para retorno de consignação        |   false   |   Fatura de Retorno de Consignação   |   Fatura de Retorno de Consignação   |
| es\_CO |      1000035      |                                                            |   false   |      MM Retorno de Consignação       |      MM Retorno de Consignação       |
| es\_CO |      1000036      |                                                            |   false   |        Retorno de Consignação        |        Retorno de Consignação        |
| es\_CO |      1000037      |     Tipo de documento para faturamento de consignação      |   false   | Fatura de Faturamento de Consignação | Fatura de Faturamento de Consignação |
| es\_CO |      1000038      |                                                            |   false   |    MM Faturamento de Consignação     |    MM Faturamento de Consignação     |
| es\_CO |      1000039      |                                                            |   false   |      Faturamento de Consignação      |      Faturamento de Consignação      |
| pt\_BR |        116        |    Document Type Note for general and promotional text.    |   true    |              AR Invoice              |               Invoice                |
| pt\_BR |        117        |    Document Type Note for general and promotional text.    |   true    |         AR Invoice Indirect          |               Invoice                |
| pt\_BR |        118        |                                                            |   true    |            AR Credit Memo            |             Credit Memo              |
| pt\_BR |        119        |                                                            |   true    |              AR Receipt              |               Receipt                |
| pt\_BR |        120        |                                                            |   true    |             MM Shipment              |            Delivery Note             |
| pt\_BR |        121        |                                                            |   true    |         MM Shipment Indirect         |            Delivery Note             |
| pt\_BR |        122        |                                                            |   true    |              MM Receipt              |           Vendor Delivery            |
| pt\_BR |        123        |                                                            |   true    |              AP Invoice              |            Vendor Invoice            |
| pt\_BR |        124        |                                                            |   true    |            AP CreditMemo             |          Vendor Credit Memo          |
| pt\_BR |        125        |                                                            |   true    |              AP Payment              |            Vendor Payment            |
| pt\_BR |        126        |                                                            |   true    |            Purchase Order            |            Purchase Order            |
| pt\_BR |        127        |                                                            |   true    |         Purchase Requisition         |         Purchase Requisition         |
| pt\_BR |        128        |                                                            |   true    |              Quotation               |              Quotation               |
| pt\_BR |        129        |                                                            |   true    |               Proposal               |               Proposal               |
| pt\_BR |        130        |                                                            |   true    |             Prepay Order             |             Prepay Order             |
| pt\_BR |        132        |                                                            |   true    |            Standard Order            |          Order Confirmation          |
| pt\_BR |        133        |                                                            |   true    |           On Credit Order            |          Order Confirmation          |
| pt\_BR |        134        |                                                            |   true    |           Warehouse Order            |          Order Confirmation          |
| pt\_BR |        135        |                                                            |   true    |              POS Order               |          Order Confirmation          |
| pt\_BR |        136        |                                                            |   true    |            Project Issue             |            Project Issue             |
| pt\_BR |        137        |                                                            |   true    |          Payment Allocation          |          Payment Allocation          |
| pt\_BR |        138        |                                                            |   true    |            Match Invoice             |            Match Invoice             |
| pt\_BR |        139        |                                                            |   true    |         Material Production          |         Material Production          |
| pt\_BR |        140        |                                                            |   true    |             GL Document              |             GL Document              |
| pt\_BR |        141        |                                                            |   true    |             Cash Journal             |             Cash Journal             |
| pt\_BR |        142        |                                                            |   true    |               Match PO               |               Match PO               |
| pt\_BR |        143        |                                                            |   true    |          Material Movement           |          Material Movement           |
| pt\_BR |        144        |                                                            |   true    |     Material Physical Inventory      |     Material Physical Inventory      |
| pt\_BR |        145        |                                                            |   true    |         AR Pro Forma Invoice         |         AR Pro Forma Invoice         |
| pt\_BR |        148        |                                                            |   true    |        MM Shipment with Pick         |            Delivery Note             |
| pt\_BR |      200004       |                                                            |   false   |           Cost Adjustment            |           Cost Adjustment            |
| pt\_BR |        115        |                                                            |   true    |              GL Journal              |               Journal                |
| pt\_BR |        150        |                                                            |   true    |        Vendor Return Material        | Vendor Return Material Authorization |
| pt\_BR |        151        |                                                            |   true    |           MM Vendor Return           |        Vendor Return Material        |
| es\_CO |      200001       |                                                            |   true    |            Adición Activo            |            Adición Activo            |
| es\_CO |      200002       |                                                            |   true    |         Depreciación Activo          |         Depreciación Activo          |
| es\_CO |      200003       |                                                            |   true    |           Desechar Activo            |           Desechar Activo            |
| es\_CO |      200004       |                                                            |   true    |             Ajuste Costo             |             Ajuste Costo             |
| pt\_BR |       50000       |                                                            |   true    |               Payroll                |               Payroll                |
| pt\_BR |       50001       |                                                            |   true    |           GL Journal Batch           |            Journal Batch             |
| pt\_BR |       50002       |                                                            |   true    |         Manufacturing Order          |         Manufacturing Order          |
| pt\_BR |       50010       |                                                            |   true    |          Maintenance Order           |          Maintenance Order           |
| pt\_BR |       50011       |                                                            |   true    |            Quality Order             |            Quality Order             |
| pt\_BR |       50012       |                                                            |   true    |          Distribution Order          |          Distribution Order          |
| pt\_BR |       50013       |                                                            |   true    |     Manufacturing Cost Collector     |     Manufacturing Cost Collector     |
| pt\_BR |      200000       |                                                            |   true    |        Internal Use Inventory        |        Internal Use Inventory        |
| pt\_BR |      200001       |                                                            |   true    |            Asset Addition            |            Asset Addition            |
| pt\_BR |      200002       |                                                            |   true    |          Asset Depreciation          |          Asset Depreciation          |
| pt\_BR |      200003       |                                                            |   true    |            Asset Disposal            |            Asset Disposal            |

</div>

</div>
