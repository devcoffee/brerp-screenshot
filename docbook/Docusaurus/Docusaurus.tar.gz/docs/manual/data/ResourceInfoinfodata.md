<div id="d543396e1" class="table">

<div class="table-title">

Table 1. Informações de
Recurso

</div>

<div class="table-contents">

|                 |         |                     |            |     |                     |            |
| :-------------: | :-----: | :-----------------: | :--------: | :-: | :-----------------: | :--------: |
| Tipo de Recurso | Recurso |   Atribuir desde    | Quantidade | UDM |    Atribuir até     | Confirmado |
|       100       |   100   | 2003-02-05 17:00:00 |     1      | 101 | 2003-02-05 18:00:00 |     N      |
|       100       |   100   | 2003-02-05 10:00:00 |     3      | 101 | 2003-02-05 13:00:00 |     N      |

</div>

</div>
