<div id="d111256e1" class="table">

<div class="table-title">

Table 1. Asset
Disposed

</div>

<div class="table-contents">

|                       |                               |                    |                |                |         |                 |                |                    |                       |               |                            |           |                   |        |                 |                      |                       |                       |           |                   |                     |                     |         |          |            |         |                    |            |                    |                 |
| :-------------------: | :---------------------------: | :----------------: | :------------: | :------------: | :-----: | :-------------: | :------------: | :----------------: | :-------------------: | :-----------: | :------------------------: | :-------: | :---------------: | :----: | :-------------: | :------------------: | :-------------------: | :-------------------: | :-------: | :---------------: | :-----------------: | :-----------------: | :-----: | :------: | :--------: | :-----: | :----------------: | :--------: | :----------------: | :-------------: |
| Depreciação Acumulada | Depreciação Acumulada (delta) | Método de Ativação | Custo do Ativo | Asset Disposed |  Ativo  | Status do Ativo | Ativo Comércio | Valor a Disposição |   Data a Disposição   | Tipo de Baixa | Código de Razão Disponivel | Proventos | Tipo de Documento | Fatura | Linha de Fatura | Período (Ano Fiscal) |     Data da Conta     |   Data do Documento   | Descrição | Ação do Documento | Estado do Documento | Número do Documento | Despesa | Aprovado | Descartado | Lançado | Tipo de Lançamento | Processado |   Processado Em    | Processar Agora |
|         83.33         |             83.33             |         AA         |    10000.00    |    5000000     | 5000001 |       AC        |                |      10000.00      | 2018-02-16 00:00:00.0 |      T1       |                            |     0     |                   |        |                 |       5000025        | 2018-02-16 00:00:00.0 | 2018-02-16 00:00:00.0 |           |        CL         |         CO          |       1000000       | 9916.67 |   true   |   false    |  true   |         A          |    true    | 1518810141442.4426 |      false      |

</div>

</div>
