<div id="d111755e1" class="table">

<div class="table-title">

Table 1. Produtos
Ativos

</div>

<div class="table-contents">

|         |                 |            |           |                                    |             |         |
| :-----: | :-------------: | :--------: | :-------: | :--------------------------------: | :---------: | :-----: |
|  Ativo  | Produtos Ativos | Quantidade | Descrição | Instância do Conjunto de Atributos | Localizador | Produto |
| 5000000 |     5000000     |    1.0     |           |              5000001               |             | 5000052 |
| 5000001 |     5000003     |    0.0     |           |              5000005               |             | 5000052 |
| 5000004 |     5000004     |    1.0     |           |              5000008               |             | 5000052 |

</div>

</div>
