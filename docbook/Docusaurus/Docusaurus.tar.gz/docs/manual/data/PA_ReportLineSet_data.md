<div id="d535065e1" class="table">

<div class="table-title">

Table 1. Conjunto de Linhas de
Relatório

</div>

<div class="table-contents">

|                                |                                |                                 |                 |
| :----------------------------: | :----------------------------: | :-----------------------------: | :-------------: |
|           Descrição            |              Nome              | Conjunto de Linhas de Relatório | Processar Agora |
|    US Format Balance Sheet     |         Balance Sheet          |               100               |      false      |
|   US Format Income Statement   |        Income Statement        |               102               |      false      |
| Income Statement for Cash Flow | Income Statement for Cash Flow |               104               |      false      |
|                                |           Balancete            |             5000000             |      false      |
|        CUSTOS/ DESPESAS        |        CUSTOS/ DESPESAS        |             5000001             |      false      |

</div>

</div>
