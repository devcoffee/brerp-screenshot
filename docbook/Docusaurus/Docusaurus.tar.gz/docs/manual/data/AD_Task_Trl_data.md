<div id="d84180e1" class="table">

<div class="table-title">

Table 1. Tarefa SO
\*\*

</div>

<div class="table-contents">

|        |           |         |               |                                                                |                                                             |           |                                   |
| :----: | :-------: | :-----: | :-----------: | :------------------------------------------------------------: | :---------------------------------------------------------: | :-------: | :-------------------------------: |
| Idioma | Tarefa SO | Checked | Pré Traduzido |                           Descrição                            |                      Comentário/Ajuda                       | Traduzida |               Nome                |
| es\_CO |    102    |         |               | Despliega la versión de la Máquina Virtual Java Predeterminada | La versión java usada por la aplicación puede ser diferente |   true    |           Versión Java            |
| es\_CO |    103    |         |               |               Exporta (Guardar) la base de datos               |           Ejecutar este comando desde el servidor           |   true    |     Exporta la base de datos      |
| es\_CO |    104    |         |               |                  Transfiere la base de datos                   |           Ejecutar este comando desde el servidor           |   true    | Transferencia de la base de datos |
| pt\_BR |    102    |         |               |               Mostra a versão do Java VM padrão                |  A versão do java usado pela aplicação pode ser diferente.  |   true    |          Versão do Java           |
| pt\_BR |    103    |         |               |               Exportar (salvar) o banco de dados               |          Rode este comando diretamente do servidor          |   true    |      Exportar Base de Dados       |
| pt\_BR |    104    |         |               |                  Transferir o banco de dados                   |          Rode este comando diretamente do servidor          |   true    |  Transferência do Banco de Dados  |

</div>

</div>
