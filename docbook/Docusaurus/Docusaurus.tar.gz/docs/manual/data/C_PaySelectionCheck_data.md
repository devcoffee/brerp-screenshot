<div id="d226839e1" class="table">

<div class="table-title">

Table 1. Pay Selection
Check

</div>

<div class="table-contents">

|                      |                            |           |                     |                      |                   |                                |                |          |        |                    |                    |            |            |                |
| :------------------: | :------------------------: | :-------: | :-----------------: | :------------------: | :---------------: | :----------------------------: | :------------: | :------: | :----: | :----------------: | :----------------: | :--------: | :--------: | :------------: |
| Parceiro de Negócios | Conta Bancária de Parceiro | Pagamento | Pay Selection Check | Seleção de Pagamento | Valor do Desconto |      Número do Documento       | Projeto Gerado | Impresso | Recibo | Valor do Pagamento | Regra de Pagamento | Processado | Quantidade | Valor da Baixa |
|         114          |                            |           |         100         |         100          |         0         |                                |     false      |  false   | false  |       352.8        |         S          |   false    |     1      |       0        |
|       5000000        |                            |           |       5000002       |       5000000        |       0.00        |            1000002             |     false      |  false   | false  |     \-1000.00      |         S          |   false    |     1      |       0        |
|       5000002        |                            |           |       5000000       |       5000000        |       0.00        |            1000000             |     false      |  false   | false  |      25200.00      |         S          |   false    |     4      |       0        |
|       5000005        |                            |           |       5000001       |       5000000        |       0.00        |            1000001             |     false      |  false   | false  |      1793.25       |         S          |   false    |     9      |       0        |
|       5000005        |                            |  5000076  |       5000003       |       5000001        |         0         | 237053100180001085262500075363 |     false      |  false   |  true  |        1000        |         T          |    true    |     1      |       0        |
|       5000005        |                            |  5000081  |       5000004       |       5000002        |         0         |            1000058             |      true      |  false   | false  |        100         |         T          |    true    |     1      |       0        |

</div>

</div>
