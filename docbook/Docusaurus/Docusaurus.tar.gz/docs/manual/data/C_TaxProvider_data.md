<div id="d238985e1" class="table">

<div class="table-title">

Table 1. Provedor de
Impostos

</div>

<div class="table-contents">

|       |                   |                                      |                      |         |                    |           |                 |
| :---: | :---------------: | :----------------------------------: | :------------------: | :-----: | :----------------: | :-------: | :-------------: |
| Conta | Código da Empresa | Configuração de Provedor de Impostos | Provedor de Impostos | Licença |        Nome        | Seqüência | Validar Conexão |
|       |                   |               1000001                |       1000001        |         | BrERP Tax Provider |     0     |        N        |

</div>

</div>
