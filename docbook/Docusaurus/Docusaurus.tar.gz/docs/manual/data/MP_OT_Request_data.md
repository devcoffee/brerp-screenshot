<div id="d412864e1" class="table">

<div class="table-title">

Table 1. Requisição de Ordem de
Trabalho

</div>

<div class="table-contents">

|         |                 |                   |                       |                       |           |                     |                     |                                  |                                 |                    |            |            |                 |
| :-----: | :-------------: | :---------------: | :-------------------: | :-------------------: | :-------: | :-----------------: | :-----------------: | :------------------------------: | :-----------------------------: | :----------------: | :--------: | :--------: | :-------------: |
|  Ativo  | Usuário/Contato | Tipo de Documento |   Data do Documento   |     Data Exigida      | Descrição | Estado do Documento | Número do Documento | Checklist de Processos (Padrões) | Requisição de Ordem de Trabalho | Tipo da Requisição | Prioridade | Processado | Processar Agora |
| 5000000 |       100       |      5000047      | 2018-01-18 00:00:00.0 | 2018-01-18 00:00:00.0 |           |         AP          |        86001        |                                  |             5000000             |         RP         |     7      |    true    |      false      |
| 5000000 |       100       |                   | 2018-01-18 00:00:00.0 | 2018-01-18 00:00:00.0 |           |         AP          |       1000000       |                                  |             5000001             |         RP         |     7      |    true    |      false      |
| 5000002 |       100       |      1000077      | 2018-02-18 00:00:00.0 | 2018-02-19 00:00:00.0 |           |         WC          |        86020        |                                  |             5000002             |         RP         |     7      |    true    |      false      |

</div>

</div>
