<div id="d445493e1" class="table">

<div class="table-title">

Table 1. Produto
\*\*

</div>

<div class="table-contents">

|        |                                                     |                                 |           |         |                                    |
| :----: | :-------------------------------------------------: | :-----------------------------: | :-------: | :-----: | :--------------------------------: |
| Idioma |                      Descrição                      |        Nota de Documento        | Traduzida | Produto |                Nome                |
| es\_CO |                                                     |                                 |   true    |   122   |              Estándar              |
| es\_CO |                                                     |                                 |   true    |   124   |            Olmo (Arbol)            |
| es\_CO |                                                     |                                 |   true    |   125   |  Contenedor de Semillas de Césped  |
| es\_CO |                                                     |                                 |   true    |   126   |       Servicio de Plantación       |
| es\_CO |                                                     |                                 |   true    |   127   |          Rosal (Arbusto)           |
| es\_CO |                                                     |                                 |   true    |   128   |          Azalea (Arbusto)          |
| es\_CO |                                                     |                                 |   true    |   129   |          Acebo (Arbusto)           |
| es\_CO |                                                     |                                 |   true    |   130   |          Ciruelo (Arbol)           |
| es\_CO |           Costos relacionados con viajes            |                                 |   true    |   131   |          Costos de Viaje           |
| es\_CO |                                                     |                                 |   true    |   132   |         María (Consultora)         |
| es\_CO |            Bonita silla para exteriores             |                                 |   true    |   133   |          Silla para patio          |
| es\_CO |             Bonita mesa para exteriores             |                                 |   true    |   134   |          Mesa para patio           |
| es\_CO |               Protege de los rayos UV               |                                 |   true    |   135   |         Parasol para patio         |
| es\_CO |       50 \# Bolsa de fertilizante para césped       |                                 |   true    |   136   |         Fertilizante \#50          |
| es\_CO |               10\# Bolsa de acolchado               |                                 |   true    |   137   |           Acolchado 10\#           |
| es\_CO |              Azadón metálico de 122cm               |                                 |   true    |   138   |            Azadón 122cm            |
| es\_CO |             Rastrillo de Bambú de 122cm             |                                 |   true    |   139   |         Rastrillo de Bambú         |
| es\_CO |          Rastrillo metálico de 122cm Rake           |                                 |   true    |   140   |         Rastrillo Metálico         |
| es\_CO |                Desmalezadora manual                 |                                 |   true    |   141   |           Desmalezadora            |
| es\_CO |               Transplantadora manual                |                                 |   true    |   142   |          Transplantadora           |
| es\_CO |             Sembradora de césped manual             |                                 |   true    |   143   |        Sembradora de Césped        |
| es\_CO |             Cultivador de césped manual             |                                 |   true    |   144   |        Cultivador de Césped        |
| es\_CO |            1 mesa, 4 sillas y 1 parasol             |                                 |   true    |   145   |     Juego de Muebles de Patio      |
| es\_CO | Información acerca de cómo plantar mejor su futuro. |                                 |   true    |   146   |            Cómo plantar            |
| es\_CO |                                                     |                                 |   true    |   147   |       Camiseta - Rojo Grande       |
| es\_CO |                                                     |                                 |   true    |   148   |      Camiseta - Verde Grande       |
| es\_CO |                                                     |                                 |   true    |  50000  |     Pata Trasera para Ensamble     |
| es\_CO |                                                     |                                 |   true    |  50001  |    Pata Delantera para Ensamble    |
| es\_CO |                                                     |                                 |   true    |  50002  | \#6-32 x 3/8 Tornillo Cabeza Allen |
| es\_CO |                                                     |                                 |   true    |  50003  |          Pegamento Ultra           |
| es\_CO |                                                     |                                 |   true    |  50004  |               Silla                |
| es\_CO |                                                     |                                 |   true    |  50005  |              Espaldar              |
| es\_CO |       70 \# Bolsa de fertilizante para césped       |                                 |   true    |  50007  |         Fertilizante \#70          |
| es\_CO |                                                     |                                 |   true    |  50008  |      Fertilizante para Césped      |
| es\_CO |                                                     |                                 |   true    |  50009  |             Nitrógeno              |
| es\_CO |                                                     |                                 |   true    |  50010  |              Fósforo               |
| es\_CO |                                                     |                                 |   true    |  50012  |              Potasio               |
| es\_CO |                                                     |                                 |   true    |  50013  |            Bolsa 50 Kg             |
| es\_CO |                                                     |                                 |   true    |  50014  |            Bolsa 70 Kg             |
| es\_CO |                                                     |                                 |   true    |  50015  |            Pata Frontal            |
| es\_CO |                                                     |                                 |   true    |  50016  |            Pata Trasera            |
| es\_CO |                                                     |                                 |   true    |  50017  |                Agua                |
| es\_CO |                                                     |                                 |   true    |  50019  |          Area de Ensamble          |
| es\_CO |                                                     |                                 |   true    |  50020  |          Area de Pintado           |
| es\_CO |                                                     |                                 |   true    |  50022  |         Area de Inspección         |
| es\_CO |                                                     |                                 |   true    |  50023  |         Planta de Muebles          |
| es\_CO |                                                     |                                 |   true    |  50024  |   Línea de Producción de Empaque   |
| es\_CO |                                                     |                                 |   true    |  50025  |             Area Mixta             |
| pt\_BR |                                                     |                                 |   true    |   124   |              Elm Tree              |
| pt\_BR |                                                     |                                 |   true    |   125   |        Grass Seed Container        |
| pt\_BR |                                                     |                                 |   true    |   126   |          Planting Service          |
| pt\_BR |                                                     |                                 |   true    |   127   |             Rose Bush              |
| pt\_BR |                                                     |                                 |   true    |   128   |            Azalea Bush             |
| pt\_BR |                                                     |                                 |   true    |   129   |             Holly Bush             |
| pt\_BR |                                                     |                                 |   true    |   130   |             Plum Tree              |
| pt\_BR |                                                     |                                 |   true    |   132   |          Mary Consultant           |
| pt\_BR |               Nice Chair for outdoors               |                                 |   true    |   133   |            Patio Chair             |
| pt\_BR |               Nice Table for outdoors               |                                 |   true    |   134   |            Patio Table             |
| pt\_BR |                   Protect from UV                   |                                 |   true    |   135   |          Patio Sun Screen          |
| pt\_BR |            50 \# Bag of Lawn Fertilizer             |                                 |   true    |   136   |          Fertilizer \#50           |
| pt\_BR |                  10\# Bag of Mulch                  |                                 |   true    |   137   |             Mulch 10\#             |
| pt\_BR |                  4 Foot Metal Hoe                   |                                 |   true    |   138   |              Hoe 4 ft              |
| pt\_BR |                 4 Foot Bamboo Rake                  |                                 |   true    |   139   |            Rake Bamboo             |
| pt\_BR |                  4 Foot Metal Rake                  |                                 |   true    |   140   |             Rake Metal             |
| pt\_BR |                     Hand Weeder                     |                                 |   true    |   141   |               Weeder               |
| pt\_BR |                  Hand Transplanter                  |                                 |   true    |   142   |            Transplanter            |
| pt\_BR |                 Manual Grass Seeder                 |                                 |   true    |   143   |            Grass Seeder            |
| pt\_BR |                 Manual Lawn Tiller                  |                                 |   true    |   144   |            Lawn Tiller             |
| pt\_BR |         1 table, 4 Chairs and 1 Sun Screen          |                                 |   true    |   145   |        Patio Furniture Set         |
| pt\_BR |  Information on how to best to plant your future.   |                                 |   true    |   146   |            How To Plant            |
| pt\_BR |                                                     |                                 |   true    |   147   |         TShirt - Red Large         |
| pt\_BR |                                                     |                                 |   true    |   148   |        TShirt - Green Large        |
| pt\_BR |                                                     |                                 |   true    |  50000  |         Assembly Back Leg          |
| pt\_BR |                                                     |                                 |   true    |  50001  |         Assembly Front Leg         |
| pt\_BR |                                                     |                                 |   true    |  50002  | \#6-32 x 3/8 Socket Head Cap Screw |
| pt\_BR |                                                     |                                 |   true    |  50003  |             Ultra Glue             |
| pt\_BR |                                                     |                                 |   true    |  50004  |                Seat                |
| pt\_BR |                                                     |                                 |   true    |  50005  |            Back Support            |
| pt\_BR |            70 \# Bag of Lawn Fertilizer             |                                 |   true    |  50007  |          Fertilizer \#70           |
| pt\_BR |                                                     |                                 |   true    |  50008  |          Lawn Fertilizer           |
| pt\_BR |                                                     |                                 |   true    |  50009  |              Nitrogen              |
| pt\_BR |                                                     |                                 |   true    |  50010  |             Phosphorus             |
| pt\_BR |                                                     |                                 |   true    |  50012  |             Potassium              |
| pt\_BR |                                                     |                                 |   true    |  50013  |             Bag 50 Kg              |
| pt\_BR |                                                     |                                 |   true    |  50014  |             Bag 70 Kg              |
| pt\_BR |                                                     |                                 |   true    |  50015  |             Front Leg              |
| pt\_BR |                                                     |                                 |   true    |  50016  |              Back Leg              |
| pt\_BR |                                                     |                                 |   true    |  50017  |               Water                |
| pt\_BR |                                                     |                                 |   true    |  50018  |          Fertilizer Plant          |
| pt\_BR |                                                     |                                 |   true    |  50019  |           Assembly Area            |
| pt\_BR |                                                     |                                 |   true    |  50020  |             Paint Area             |
| pt\_BR |                                                     |                                 |   true    |  50021  |      Chrome Subcontract Area       |
| pt\_BR |                                                     |                                 |   true    |  50022  |          Inspection Area           |
| pt\_BR |                                                     |                                 |   true    |  50023  |          Furniture Plant           |
| pt\_BR |                                                     | Oak Trees may grow quite a bit. |   true    |   123   |              Oak Tree              |
| pt\_BR |                                                     |                                 |   true    |   122   |              Standard              |
| pt\_BR |                Travel related costs                 |                                 |   true    |   131   |            Travel cost             |
| pt\_BR |                                                     |                                 |   true    |  50024  |      Packing Production Line       |
| es\_CO |                                                     |                                 |   true    |  50026  |           Area de Secado           |
| es\_CO |                                                     |                                 |   true    |  50027  | Area de Inspección de Fertilizante |

</div>

</div>
