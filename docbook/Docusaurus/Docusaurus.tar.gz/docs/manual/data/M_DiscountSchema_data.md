<div id="d419200e1" class="table">

<div class="table-title">

Table 1. Esquema de
Descontos

</div>

<div class="table-contents">

|                     |                                                                             |                  |                 |                             |                       |                      |                     |                 |                  |                       |
| :-----------------: | :-------------------------------------------------------------------------: | :--------------: | :-------------: | :-------------------------: | :-------------------: | :------------------: | :-----------------: | :-------------: | :--------------: | :-------------------: |
| Nível de Acumulação |                                  Descrição                                  | Tipo de Desconto | Desconto Fixo % | Desconto Raso do P.Negócios | Baseado em Quantidade | Esquema de Descontos |        Nome         | Processar Agora | Roteiro (Script) |     Válido desde      |
|                     |                                                                             |        P         |                 |            false            |         true          |         100          |     Sales 2001      |                 |                  | 2001-01-01 00:00:00.0 |
|                     |                                                                             |        P         |                 |            false            |         true          |         101          |    Purchase 2001    |                 |                  | 2001-05-21 00:00:00.0 |
|          L          | Just an example of additional 5% when ordering more then 100 units per line |        B         |        0        |            false            |         true          |         102          | 5% Discount if 100+ |      false      |                  | 2004-01-01 00:00:00.0 |
|          L          |                                                                             |        P         |       0.0       |            false            |         true          |       1000000        |       Padrão        |      false      |                  | 2015-02-09 00:00:00.0 |
|          L          |                                                                             |        P         |        0        |            false            |         true          |       1000001        |   Redução de 30%    |      false      |                  | 2015-02-27 00:00:00.0 |

</div>

</div>
