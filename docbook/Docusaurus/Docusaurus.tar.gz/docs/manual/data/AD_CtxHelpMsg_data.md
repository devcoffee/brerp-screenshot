<div id="d7959e1" class="table">

<div class="table-title">

Table 1. Menssagem de ajuda de
contexto

</div>

<div class="table-contents">

|                   |                                |                                                                                                                                                                                                                                                                             |
| :---------------: | :----------------------------: | :-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------: |
| Ajuda de Contexto | Menssagem de ajuda de contexto |                                                                                                                              Texto de Mensagem                                                                                                                              |
|      5000000      |            5000000             | Temos diversas varíaveis disponíveis para o uso dentro das instruções, que são elas: @JUROS@ - Exibe o valor dos juros, @CONDPAG@ - Exibe a condição de pagamento, @NOTAFISCAL@ - Exibe o número da nota fiscal, @MULTA@ - Exibe a quantidade de dias de atraso permitidos. |

</div>

</div>
