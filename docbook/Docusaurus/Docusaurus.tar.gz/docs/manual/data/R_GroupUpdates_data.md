<div id="d541938e1" class="table">

<div class="table-title">

Table 1. R\_GroupUpdates

</div>

<div class="table-contents">

|                 |              |       |
| :-------------: | :----------: | :---: |
| Usuário/Contato | Auto-Serviço | Grupo |
|       101       |    false     |  100  |

</div>

</div>
