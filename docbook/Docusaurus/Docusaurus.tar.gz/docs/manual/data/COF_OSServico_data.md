<div id="d133050e1" class="table">

<div class="table-title">

Table 1. COF\_OSServico\_ID

</div>

<div class="table-contents">

|          |        |                  |                    |         |                |           |             |                |            |
| :------: | :----: | :--------------: | :----------------: | :-----: | :------------: | :-------: | :---------: | :------------: | :--------: |
| Faturado | Motivo | Ordem de Serviço | COF\_OSServico\_ID | Serviço | Valor Unitário | Descrição | Total Geral | Lista de Preço | Quantidade |
|   true   |        |     5000000      |      5000000       | 5000026 |      155       |           |     155     |    1000005     |     1      |

</div>

</div>
