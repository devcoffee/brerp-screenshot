<div id="d117701e1" class="table">

<div class="table-title">

Table 1. Informações Lista de
Embarque

</div>

<div class="table-contents">

|                     |                   |           |        |             |              |                           |       |                         |            |                           |                     |                    |                    |      |             |           |        |          |        |              |         |
| :-----------------: | :---------------: | :-------: | :----: | :---------: | :----------: | :-----------------------: | :---: | :---------------------: | :--------: | :-----------------------: | :-----------------: | :----------------: | :----------------: | :--: | :---------: | :-------: | :----: | :------: | :----: | :----------: | :-----: |
| Número do Documento | Região de Entrega | Motorista |  Peso  | Total Geral | Equipamentos | Data de Lista de Embarque | Placa |     Data de Início      | Data Final | Tipo da Lista de Embarque | Km Ini. Equipamento | Km Fim Equipamento | Número Habilitação | CPF  | Organização | Descrição | Estado | Impresso | Chassi | Estado Placa | Empresa |
|       1000000       | INTERIOR PAULISTA |   null    | 886.00 |  16010.00   |     null     |    2017-12-01 00:00:00    | null  | 2018-01-15 11:35:01.725 |    null    |             D             |        null         |        null        |        null        | null |   1000001   |   null    |   OP   |    N     |  null  |     null     | 1000000 |
|       1000001       |       null        |   null    |  75.0  |    3250     |     null     |    2017-12-13 00:00:00    | null  | 2018-01-15 13:14:47.992 |    null    |             P             |        null         |        null        |        null        | null |   1000001   |   null    |   OP   |    N     |  null  |     null     | 1000000 |
|       1000002       |       null        |   null    | 16.500 |   1500.00   |     null     |    2018-01-24 00:00:00    | null  | 2018-01-24 11:30:04.472 |    null    |             P             |        null         |        null        |        null        | null |   1000001   |   null    |   OP   |    N     |  null  |     null     | 1000000 |
|       1000003       | INTERIOR PAULISTA |   null    | 141.0  |    6896     |     null     |    2018-03-02 00:00:00    | null  | 2018-03-02 08:18:27.749 |    null    |             D             |        null         |        null        |        null        | null |   1000001   |   null    |   OP   |    N     |  null  |     null     | 1000000 |

</div>

</div>
