<div id="d238973e1" class="table">

<div class="table-title">

Table 1. Configuração de Provedor de
Impostos

</div>

<div class="table-contents">

|                                      |                                                                                       |                    |                                           |     |
| :----------------------------------: | :-----------------------------------------------------------------------------------: | :----------------: | :---------------------------------------: | :-: |
| Configuração de Provedor de Impostos |                                       Descrição                                       |        Nome        |      Classe de Provedor de Impostos       | URL |
|               1000001                | Utilizado para realizar os cálculos de impostos de acordo com a legislação brasileira | BrERP Tax Provider | org.brerp.base.component.BrERPTaxProvider |     |

</div>

</div>
