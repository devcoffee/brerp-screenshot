<div id="d543063e1" class="table">

<div class="table-title">

Table 1. Tipo de
Solicitação

</div>

<div class="table-contents">

|                 |                          |                   |                   |                 |           |                                  |                  |                                |                      |        |                 |                  |         |                         |              |                       |                     |                 |
| :-------------: | :----------------------: | :---------------: | :---------------: | :-------------: | :-------: | :------------------------------: | :--------------: | :----------------------------: | :------------------: | :----: | :-------------: | :--------------: | :-----: | :---------------------: | :----------: | :-------------------: | :-----------------: | :-------------: |
| Usuário/Contato | Prazo de Vencimento Auto | Template de Email | Confidencialidade | Cor do Conteúdo | Descrição | Tolerância da Data do Vencimento | Cor do Cabeçalho | Criar Solicitação de Alteração | Inform. Confidencial | Padrão | Email ao Vencer | Email ao Atrasar | Indexed | Faturado (Nota Emitida) | Auto-Serviço |         Nome          | Tipo de Solicitação | Status Category |
|                 |                          |                   |         C         |                 |           |                7                 |                  |             false              |        false         | false  |      false      |      false       |  true   |          false          |     true     | Request for Quotation |         100         |       100       |
|                 |                          |                   |         C         |                 |           |                7                 |                  |             false              |        false         | false  |      false      |      false       |  true   |          false          |     true     |    Service Request    |         101         |       100       |
|                 |                          |                   |         C         |                 |           |                7                 |                  |             false              |        false         | false  |      false      |      false       |  true   |          false          |     true     |       Warranty        |         102         |       100       |

</div>

</div>
