<div id="d2499e1" class="table">

<div class="table-title">

Table 1. Gráfico

</div>

<div class="table-contents">

|         |            |                 |           |              |                  |                |             |                                  |             |            |                  |                  |
| :-----: | :--------: | :-------------: | :-------: | :----------: | :--------------: | :------------: | :---------: | :------------------------------: | :---------: | :--------: | :--------------: | :--------------: |
| Gráfico | Orientação | Tipo de Gráfico | Descrição | Domain Label | Tipo de Entidade | Exibir Legenda | Time Series |               Nome               | Range Label | Time Scope | Unidade de Tempo | Altura da Janela |
|  50003  |     V      |       BS        |           |              |        D         |      true      |    false    |         My Open Requests         |             |     0      |                  |       300        |
|  50001  |     H      |       P3        |           | Opportunity  |        D         |      true      |    false    |   My Opportunities by Campaign   |  Campaign   |     0      |                  |       300        |
|  50000  |     V      |       BS        |           | Sales Stage  |        D         |      true      |    false    |        My Sales Pipeline         |    Value    |     0      |                  |       300        |
| 1500013 |     V      |       RC        |           |              |    BRERP0001     |      true      |    false    | Estoque Disponivel por Categoria |             |     0      |                  |        0         |
| 1500042 |     V      |       RC        |           |              |        U         |      true      |    false    |       Clientes por Estado        |             |     0      |                  |       300        |
| 1500047 |     V      |       WC        |           |    Domain    |        U         |     false      |    false    |    Maiores Pedidos Hora x Dia    |    Range    |     0      |                  |       300        |
| 1500046 |     V      |       LC        |           |              |        U         |     false      |    true     |  Analise de Curvatura de Fluxo   |             |     90     |        D         |       300        |
|  50002  |     V      |       LC        |           |     Mês      |        D         |     false      |    true     |          Vendas Anuais           |    Valor    |     12     |        M         |       300        |
| 1500040 |     V      |       B3        |           |              |        U         |     false      |    false    |      Ranking de Vendedores       |             |     0      |                  |       300        |
| 1500043 |     V      |       AS        |           |              |        U         |     false      |    true     |   Vendas Por Categoria 30 dias   |             |     30     |        D         |       300        |
| 1500044 |     V      |       LC        |           |              |        U         |     false      |    true     |      Fluxo de Caixa 30 Dias      |             |     30     |        D         |       300        |
| 1500045 |     V      |       WC        |           |              |        U         |     false      |    false    |    Vendas por Estado x Cidade    |             |     0      |                  |       300        |
| 1500039 |     V      |       B3        |           |              |        U         |      true      |    false    |  Top 5 por Categoria de Produto  |             |     0      |                  |       300        |

</div>

</div>
