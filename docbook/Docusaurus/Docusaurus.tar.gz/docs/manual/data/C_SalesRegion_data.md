<div id="d238540e1" class="table">

<div class="table-title">

Table 1. Região de
Vendas

</div>

<div class="table-contents">

|                  |           |        |                 |                          |                         |                          |
| :--------------: | :-------: | :----: | :-------------: | :----------------------: | :---------------------: | :----------------------: |
| Região de Vendas | Descrição | Padrão | Nível de Resumo |           Nome           | Representante de Vendas |      Chave de Busca      |
|       101        |           | false  |      false      |           East           |                         |           East           |
|       102        |           | false  |      false      |           West           |                         |           West           |
|     1000000      |           | false  |      false      |          Padrão          |                         |          Padrão          |
|     1000002      |           | false  |      true       |         SUDESTE          |           100           |         SUDESTE          |
|     1000007      |           | false  |      false      |       CENTRO-OESTE       |         1000020         |       CENTRO-OESTE       |
|     1000005      |           | false  |      false      |   SUDESTE - SÃO PAULO    |         1000019         |   SUDESTE - SÃO PAULO    |
|     1000006      |           | false  |      false      | SUDESTE - DEMAIS ESTADOS |         1000022         | SUDESTE - DEMAIS ESTADOS |
|     1000004      |           | false  |      false      |         NORDESTE         |         1000021         |         NORDESTE         |
|     1000003      |           | false  |      false      |          NORTE           |         1000023         |          NORTE           |
|     1000001      |           | false  |      false      |           SUL            |         1000019         |           SUL            |

</div>

</div>
