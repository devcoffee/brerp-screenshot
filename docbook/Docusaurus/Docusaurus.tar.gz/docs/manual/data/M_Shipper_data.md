<div id="d459892e1" class="table">

<div class="table-title">

Table 1. Transportadora

</div>

<div class="table-contents">

|                      |                          |                           |                |                       |                             |
| :------------------: | :----------------------: | :-----------------------: | :------------: | :-------------------: | :-------------------------: |
| Parceiro de Negócios | Criar linhas a partir de | Configuração do Remetente | Transportadora | Processo do Remetente |            Nome             |
|                      |                          |                           |      100       |                       |             UPS             |
|                      |                          |                           |     50002      |                       | Furniture Internal Shipper  |
|                      |                          |                           |     50001      |                       | Fertilizer Internal Shipper |
|       1000026        |            N             |                           |    1000000     |                       |    Rodoviário So no Grão    |
|       5000004        |            N             |                           |    5000000     |                       |    TRANSPORTADORA MODELO    |

</div>

</div>
