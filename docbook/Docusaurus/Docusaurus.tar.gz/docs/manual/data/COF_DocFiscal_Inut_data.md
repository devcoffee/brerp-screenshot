<div id="d131950e1" class="table">

<div class="table-title">

Table 1. COF\_DocFiscal\_Inut\_ID

</div>

<div class="table-contents">

|                          |                                  |       |
| :----------------------: | :------------------------------: | :---: |
| COF\_DocFiscal\_Inut\_ID | Inutilização de Numeração de NFe | Valor |
|         5000000          |             5000000              | 5008  |
|         5000001          |             5000001              | 5029  |
|         5000002          |             5000002              | 10003 |
|         5000003          |             5000003              | 10004 |
|         5000004          |             5000004              |  205  |

</div>

</div>
