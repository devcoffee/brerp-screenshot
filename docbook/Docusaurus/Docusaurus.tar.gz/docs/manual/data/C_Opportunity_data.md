<div id="d202051e1" class="table">

<div class="table-title">

Table 1. Oportunidade de
Vendas

</div>

<div class="table-contents">

|                 |                      |          |          |                    |                           |                 |             |                        |        |       |                   |                       |                     |                             |                      |                       |               |            |                         |                       |
| :-------------: | :------------------: | :------: | :------: | :----------------: | :-----------------------: | :-------------: | :---------: | :--------------------: | :----: | :---: | :---------------: | :-------------------: | :-----------------: | :-------------------------: | :------------------: | :-------------------: | :-----------: | :--------: | :---------------------: | :-------------------: |
| Usuário/Contato | Parceiro de Negócios | Campanha | Moeda De | Data de Fechamento | Descrição do Encerramento | Processar Agora | Comentários | Oportunidade de Vendas | Pedido | Custo | Estágio de Vendas |       Descrição       | Número do Documento | Data de Fechamento Prevista | Estado de Fechamento | Valor da Oportunidade | Probabilidade | Processado | Representante de Vendas |    Valor Ponderado    |
|     5000018     |       5000023        |          |   297    |                    |                           |                 |             |        5000000         |        |       |      5000000      |                       |       1000000       |    2018-01-31 00:00:00.0    |        false         |          0.0          |     10.00     |   false    |           100           |         0E-20         |
|     5000019     |       5000024        |          |   297    |                    |                           |                 |             |        5000001         |        |       |      5000000      |                       |       1000001       |    2018-01-18 00:00:00.0    |        false         |          0.0          |     10.00     |   false    |           100           |         0E-20         |
|     5000021     |       5000027        |          |   297    |                    |                           |                 |             |        5000002         |        |       |      5000000      | Orçamento de proposta |       1000002       |    2018-02-09 00:00:00.0    |        false         |         50000         |     10.00     |   false    |         1000023         | 5000.0000000000000000 |

</div>

</div>
