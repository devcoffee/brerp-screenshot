<div id="d543281e1" class="table">

<div class="table-title">

Table 1. Resolução

</div>

<div class="table-contents">

|           |                  |         |           |
| :-------: | :--------------: | :-----: | :-------: |
| Descrição | Comentário/Ajuda |  Nome   | Resolução |
|           |                  | Solved  |    100    |
|           |                  | Delayed |    101    |
|           |                  | Dropped |    102    |

</div>

</div>
