<div id="d255535e1" class="table">

<div class="table-title">

Table 1. Gerador de
Razão

</div>

<div class="table-contents">

|                  |                   |                  |                 |                                                    |             |                          |                  |                                                                                    |                                  |                    |
| :--------------: | :---------------: | :--------------: | :-------------: | :------------------------------------------------: | :---------: | :----------------------: | :--------------: | :--------------------------------------------------------------------------------: | :------------------------------: | :----------------: |
| Esquema Contábil | Tipo de Documento | Ajustar Conta CR | Conta Ajuste DR |                     Descrição                      | Gerar Razão | Categoria de Razão Geral | Gerador de Razão |                                  Comentário/Ajuda                                  |               Nome               | Tipo de Lançamento |
|       101        |        115        |       771        |       771       |  Step 1 - close Revenue/Expense to Income Summary  |      N      |           108            |      200000      |            Processing date start on 1900 - execute on adjustment period            | Year-End Closing Sample - step 1 |         A          |
|       101        |        115        |       631        |       631       | Step 1 - close Income Summary to Retained Earnings |      N      |           108            |      200001      | Executed on year-end - must be executed after -\> Year-End Closing Sample - step 1 | Year-End Closing Sample - step 2 |         A          |
|     1000001      |      1000040      |     1000430      |     1000430     |                       teste                        |      N      |                          |     5000000      |                                                                                    |              teste               |         C          |

</div>

</div>
