<div id="d156145e1" class="table">

<div class="table-title">

Table 1. Campanha

</div>

<div class="table-contents">

|          |         |        |                             |                       |                 |               |                       |                |
| :------: | :-----: | :----: | :-------------------------: | :-------------------: | :-------------: | :-----------: | :-------------------: | :------------: |
| Campanha |  Canal  | Custos |          Descrição          |      Data Final       | Nível de Resumo |     Nome      |    Data de Início     | Chave de Busca |
|   102    |   103   |   0    | Brochure Mailing for Spring | 2003-03-31 00:00:00.0 |      false      | Spring Mailer | 2003-01-02 00:00:00.0 |  SpringMailer  |
|   101    |   101   |   0    |                             |                       |      false      |   Standard    |                       |    Standard    |
| 1000000  | 1000000 |   0    |                             |                       |      false      |    Padrão     |                       |     Padrão     |

</div>

</div>
