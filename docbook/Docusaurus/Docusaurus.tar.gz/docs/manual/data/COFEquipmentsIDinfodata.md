<div id="d117689e1" class="table">

<div class="table-title">

Table 1. Informações de
Equipamento

</div>

<div class="table-contents">

|                   |       |        |              |       |        |                       |         |                    |           |
| :---------------: | :---: | :----: | :----------: | :---: | :----: | :-------------------: | :-----: | :----------------: | :-------: |
| Número Ativo Fixo | Placa | Chassi | Estado Placa | Marca | Modelo | Habilitação Requerida | RENAVAM | Próxima Manutenção | Motorista |

</div>

</div>
