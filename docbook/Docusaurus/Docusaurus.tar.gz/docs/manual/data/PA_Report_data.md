<div id="d539309e1" class="table">

<div class="table-title">

Table 1. Relatório
Financeiro

</div>

<div class="table-contents">

|                      |                  |            |                                         |                |                    |                |                                                |                   |                                         |                                   |             |                      |                                 |                 |
| :------------------: | :--------------: | :--------: | :-------------------------------------: | :------------: | :----------------: | :------------: | :--------------------------------------------: | :---------------: | :-------------------------------------: | :-------------------------------: | :---------: | :------------------: | :-----------------------------: | :-------------: |
| Formato de Impressão | Esquema Contábil | Calendário |                Descrição                | Jasper Process | Jasper Process Now | Listar Origens | Incluir contas de origem sem nenhuma transação | Listar Transações |                  Nome                   | Conjunto de Colunas de Relatórios | Report Cube | Relatório Financeiro | Conjunto de Linhas de Relatório | Processar Agora |
|                      |       101        |    102     |                                         |                |                    |      true      |                     false                      |       false       |     Income Statement Current Month      |                101                |             |         101          |               102               |      false      |
|                      |       101        |    102     |                                         |                |                    |      true      |                     false                      |       true        |       Balance Sheet Current Month       |                100                |             |         100          |               100               |      false      |
|                      |       101        |    102     |         Statement of Cash Flows         |                |                    |     false      |                     false                      |       false       |         Statement of Cash Flows         |                102                |             |         102          |               104               |      false      |
|       5000088        |     1000001      |  1000000   |     Balancete Comparativo 12 Meses      |                |         N          |      true      |                     false                      |       false       |     Balancete Comparativo 12 Meses      |              5000000              |             |       5000000        |             5000000             |      false      |
|       5000088        |     1000001      |  1000000   | CUSTOS/ DESPESAS - Comparativo 12 Meses |                |         N          |      true      |                     false                      |       false       | CUSTOS/ DESPESAS - Comparativo 12 Meses |              5000000              |             |       5000001        |             5000001             |      false      |

</div>

</div>
