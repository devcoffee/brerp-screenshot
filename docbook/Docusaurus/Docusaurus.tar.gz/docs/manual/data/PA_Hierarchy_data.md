<div id="d533287e1" class="table">

<div class="table-title">

Table 1. Hierarquia de
Relatórios

</div>

<div class="table-contents">

|                  |                     |                      |                    |                       |                   |                   |                            |                           |                           |                           |                          |
| :--------------: | :-----------------: | :------------------: | :----------------: | :-------------------: | :---------------: | :---------------: | :------------------------: | :-----------------------: | :-----------------------: | :-----------------------: | :----------------------: |
| Árvore de Contas | Árvore de Atividade | Árvore Parc.Negócios | Árvore de Campanha | Árvore da Organização | Árvore de Produto | Árvore de Projeto | Árvore de Região de Vendas |         Descrição         |     Comentário/Ajuda      |           Nome            | Hierarquia de Relatórios |
|     1000014      |       1000011       |       1000007        |      1000010       |        1000008        |      1000006      |      1000015      |          1000009           | Relatorio Sem Consoliação | Relatorio Sem Consoliação | Relatorio Sem Consoliação |         5000000          |

</div>

</div>
