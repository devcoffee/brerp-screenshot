<div id="d238891e1" class="table">

<div class="table-title">

Table 1. Categoria de
Imposto

</div>

<div class="table-contents">

|                     |                      |                    |        |                         |
| :-----------------: | :------------------: | :----------------: | :----: | :---------------------: |
| Código de Commodity | Categoria de Imposto |     Descrição      | Padrão |          Nome           |
|                     |         107          |                    |  true  |        Standard         |
|                     |       1000000        |                    |  true  |         Padrão          |
|                     |       1000001        |                    | false  |          VENDA          |
|                     |       1000002        |                    | false  |         COMPRA          |
|                     |       1000003        |                    | false  |    REMESSA (ENTRADA)    |
|                     |       1000004        |                    | false  |     REMESSA (SAIDA)     |
|                     |       1000006        |                    | false  |    DEVOLUÇÃO (VENDA)    |
|                     |       1000005        |                    | false  |   DEVOLUÇÃO (COMPRA)    |
|                     |       1000007        |                    | false  | TRANSFERÊNCIA (ENTRADA) |
|                     |       1000008        |                    | false  |  TRANSFERÊNCIA (SAIDA)  |
|                     |       1000009        |                    | false  |    SIMPLES NACIONAL     |
|                     |       5000000        |   SERVIÇO SAIDA    | false  |      SERVIÇO SAIDA      |
|                     |       5000001        | DESPESAS - ENTRADA | false  |   DESPESAS - ENTRADA    |
|                     |       5000002        |     Importacao     | false  |       Importacao        |
|                     |       1000010        |  SERVIÇO ENTRADA   | false  |     SERVIÇO ENTRADA     |

</div>

</div>
