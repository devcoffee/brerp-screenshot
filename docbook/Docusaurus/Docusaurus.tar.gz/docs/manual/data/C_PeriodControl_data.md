<div id="d235431e1" class="table">

<div class="table-title">

Table 1. Controle de
Períodos

</div>

<div class="table-contents">

|                      |                      |                           |                      |                   |                 |
| :------------------: | :------------------: | :-----------------------: | :------------------: | :---------------: | :-------------: |
| Controle de Períodos | Período (Ano Fiscal) | Tipo de Base de Documento | Atividade no Período | Estado do Período | Processar Agora |
|         280          |         147          |            ARF            |          N           |         O         |                 |
|         282          |         147          |            ARR            |          N           |         O         |                 |
|         283          |         147          |            GLD            |          N           |         O         |                 |
|         285          |         147          |            MMI            |          N           |         O         |                 |
|         286          |         147          |            MMM            |          N           |         O         |                 |
|         287          |         147          |            MMR            |          N           |         O         |                 |
|         289          |         147          |            POO            |          N           |         O         |                 |
|         290          |         147          |            POR            |          N           |         O         |                 |
|         292          |         136          |            CMA            |          N           |         C         |                 |
|         293          |         136          |            CMB            |          N           |         C         |                 |
|         294          |         136          |            CMC            |          N           |         C         |                 |
|         296          |         137          |            CMB            |          N           |         C         |                 |
|         297          |         137          |            CMC            |          N           |         C         |                 |
|         299          |         138          |            CMB            |          N           |         C         |                 |
|         300          |         138          |            CMC            |          N           |         C         |                 |
|         302          |         139          |            CMB            |          N           |         C         |                 |
|         303          |         139          |            CMC            |          N           |         C         |                 |
|         304          |         140          |            CMA            |          N           |         C         |                 |
|         306          |         140          |            CMC            |          N           |         C         |                 |
|         307          |         141          |            CMA            |          N           |         C         |                 |
|         309          |         141          |            CMC            |          N           |         C         |                 |
|         310          |         142          |            CMA            |          N           |         O         |                 |
|         312          |         142          |            CMC            |          N           |         O         |                 |
|         313          |         143          |            CMA            |          N           |         O         |                 |
|         314          |         143          |            CMB            |          N           |         O         |                 |
|         316          |         144          |            CMA            |          N           |         O         |                 |
|         317          |         144          |            CMB            |          N           |         O         |                 |
|         319          |         145          |            CMA            |          N           |         O         |                 |
|         320          |         145          |            CMB            |          N           |         O         |                 |
|         322          |         146          |            CMA            |          N           |         O         |                 |
|         323          |         146          |            CMB            |          N           |         O         |                 |
|         324          |         146          |            CMC            |          N           |         O         |                 |
|         326          |         147          |            CMB            |          N           |         O         |                 |
|         327          |         147          |            CMC            |          N           |         O         |                 |
|         329          |         148          |            API            |          N           |         O         |                 |
|         330          |         148          |            APP            |          N           |         O         |                 |
|         331          |         148          |            ARC            |          N           |         O         |                 |
|         333          |         148          |            ARI            |          N           |         O         |                 |
|         334          |         148          |            ARR            |          N           |         O         |                 |
|         336          |         148          |            CMB            |          N           |         O         |                 |
|         337          |         148          |            CMC            |          N           |         O         |                 |
|         715          |         165          |            MMM            |          N           |         O         |                 |
|         716          |         165          |            MMP            |          N           |         O         |                 |
|         717          |         165          |            MMR            |          N           |         O         |                 |
|         719          |         165          |            MXI            |          N           |         O         |                 |
|         720          |         165          |            MXP            |          N           |         O         |                 |
|         722          |         165          |            POR            |          N           |         O         |                 |
|         1175         |         182          |            MXI            |          N           |         O         |                 |
|         1177         |         182          |            PJI            |          N           |         O         |                 |
|         1178         |         182          |            POO            |          N           |         O         |                 |
|         1179         |         182          |            POR            |          N           |         O         |                 |
|         1181         |         183          |            APC            |          N           |         O         |                 |
|         1183         |         183          |            APP            |          N           |         O         |                 |
|         1185         |         183          |            ARF            |          N           |         O         |                 |
|         1186         |         183          |            ARI            |          N           |         O         |                 |
|         1188         |         183          |            CMA            |          N           |         O         |                 |
|         1189         |         183          |            CMB            |          N           |         O         |                 |
|         1190         |         183          |            CMC            |          N           |         O         |                 |
|         1192         |         183          |            GLJ            |          N           |         O         |                 |
|         1193         |         183          |            MMI            |          N           |         O         |                 |
|         1195         |         183          |            MMP            |          N           |         O         |                 |
|         1196         |         183          |            MMR            |          N           |         O         |                 |
|         1197         |         183          |            MMS            |          N           |         O         |                 |
|         1199         |         183          |            MXP            |          N           |         O         |                 |
|         1200         |         183          |            PJI            |          N           |         O         |                 |
|         1202         |         183          |            POR            |          N           |         O         |                 |
|         1203         |         183          |            SOO            |          N           |         O         |                 |
|         1481         |         196          |            MMS            |          N           |         O         |      false      |
|         1482         |         196          |            PJI            |          N           |         O         |      false      |
|         1483         |         196          |            CMA            |          N           |         O         |      false      |
|         1485         |         196          |            MMP            |          N           |         O         |      false      |
|         1486         |         196          |            GLD            |          N           |         O         |      false      |
|         1487         |         196          |            CMC            |          N           |         O         |      false      |
|         1489         |         196          |            MMM            |          N           |         O         |      false      |
|         1490         |         196          |            MMI            |          N           |         O         |      false      |
|         1491         |         196          |            ARF            |          N           |         O         |      false      |
|         1494         |         196          |            API            |          N           |         O         |      false      |
|         1495         |         196          |            APC            |          N           |         O         |      false      |
|         1496         |         196          |            GLJ            |          N           |         O         |      false      |
|         1499         |         196          |            ARC            |          N           |         O         |      false      |
|         1500         |         196          |            ARR            |          N           |         O         |      false      |
|         1503         |         196          |            APP            |          N           |         O         |      false      |
|         1505         |         196          |            POR            |          N           |         O         |      false      |
|         1506         |         196          |            SOO            |          N           |         O         |      false      |
|         1515         |         197          |            MMR            |          N           |         O         |      false      |
|         1517         |         197          |            PJI            |          N           |         O         |      false      |
|         1518         |         197          |            CMA            |          N           |         O         |      false      |
|         1519         |         197          |            MXI            |          N           |         O         |      false      |
|         1521         |         197          |            GLD            |          N           |         O         |      false      |
|         1522         |         197          |            CMC            |          N           |         O         |      false      |
|         1523         |         197          |            MXP            |          N           |         O         |      false      |
|         1525         |         197          |            MMI            |          N           |         O         |      false      |
|         1526         |         197          |            ARF            |          N           |         O         |      false      |
|         1529         |         197          |            API            |          N           |         O         |      false      |
|         1530         |         197          |            APC            |          N           |         O         |      false      |
|         1531         |         197          |            GLJ            |          N           |         O         |      false      |
|         1534         |         197          |            ARC            |          N           |         O         |      false      |
|         1535         |         197          |            ARR            |          N           |         O         |      false      |
|         1538         |         197          |            APP            |          N           |         O         |      false      |
|         1540         |         197          |            POR            |          N           |         O         |      false      |

</div>

</div>
