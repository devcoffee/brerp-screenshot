<div id="d543307e1" class="table">

<div class="table-title">

Table 1. Status
Category

</div>

<div class="table-contents">

|                        |                  |        |         |                 |
| :--------------------: | :--------------: | :----: | :-----: | :-------------: |
|       Descrição        | Comentário/Ajuda | Padrão |  Nome   | Status Category |
| Default Request Status |                  |  true  | Default |       100       |

</div>

</div>
