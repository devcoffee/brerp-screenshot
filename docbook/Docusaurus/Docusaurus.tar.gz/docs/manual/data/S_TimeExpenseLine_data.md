<div id="d543804e1" class="table">

<div class="table-title">

Table 1. Linha de
Despesa

</div>

<div class="table-contents">

|           |                      |          |          |                 |                  |                          |         |                 |                   |     |                       |                                    |                  |                 |                         |                    |            |         |      |                |                   |            |            |                     |                        |                       |                      |                  |               |
| :-------: | :------------------: | :------: | :------: | :-------------: | :--------------: | :----------------------: | :-----: | :-------------: | :---------------: | :-: | :-------------------: | :--------------------------------: | :--------------: | :-------------: | :---------------------: | :----------------: | :--------: | :-----: | :--: | :------------: | :---------------: | :--------: | :--------: | :-----------------: | :--------------------: | :-------------------: | :------------------: | :--------------: | :-----------: |
| Atividade | Parceiro de Negócios | Campanha | Moeda De | Linha de Fatura | Valor Convertido | Linha de Ordem de Vendas | Projeto | Fase de Projeto | Tarefa de Projeto | UDM |    Data de Despesa    |             Descrição              | Valor da Despesa | Preço de Fatura | Faturado (Nota Emitida) | Relatório de Horas | Linha Núm. | Produto | Nota | Preço Faturado | Preço Reembolsado | Processado | Quantidade | Quantidade Faturada | Quantidade Reembolsada | Atribuição de Recurso | Relatório de Despesa | Linha de Despesa | Tipo de Tempo |
|           |         118          |          |   100    |                 |        0         |                          |   101   |                 |                   |     | 2003-02-03 00:00:00.0 | Garden Layout (Initial Discussion) |        0         |        0        |          true           |       false        |     10     |   132   |      |                |                   |    true    |     3      |                     |                        |          100          |         100          |       100        |               |
|           |         118          |          |   100    |                 |        0         |                          |   101   |                 |                   |     | 2003-02-03 00:00:00.0 |   Garden Layout (Discuss Budget)   |        0         |       100       |          true           |       false        |     20     |   132   |      |                |                   |    true    |     1      |                     |                        |          101          |         100          |       101        |               |
|           |         118          |          |   100    |                 |        30        |                          |   101   |                 |                   |     | 2003-02-03 00:00:00.0 |                                    |        30        |        0        |          false          |       false        |     30     |   131   |      |                |                   |    true    |     1      |                     |                        |                       |         100          |       102        |               |
|           |         118          |          |   100    |                 |        0         |                          |   101   |                 |                   | 101 | 2002-06-04 00:00:00.0 |            Preparation             |        0         |        0        |          false          |        true        |     40     |         |      |                |                   |    true    |     5      |                     |                        |                       |         100          |       103        |               |

</div>

</div>
