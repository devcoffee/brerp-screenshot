<div id="d178425e1" class="table">

<div class="table-title">

Table 1. Elemento

</div>

<div class="table-contents">

|         |          |          |              |              |            |                          |      |             |               |                          |                  |
| :-----: | :------: | :------: | :----------: | :----------: | :--------: | :----------------------: | :--: | :---------: | :-----------: | :----------------------: | :--------------: |
| Árvore  | Elemento | Entidade | Referenciado | Válido Desde | Válido Até |        Descrição         | Tipo | Balanceando | Conta Natural |           Nome           | Formato do Valor |
|   101   |   105    |          |    false     |              |            |   GardenWorld Account    |  A   |    false    |     true      |   GardenWorld Account    |                  |
| 5000000 | 5000001  |          |    false     |              |            |     Centro de Custo      |  A   |    false    |     false     |     Centro de Custo      |                  |
| 5000001 | 5000003  |          |    false     |              |            | Metodo de Contabilização |  A   |    false    |     true      | Metodo de Contabilização |                  |
| 1000014 | 1000000  |          |    false     |              |            | Plano de Contas Contabil |  A   |    false    |     true      | Plano de Contas Contabil |                  |

</div>

</div>
