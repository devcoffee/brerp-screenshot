<div id="d0e1" class="table">

<div class="table-title">

Table 1. Registro (log) do Processador de
Alertas

</div>

<div class="table-contents">

|                        |                                          |                |           |       |             |                          |                   |
| :--------------------: | :--------------------------------------: | :------------: | :-------: | :---: | :---------: | :----------------------: | :---------------: |
| Processador de Alertas | Registro (log) do Processador de Alertas | Dados Binários | Descrição | Erro  | Referência  |          Resumo          | Texto de Mensagem |
|          100           |                 5000391                  |                |           | false | \#0 - 00.86 | Total=0 - Logs deleted=0 |                   |
|          100           |                 5000392                  |                |           | false | \#0 - 00.29 | Total=0 - Logs deleted=1 |                   |
|          100           |                 5000393                  |                |           | false | \#0 - 00.87 | Total=0 - Logs deleted=0 |                   |
|          100           |                 5000394                  |                |           | false | \#0 - 00.38 | Total=0 - Logs deleted=1 |                   |
|          100           |                 5000395                  |                |           | false | \#0 - 00.48 | Total=0 - Logs deleted=1 |                   |

</div>

</div>
