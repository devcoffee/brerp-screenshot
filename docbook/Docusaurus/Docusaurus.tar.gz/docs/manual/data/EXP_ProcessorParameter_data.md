<div id="d250340e1" class="table">

<div class="table-title">

Table 1. Parâmetro do
Processador

</div>

<div class="table-contents">

|                                        |                           |                          |                                           |                                                |                    |                          |
| :------------------------------------: | :-----------------------: | :----------------------: | :---------------------------------------: | :--------------------------------------------: | :----------------: | :----------------------: |
|               Descrição                | Processador de Exportação | Parâmetro do Processador |             Comentário/Ajuda              |                      Nome                      | Valor de Parâmetro |      Chave de Busca      |
| Export Processor Parameter Description |           50000           |          50000           |         Processor Parameter Help          | Name of file under which xml will be exported  | example-export.xml |         fileName         |
| Export Processor Parameter Description |           50000           |          50001           |         Processor Parameter Help          |   Name of folder where file will be exported   |      C:/temp/      |          folder          |
| Export Processor Parameter Description |           50001           |          50002           | JMS Topic Export Processor Parameter Help |  Name of JMS Topic where xml will be exported  |    ExampleTopic    |        topicName         |
| Export Processor Parameter Description |           50001           |          50003           | JMS Topic Export Processor Parameter Help |  ClientID which will be set in JMS connection  |  ExampleClientID   |         clientID         |
| Export Processor Parameter Description |           50001           |          50004           | JMS Topic Export Processor Parameter Help | protocol which will be used for JMS connection |        tcp         |         protocol         |
| Export Processor Parameter Description |           50001           |          50005           | JMS Topic Export Processor Parameter Help |        Time to Live for the JMS Message        |       10000        |        timeToLive        |
| Export Processor Parameter Description |           50001           |          50006           | JMS Topic Export Processor Parameter Help |        Is JMS Delivery Mode Persistent         |        true        | isDeliveryModePersistent |

</div>

</div>
