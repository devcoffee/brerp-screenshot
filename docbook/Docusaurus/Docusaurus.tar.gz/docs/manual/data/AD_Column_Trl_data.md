<div id="d2891e1" class="table">

<div class="table-title">

Table 1. Coluna
\*\*

</div>

<div class="table-contents">

|        |        |           |                                   |             |
| :----: | :----: | :-------: | :-------------------------------: | :---------: |
| Coluna | Idioma | Traduzida |               Nome                | Placeholder |
| 57396  | es\_CO |   false   |          Característica           |             |
| 57423  | es\_CO |   false   |       Cantidad Desperdicio        |             |
| 57448  | es\_CO |   false   |           Fecha Inicio            |             |
| 57449  | es\_CO |   false   |       Fecha Inicio Programa       |             |
|  5794  | es\_CO |   false   |  Referencia de Orden de Tercero   |             |
| 13624  | es\_CO |   false   |          Parámetro Web 5          |             |
| 13625  | es\_CO |   false   |          Parámetro Web 6          |             |
| 14484  | es\_CO |   false   |          Fecha Contable           |             |
|  5552  | es\_CO |   false   |         Grupo de Tercero          |             |
|  6854  | es\_CO |   false   |              Código               |             |
|  5544  | es\_CO |   false   |             Aprobado              |             |
|  4649  | es\_CO |   false   |           Contabilizado           |             |
|  2754  | es\_CO |   false   |              Tercero              |             |
|  2581  | es\_CO |   false   |           Fecha Inicio            |             |
|  5259  | es\_CO |   false   |           Contabilizado           |             |
|  7794  | es\_CO |   false   |     Contraseña Usuario EMail      |             |
|  7962  | es\_CO |   false   |       Dirección Web Imagen        |             |
|  6558  | es\_CO |   false   |        Carpeta Solicitudes        |             |
|  7061  | es\_CO |   false   |       Calcular Promedio (μ)       |             |
|  1226  | es\_CO |   false   |         Formato Teléfono          |             |
| 14725  | es\_CO |   false   |           Estado Tarea            |             |
| 15335  | es\_CO |   false   |             Plantilla             |             |
| 10242  | es\_CO |   false   |  Instancia Conjunto de Atributos  |             |
| 10683  | es\_CO |   false   |          Crédito Fuente           |             |
| 10901  | es\_CO |   false   |              Tercero              |             |
| 11379  | es\_CO |   false   |   Siguiente Fecha de Ejecución    |             |
|  9545  | es\_CO |   false   |             Actividad             |             |
|  4922  | es\_CO |   false   |     Diferencia Edo. De Cuenta     |             |
|  9229  | es\_CO |   false   |           Débito Fuente           |             |
|  8248  | es\_CO |   false   |             Actividad             |             |
|  8251  | es\_CO |   false   |              Tercero              |             |
|  7815  | es\_CO |   false   |         Código ISO Moneda         |             |
| 14546  | es\_CO |   false   | Fondos de la contabilidad general |             |
| 12557  | es\_CO |   false   |               Monto               |             |
| 13700  | es\_CO |   false   |          Mensaje Correo           |             |
| 13651  | es\_CO |   false   |          Parámetro Web 1          |             |
| 13652  | es\_CO |   false   |          Parámetro Web 2          |             |
| 10831  | es\_CO |   false   |   Línea Autorización Devolución   |             |
|  6491  | es\_CO |   false   |         Pagos sin Asignar         |             |
|  7647  | es\_CO |   false   |          Código Tercero           |             |
|  4423  | es\_CO |   false   |       Instancia de Proceso        |             |
|  455   | es\_CO |   false   |     Factor de Base a Destino      |             |
|  5752  | es\_CO |   false   |      Representante Comercial      |             |
| 11774  | es\_CO |   false   |              Tercero              |             |
| 12006  | es\_CO |   false   |         Código ISO Moneda         |             |
| 12182  | es\_CO |   false   |             Aprobado              |             |
|  7453  | es\_CO |   false   |    Saludo contacto del tercero    |             |
| 14780  | es\_CO |   false   |           Columna Clave           |             |
|  3094  | es\_CO |   false   |      Cuenta Bancaria Tercero      |             |
|  7739  | es\_CO |   false   |      Representante Comercial      |             |
|  3902  | es\_CO |   false   |              Tercero              |             |
| 12746  | es\_CO |   false   |      Disposición Teclado PDV      |             |
| 12748  | es\_CO |   false   |      Representante Comercial      |             |
| 14077  | es\_CO |   false   |       Instancia de Proceso        |             |
| 13166  | es\_CO |   false   |  Instancia Conjunto de Atributos  |             |
|  9884  | es\_CO |   false   |         Info Verificación         |             |
| 12528  | es\_CO |   false   |        No. Orden Registro         |             |
| 15407  | es\_CO |   false   |           Proyecto web            |             |
| 15166  | es\_CO |   false   |             Indexado              |             |
| 15169  | es\_CO |   false   |            Meta Autor             |             |
| 15517  | es\_CO |   false   |          Entrada de chat          |             |
| 15216  | es\_CO |   false   |         Marco de objetivo         |             |
| 14414  | es\_CO |   false   |  Instancia Conjunto de Atributos  |             |
| 13054  | es\_CO |   false   |           Llenar Forma            |             |
| 14777  | es\_CO |   false   |         Grupo de Tercero          |             |
| 15726  | es\_CO |   false   |      Servidor de trasmisión       |             |
| 15727  | es\_CO |   false   |         Tipo de solicitud         |             |
| 15735  | es\_CO |   false   |             Guion (-)             |             |
| 15736  | es\_CO |   false   |             Protocolo             |             |
| 15737  | es\_CO |   false   |         Codigo de estado          |             |
| 12976  | es\_CO |   false   |              Tercero              |             |
|  787   | es\_CO |   false   |           Moneda Hacia            |             |
|  2175  | es\_CO |   false   |             Aprobado              |             |
|  3499  | es\_CO |   false   |              Tercero              |             |
| 10163  | es\_CO |   false   |              Tercero              |             |
| 10051  | es\_CO |   false   |    Número de Referencia (SKU)     |             |
| 11738  | es\_CO |   false   |          Línea SCP (RfQ)          |             |
|  6623  | es\_CO |   false   |              Tercero              |             |
|  7940  | es\_CO |   false   |     Mensaje Error Importación     |             |
|  1667  | es\_CO |   false   |           Nota Contable           |             |
|  1680  | es\_CO |   false   |          Crédito Fuente           |             |
|  2958  | es\_CO |   false   |              Tercero              |             |
|  489   | es\_CO |   false   |        Precisión del Costo        |             |
| 11814  | es\_CO |   false   |       Dirección del Tercero       |             |
| 11815  | es\_CO |   false   |              Tercero              |             |
|  4974  | es\_CO |   false   |         Grupo de Tercero          |             |
|  5941  | es\_CO |   false   |          Columna Tercero          |             |
|  1790  | es\_CO |   false   |             Aprobado              |             |
|  3512  | es\_CO |   false   |      Representante Comercial      |             |
|  7963  | es\_CO |   false   |     Dirección Web Descripción     |             |
|  2724  | es\_CO |   false   |         Arbol de Proyecto         |             |
| 12982  | es\_CO |   false   |          Crédito Fuente           |             |
| 12831  | es\_CO |   false   |       Cantidad Desperdicio        |             |
| 13153  | es\_CO |   false   |        Código Verificación        |             |
| 13205  | es\_CO |   false   |              Tercero              |             |
| 14435  | es\_CO |   false   |    Conciliación de Inventario     |             |
| 15159  | es\_CO |   false   |             Plantilla             |             |
| 15425  | es\_CO |   false   |             Plantilla             |             |
| 15454  | es\_CO |   false   |         Reglas de factura         |             |
| 12530  | es\_CO |   false   |            Dirección 3            |             |

</div>

</div>
