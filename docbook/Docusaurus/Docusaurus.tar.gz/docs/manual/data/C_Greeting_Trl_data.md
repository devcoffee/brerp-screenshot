<div id="d178487e1" class="table">

<div class="table-title">

Table 1. Saudação \*\*

</div>

<div class="table-contents">

|        |          |          |           |      |
| :----: | :------: | :------: | :-------: | :--: |
| Idioma | Saudação | Saudação | Traduzida | Nome |
| pt\_BR |   100    |    Mr    |   true    |  Mr  |
| es\_CO |   100    |    Sr    |   true    |  Sr  |

</div>

</div>
