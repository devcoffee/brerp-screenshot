<div id="d409146e1" class="table">

<div class="table-title">

Table 1. Imposto
Brasileiro

</div>

<div class="table-contents">

|        |                                                                        |                    |                |
| :----: | :--------------------------------------------------------------------: | :----------------: | :------------: |
| Tabela |                               Descrição                                | Imposto Brasileiro | ID do Registro |
|        |              ICMSST-18,00, ICMSDIFAL-5,00, ICMSPROD-12,00              |      1000081       |                |
|        |              ICMSDIFAL-6,00, ICMSPROD-12,00, ICMSST-18,00              |      1000009       |                |
|        |                             ICMSPROD-18,00                             |      1000532       |                |
|        |      ICMSST-18,00, ICMSPROD-12,00, PISPROD-1,65, COFINSPROD-7,60       |      5000000       |                |
|        |                       ICMSST-0,00, ICMSPROD-0,00                       |      5000057       |                |
|        |                       ICMSST-0,00, ICMSPROD-0,00                       |      5000006       |                |
|        |                      ICMSPROD-0,00, ICMSST-18,00                       |      5000058       |                |
|        |                      ICMSPROD-0,00, ICMSST-18,00                       |      5000009       |                |
|        |                      ICMSPROD-0,00, ICMSST-18,00                       |      5000059       |                |
|        |                       ICMSST-0,00, ICMSPROD-0,00                       |      5000010       |                |
|        |                       ICMSPROD-0,00, ICMSST-0,00                       |      5000017       |                |
|        |                       ICMSPROD-0,00, ICMSST-0,00                       |      5000018       |                |
|        |                      ICMSPROD-0,00, ICMSST-18,00                       |      5000019       |                |
|        |                      ICMSST-18,00, ICMSPROD-0,00                       |      5000020       |                |
|        |                       ICMSST-0,00, ICMSPROD-0,00                       |      5000021       |                |
|        |                       ICMSST-0,00, ICMSPROD-0,00                       |      5000022       |                |
|        |                       ICMSPROD-0,00, ICMSST-0,00                       |      5000023       |                |
|        |                       ICMSPROD-0,00, ICMSST-0,00                       |      5000024       |                |
|        |                       ICMSST-0,00, ICMSPROD-0,00                       |      5000025       |                |
|        |             ICMSPROD-18,00, PISPROD-0,00, COFINSPROD-0,00              |      1000730       |                |
|        |             ICMSPROD-18,00, PISPROD-0,00, COFINSPROD-0,00              |      1000731       |                |
|        |             ICMSPROD-18,00, PISPROD-0,00, COFINSPROD-0,00              |      1000732       |                |
|        |             ICMSPROD-18,00, PISPROD-0,00, COFINSPROD-0,00              |      1000734       |                |
|        |        ICMSPROD-18,00, PISPROD-1,65, COFINSPROD-7,60, IPI-5,00         |      1000736       |                |
|        |        ICMSPROD-18,00, PISPROD-1,65, COFINSPROD-7,60, IPI-5,00         |      1000735       |                |
|        |        ICMSPROD-18,00, PISPROD-1,65, COFINSPROD-7,60, IPI-5,00         |      1000733       |                |
|        |        ICMSPROD-18,00, PISPROD-1,65, COFINSPROD-7,60, IPI-5,00         |      1000737       |                |
|        |                      ICMSPROD-0,00, ICMSST-18,00                       |      5000026       |                |
|        |                      ICMSPROD-0,00, ICMSST-18,00                       |      5000027       |                |
|        |                       ICMSST-0,00, ICMSPROD-0,00                       |      5000028       |                |
|        |                       ICMSST-0,00, ICMSPROD-0,00                       |      5000060       |                |
|        |                       ICMSPROD-0,00, ICMSST-0,00                       |      5000049       |                |
|        |                       ICMSPROD-0,00, ICMSST-0,00                       |      5000050       |                |
|        |                      ICMSPROD-0,00, ICMSST-18,00                       |      5000051       |                |
|        |                      ICMSST-18,00, ICMSPROD-0,00                       |      5000052       |                |
|        |                       ICMSST-0,00, ICMSPROD-0,00                       |      5000053       |                |
|        |                       ICMSST-0,00, ICMSPROD-0,00                       |      5000054       |                |
|        |                       ICMSPROD-0,00, ICMSST-0,00                       |      5000055       |                |
|        |                       ICMSPROD-0,00, ICMSST-0,00                       |      5000056       |                |
|        |              ICMSDIFAL-6,00, ICMSST-18,00, ICMSPROD-12,00              |      1000003       |                |
|        |              ICMSDIFAL-6,00, ICMSPROD-12,00, ICMSST-18,00              |      1000014       |                |
|        |      ICMSST-18,00, ICMSPROD-12,00, PISPROD-1,65, COFINSPROD-7,60       |      5000001       |                |
|        |                       ICMSPROD-0,00, ICMSST-0,00                       |      5000086       |                |
|        |                       ICMSPROD-0,00, ICMSST-0,00                       |      5000004       |                |
|        |                      ICMSPROD-0,00, ICMSST-18,00                       |      5000087       |                |
|        |                      ICMSST-18,00, ICMSPROD-0,00                       |      5000005       |                |
|        |                      ICMSST-18,00, ICMSPROD-0,00                       |      5000088       |                |
|        |                       ICMSST-0,00, ICMSPROD-0,00                       |      5000089       |                |
|        |                       ICMSST-0,00, ICMSPROD-0,00                       |      5000090       |                |
|        |                       ICMSST-0,00, ICMSPROD-0,00                       |      5000007       |                |
|        |                             ICMSDIFAL-6,00                             |      5000008       |                |
|        | ICMSST-18,00, ICMSPROD-12,00, PISPROD-1,65, COFINSPROD-7,60, IPI-10,00 |      5000031       |                |
|        |                       ICMSPROD-0,00, ICMSST-0,00                       |      5000061       |                |
|        |                       ICMSPROD-0,00, ICMSST-0,00                       |      5000062       |                |
|        |                      ICMSPROD-0,00, ICMSST-18,00                       |      5000063       |                |
|        |                      ICMSST-18,00, ICMSPROD-0,00                       |      5000064       |                |
|        |                       ICMSST-0,00, ICMSPROD-0,00                       |      5000065       |                |
|        |                       ICMSST-0,00, ICMSPROD-0,00                       |      5000066       |                |
|        |                       ICMSPROD-0,00, ICMSST-0,00                       |      5000067       |                |
|        |                       ICMSPROD-0,00, ICMSST-0,00                       |      5000068       |                |
|        |                       ICMSST-0,00, ICMSPROD-0,00                       |      5000069       |                |
|        |                      ICMSPROD-0,00, ICMSST-18,00                       |      5000070       |                |
|        |                      ICMSPROD-0,00, ICMSST-18,00                       |      5000071       |                |
|        |                       ICMSST-0,00, ICMSPROD-0,00                       |      5000072       |                |
|        |                       ICMSPROD-0,00, ICMSST-0,00                       |      5000073       |                |
|        |                       ICMSPROD-0,00, ICMSST-0,00                       |      5000074       |                |
|        |                      ICMSPROD-0,00, ICMSST-18,00                       |      5000075       |                |
|        |                      ICMSST-18,00, ICMSPROD-0,00                       |      5000076       |                |
|        |                       ICMSST-0,00, ICMSPROD-0,00                       |      5000077       |                |
|        |                       ICMSST-0,00, ICMSPROD-0,00                       |      5000078       |                |
|        |                       ICMSPROD-0,00, ICMSST-0,00                       |      5000079       |                |
|        |                       ICMSPROD-0,00, ICMSST-0,00                       |      5000080       |                |
|        |                       ICMSST-0,00, ICMSPROD-0,00                       |      5000081       |                |
|        |                      ICMSPROD-0,00, ICMSST-18,00                       |      5000082       |                |
|        |                      ICMSPROD-0,00, ICMSST-18,00                       |      5000083       |                |
|        |                       ICMSST-0,00, ICMSPROD-0,00                       |      5000084       |                |
|        |                       ICMSPROD-0,00, ICMSST-0,00                       |      5000085       |                |
|        |                       ICMSPROD-0,00, ICMSST-0,00                       |      5000091       |                |
|        |                       ICMSPROD-0,00, ICMSST-0,00                       |      5000092       |                |
|        |                       ICMSST-0,00, ICMSPROD-0,00                       |      5000093       |                |
|        |                      ICMSPROD-0,00, ICMSST-18,00                       |      5000094       |                |
|        |                      ICMSPROD-0,00, ICMSST-18,00                       |      5000095       |                |
|        |                       ICMSST-0,00, ICMSPROD-0,00                       |      5000096       |                |
|        |              ICMSDIFAL-6,00, ICMSPROD-12,00, ICMSST-18,00              |      1000273       |                |
|        |              ICMSDIFAL-6,00, ICMSPROD-12,00, ICMSST-18,00              |      1000581       |                |
|        |                       ICMSST-0,00, ICMSPROD-0,00                       |      5000117       |                |
|        |                       ICMSPROD-0,00, ICMSST-0,00                       |      5000002       |                |
|        |                      ICMSPROD-0,00, ICMSST-18,00                       |      5000118       |                |
|        |                       ICMSPROD-0,00, ICMSST-0,00                       |      5000012       |                |
|        |                      ICMSPROD-0,00, ICMSST-18,00                       |      5000119       |                |
|        |                       ICMSST-0,00, ICMSPROD-0,00                       |      5000013       |                |
|        |                       ICMSST-0,00, ICMSPROD-0,00                       |      5000120       |                |
|        |                       ICMSPROD-0,00, ICMSST-0,00                       |      5000015       |                |
|        |                       ICMSPROD-0,00, ICMSST-0,00                       |      5000034       |                |
|        |                       ICMSPROD-0,00, ICMSST-0,00                       |      5000035       |                |
|        |                      ICMSPROD-0,00, ICMSST-18,00                       |      5000036       |                |
|        |                      ICMSST-18,00, ICMSPROD-0,00                       |      5000037       |                |
|        |                       ICMSST-0,00, ICMSPROD-0,00                       |      5000038       |                |
|        |                       ICMSST-0,00, ICMSPROD-0,00                       |      5000039       |                |
|        |                       ICMSPROD-0,00, ICMSST-0,00                       |      5000040       |                |

</div>

</div>
