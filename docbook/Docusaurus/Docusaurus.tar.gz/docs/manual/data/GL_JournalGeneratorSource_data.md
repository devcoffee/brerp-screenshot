<div id="d255463e1" class="table">

<div class="table-title">

Table 1. Gerador de
Fonte

</div>

<div class="table-contents">

|                     |                    |                          |                  |                  |                  |                         |
| :-----------------: | :----------------: | :----------------------: | :--------------: | :--------------: | :--------------: | :---------------------: |
| Valor Multiplicador | Elemento de Contas | Categoria de Razão Geral | Gerador de Linha | Gerador de Fonte | Comentário/Ajuda | Fator de Arredondamento |
|          1          |        632         |                          |      200000      |      200000      |                  |            2            |
|          1          |        704         |                          |      200000      |      200001      |                  |            2            |
|          1          |        429         |                          |      200001      |      200002      |                  |            2            |
|          1          |        449         |                          |      200002      |      200003      |                  |            2            |
|          1          |        783         |                          |      200003      |      200004      |                  |            2            |
|          1          |        716         |                          |      200004      |      200005      |                  |            2            |
|          1          |       50008        |                          |      200004      |      200006      |                  |            2            |
|          1          |        771         |                          |      200005      |      200008      |                  |            2            |
|          1          |      1000702       |                          |     5000001      |     5000001      |                  |           10            |

</div>

</div>
