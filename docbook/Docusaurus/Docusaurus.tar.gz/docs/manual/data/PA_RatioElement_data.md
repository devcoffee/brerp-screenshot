<div id="d533539e1" class="table">

<div class="table-title">

Table 1. Elemento de
Relação

</div>

<div class="table-contents">

|       |                 |           |                       |                    |                     |       |             |                    |              |         |           |
| :---: | :-------------: | :-------: | :-------------------: | :----------------: | :-----------------: | :---: | :---------: | :----------------: | :----------: | :-----: | :-------: |
| Conta | Valor Constante | Descrição |         Nome          | Cálculo de Medição | Elemento de Relação | Razão | Razão Usada | Tipo de Lançamento | Element Type | Operand | Seqüência |
|  537  |        0        |           | Long Term Investments |                    |         100         |  100  |             |         A          |      A       |    P    |    10     |
|  541  |        0        |           |       Inventory       |                    |         101         |  100  |             |         A          |      A       |    P    |     0     |
|  554  |        0        |           |   Land and Building   |                    |         102         |  100  |             |                    |      A       |    P    |     0     |

</div>

</div>
