<div id="d86512e1" class="table">

<div class="table-title">

Table 1. Parâmetro definido pelo
Usuário

</div>

<div class="table-contents">

|                       |                              |                                 |               |                                |                        |                                                                                                            |          |                       |                     |                           |
| :-------------------: | :--------------------------: | :-----------------------------: | :-----------: | :----------------------------: | :--------------------: | :--------------------------------------------------------------------------------------------------------: | :------: | :-------------------: | :-----------------: | :-----------------------: |
| Parâmetro de Processo | Janela definida pelo Usuário | Parâmetro definido pelo Usuário | Lógica Padrão |           Descrição            | Lógica de Visualização |                                              Comentário/Ajuda                                              | Mostrado | Lógica de Obrigatório |        Nome         | Lógica Somente de Leitura |
|        1501218        |           5000000            |             5000001             |    5000001    |        Centro de Custo         |                        | O "Centro de Custo" exibe os elementos opcionais que tenham sido definidos para esta combinação de contas. |   true   |                       |   Centro de Custo   |            1=1            |
|          211          |           5000000            |             5000000             |       Y       | Esta é uma Transação de Vendas |                        |        A caixa de verificação "Transação de Vendas" indica se este item é uma Transação de Vendas.         |   true   |                       | Transação de Vendas |            1=1            |

</div>

</div>
