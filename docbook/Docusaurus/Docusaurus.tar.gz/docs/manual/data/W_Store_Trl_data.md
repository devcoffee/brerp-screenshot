<div id="d559256e1" class="table">

<div class="table-title">

Table 1. Loja de Web
\*\*

</div>

<div class="table-contents">

|        |                 |                    |           |                        |                     |                            |                 |                 |                 |                 |             |
| :----: | :-------------: | :----------------: | :-------: | :--------------------: | :-----------------: | :------------------------: | :-------------: | :-------------: | :-------------: | :-------------: | :---------: |
| Idioma | Rodapé de email | Cabeçalho de email | Traduzida | Informação da Loja Web |   Parâmetro Web 1   |      Parâmetro Web 2       | Parâmetro Web 3 | Parâmetro Web 4 | Parâmetro Web 5 | Parâmetro Web 6 | Loja de Web |
| pt\_BR |                 |                    |   true    |                        | iDempiere120x60.png | \< h1\> Web Store\< /h1\>  |   Parameter3    |   Parameter4    |   Parameter5    |   Parameter6    |     11      |
| es\_CO |                 |                    |   true    |                        | iDempiere120x60.png | \< h1\> Tienda Web\< /h1\> |   Parámetro3    |   Parámetro4    |   Parámetro5    |   Parámetro6    |     11      |

</div>

</div>
