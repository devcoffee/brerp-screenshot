<div id="d96356e1" class="table">

<div class="table-title">

Table 1. Parâmetro de Nó de Fluxo de
Trabalho

</div>

<div class="table-contents">

|                       |     |                                      |                  |                      |           |                  |
| :-------------------: | :-: | :----------------------------------: | :--------------: | :------------------: | :-------: | :--------------: |
| Parâmetro de Processo | Nó  | Parâmetro de Nó de Fluxo de Trabalho | Nome do Atributo |  Valor de Atributo   | Descrição | Tipo de Entidade |
|          479          | 179 |                 100                  | M\_Warehouse\_ID | @\#M\_Warehouse\_ID@ |           |        D         |

</div>

</div>
