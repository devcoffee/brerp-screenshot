<div id="d86817e1" class="table">

<div class="table-title">

Table 1. AD\_UserPreference\_ID

</div>

<div class="table-contents">

|                 |                        |                        |                                         |                          |                      |                |                        |
| :-------------: | :--------------------: | :--------------------: | :-------------------------------------: | :----------------------: | :------------------: | :------------: | :--------------------: |
| Usuário/Contato | AD\_UserPreference\_ID | Salvar Automáticamente | Casas Decimais Automáticas para Valores | Novo Registro Automático | Detailed Zoom Across | Use Similar To | Toggle on Double Click |
|       100       |        1000000         |          true          |                    0                    |           true           |        false         |     false      |         false          |
|       100       |        1000002         |          true          |                    0                    |           true           |        false         |     false      |         false          |
|     5000000     |        5000000         |          true          |                    0                    |           true           |        false         |     false      |         false          |
|     1000000     |        5000001         |          true          |                    0                    |           true           |        false         |     false      |         false          |
|     1000023     |        5000002         |          true          |                    0                    |           true           |        false         |     false      |         false          |
|     1000005     |        5000003         |          true          |                    0                    |           true           |        false         |     false      |         false          |
|     1000022     |        5000004         |          true          |                    0                    |           true           |        false         |     false      |         false          |
|       100       |        1000001         |          true          |                    0                    |           true           |         true         |     false      |         false          |
|     1000026     |        5000005         |          true          |                    0                    |           true           |        false         |     false      |         false          |

</div>

</div>
