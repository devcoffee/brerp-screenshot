<div id="d440166e1" class="table">

<div class="table-title">

Table 1. Versão da Lista de Preço \*\*

</div>

<div class="table-contents">

|        |           |                          |                     |
| :----: | :-------: | :----------------------: | :-----------------: |
| Idioma | Traduzida | Versão da Lista de Preço |        Nome         |
| pt\_BR |   false   |           101            |    Standard 2001    |
| pt\_BR |   false   |           102            |    Purchase 2001    |
| pt\_BR |   false   |           103            |    Purchase 2003    |
| pt\_BR |   false   |           104            |    Standard 2003    |
| pt\_BR |   false   |           105            |     Export 2003     |
| pt\_BR |   false   |         1000000          |     Vendas BRL      |
| pt\_BR |   false   |         1000001          |     Compras BRL     |
| es\_CO |   false   |         1000000          |     Vendas BRL      |
| es\_CO |   false   |         1000001          |     Compras BRL     |
| es\_CO |   false   |         1000003          |        VENDA        |
| es\_CO |   false   |         1000002          |       Padrão        |
| es\_CO |   false   |         1000004          |       COMPRA        |
| es\_CO |   false   |           101            |    Standard 2001    |
| es\_CO |   false   |           102            |    Purchase 2001    |
| es\_CO |   false   |           103            |    Purchase 2003    |
| es\_CO |   false   |           104            |    Standard 2003    |
| es\_CO |   false   |           105            |     Export 2003     |
| pt\_BR |   true    |         1000002          |       Padrão        |
| pt\_BR |   false   |         1000003          |        VENDA        |
| pt\_BR |   false   |         1000004          |       COMPRA        |
| pt\_BR |   false   |         5000000          |      COMPRA $$      |
| es\_CO |   false   |         5000000          |      COMPRA $$      |
| pt\_BR |   false   |         5000001          | 2018-01-11 15:03:07 |
| es\_CO |   false   |         5000001          | 2018-01-11 15:03:07 |
| pt\_BR |   false   |         5000002          |    VENDA MARKUP     |
| es\_CO |   false   |         5000002          |    VENDA MARKUP     |

</div>

</div>
